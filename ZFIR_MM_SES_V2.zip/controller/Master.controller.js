sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"zfir_mm_srv_v2/model/formatter"
], function(Controller, MessageToast, JSONModel, Filter, formatter) {
	"use strict";

	return Controller.extend("zfir_mm_srv_v2.controller.Master", {
		formatter: formatter,
		oGroupSort: {
			sGroupKey: null,
			bGroupDescending: null,
			sSortKey: null,
			bSortDescending: null
		},
		// Constants:
		PO_ITEMS_TABLE: {
			ID: "POItemsTable",
			SORT_KEY: {
				EADAT: "Eadat",
				EBELN: "Ebeln"
			}
		},
		//get the model instance
		onInit: function() {
			//disable sort button
			var oSort = this.byId("sort");
			oSort.setEnabled(false);
			JSONModel = this.getOwnerComponent().getModel("json");
		},

		//method to get router instance
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		//called when item is pressed
		onListItemPress: function(evt) {
			//get the ebeln presed
			var oCtx = evt.getSource().getTitle();
			var oLine = evt.getSource().getBindingContext().getProperty("Ebelp");
			//navigate to detail view the clicked ebeln
			this.getRouter().navTo("detail", {
				ebeln: oCtx,
				ebelp: oLine
			});

			MessageToast.show("Order : " + evt.getSource().getTitle());
		},

		//called on search control
		handleSearch: function(evt) {
			var aFilters = [];
			var sQuery = evt.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("Ebeln", sap.ui.model.FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}
			var oList = this.getView().byId("list");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters);
		},

		//call on filter value change
		onChange: function(oEvent) {
			this.byId("filterBar").fireFilterChange(oEvent);
		},
		//reset all filters
		onReset: function() {
			var oItems = this.byId("filterBar").getAllFilterItems(true);
			for (var i = 0; i < oItems.length; i++) {
				var oControl = this.byId("filterBar").determineControlByFilterItem(oItems[i]);
				if (oControl) {
					oControl.setValue("");
				}
			}
		},
		//Search functionality based on values in filters
		onSearch: function() {
			var i;
			var oControl;
			var filter;
			var aFilter = [];
			var aFilters = this.byId("filterBar").getFilterGroupItems();
			var aFiltersWithValue = [];
			for (i = 0; i < aFilters.length; i++) {
				oControl = this.byId("filterBar").determineControlByFilterItem(aFilters[i]);
				if (oControl && oControl.getValue && oControl.getValue()) {
					aFiltersWithValue.push(aFilters[i]);
					if (i === 0) {
						filter = new Filter("Ebeln", sap.ui.model.FilterOperator.Contains, oControl.getValue());
						aFilter.push(filter);
					}
					if (i === 1) {
						var value = this.byId("date").getProperty("dateValue");
						var date = new Date(value.getUTCFullYear(), value.getMonth(), value.getUTCDate());
						var nDate = sap.ui.core.format.DateFormat.getDateInstance({
							pattern: "yyyy-MM-dd"
						});
						var oDatef = nDate.format(new Date(date));
						var oDateout = oDatef + 'T00:00:00';
						filter = new Filter("Eadat", sap.ui.model.FilterOperator.EQ, oDateout);
						aFilter.push(filter);
					}
					if (i === 2) {
						if (oControl.getSelectedKey()) {
							filter = new Filter("Lgort", sap.ui.model.FilterOperator.EQ, oControl.getSelectedKey());
						} else {
							if (JSONModel.getData().slKey) {
								filter = new Filter("Lgort", sap.ui.model.FilterOperator.EQ, JSONModel.getData().slKey);
							}
						}
						aFilter.push(filter);
					}
					if (i === 3) {
						if (oControl.getSelectedKey()) {
							filter = new Filter("Lifnr", sap.ui.model.FilterOperator.EQ, oControl.getSelectedKey());
						} else {
							if (JSONModel.getData().lfKey) {
								filter = new Filter("Lifnr", sap.ui.model.FilterOperator.EQ, JSONModel.getData().lfKey);
							}
						}
						aFilter.push(filter);
					}
				}
			}

			var oBinding = this.byId("list").getBinding("items");
			var vURLCountPR = "/SesHeaderSet/$count?" + oBinding.filter(aFilter);
			var oModel = this.getOwnerComponent().getModel();
			var oSort = this.byId("sort");
			var that = this;
			var mParameters = {
				json: true,
				success: (function(oData, response) {
					oSort.setEnabled(true);
					sap.ui.core.BusyIndicator.hide();
				}),
				error: (function(oError) {
					oSort.setEnabled(false);
					sap.ui.core.BusyIndicator.hide();
					if (that._lineItemViewDialog) {
						that._lineItemViewDialog.destroy(true);
					}
				})
			};
			sap.ui.core.BusyIndicator.show();
			oModel.read(vURLCountPR, mParameters);

		},
		onUpdatefinish: function(e) {
			var oSort = this.byId("sort");
			if (e.getParameter("actual") !== 0) {
				oSort.setEnabled(true);
			} else {
				oSort.setEnabled(false);
			}
		},
		//add f4 valuehelp for Purchase Order
		handleValueHelpPo: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._oPOf4) {
				this._oPOf4 = sap.ui.xmlfragment(
					"zfir_mm_srv_v2.view.POf4",
					this
				);
				this.getView().addDependent(this._oPOf4);
			}
			// create a filter for the binding
			this._oPOf4.getBinding("items").filter([new Filter(
				"Ebeln",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);
			// open value help dialog filtered by the input value
			this._oPOf4.open(sInputValue);
		},
		//addf4 valuehelp for Storage Locations
		handleValueHelpLg: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._oSLf4) {
				this._oSLf4 = sap.ui.xmlfragment(
					"zfir_mm_srv_v2.view.SLf4",
					this
				);
				this.getView().addDependent(this._oSLf4);
			}
			// create a filter for the binding
			this._oSLf4.getBinding("items").filter([new Filter(
				"Lgobe",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);
			// open value help dialog filtered by the input value
			this._oSLf4.open(sInputValue);
		},
		//add f4 valuehelp for Vendor
		//addf4 valuehelp for Storage Locations
		handleValueHelpLf: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._oLFf4) {
				this._oLFf4 = sap.ui.xmlfragment(
					"zfir_mm_srv_v2.view.LFf4",
					this
				);
				this.getView().addDependent(this._oLFf4);
			}
			// create a filter for the binding
			this._oLFf4.getBinding("items").filter([new Filter(
				"Name1",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);
			// open value help dialog filtered by the input value
			this._oLFf4.open(sInputValue);
		},
		_handleValueHelpSearch: function(evt) {
			var oDialog = evt.getParameter("id");
			var sValue = evt.getParameter("value");
			var oFilter;
			if (oDialog === "pod") {
				oFilter = new Filter(
					"Ebeln",
					sap.ui.model.FilterOperator.Contains, sValue
				);
			} else {
				if (oDialog === "sld") {
					oFilter = new Filter(
						"Lgobe",
						sap.ui.model.FilterOperator.Contains, sValue
					);
				} else {
					oFilter = new Filter(
						"Name1",
						sap.ui.model.FilterOperator.Contains, sValue
					);
				}
			}
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpClose: function(evt) {
			var orderInput;
			var oDialog = evt.getParameter("id");
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				if (oDialog === "pod") {
					orderInput = this.byId("po");
					orderInput.setValue(oSelectedItem.getTitle());
				} else {
					if (oDialog === "sld") {
						orderInput = this.byId("sl");
						orderInput.setValue(oSelectedItem.getTitle());
						JSONModel.setProperty("/slKey", oSelectedItem.getDescription());
					} else {
						orderInput = this.byId("lf");
						orderInput.setValue(oSelectedItem.getTitle());
						JSONModel.setProperty("/lfKey", oSelectedItem.getDescription());
					}
				}
			}
			evt.getSource().getBinding("items").filter([]);
		},

		//sorter function called when sorting is called
		handleSort: function() {
			if (!this._lineItemViewDialog) {
				this._lineItemViewDialog = new sap.m.ViewSettingsDialog("sDi", {
					sortDescending: this.oGroupSort.bSortDescending,
					sortItems: [
						new sap.m.ViewSettingsItem("sDt", {
							text: "Created On",
							key: this.PO_ITEMS_TABLE.SORT_KEY.EADAT,
							selected: this.oGroupSort.sSortKey === this.PO_ITEMS_TABLE.SORT_KEY.EADAT
						}),
						new sap.m.ViewSettingsItem("sPo", {
							text: "Purchase Order",
							key: this.PO_ITEMS_TABLE.SORT_KEY.EBELN,
							selected: this.oGroupSort.sSortKey === this.PO_ITEMS_TABLE.SORT_KEY.EBELN
						})
					],
					confirm: jQuery.proxy(
						function(evt) {
							var oParams = evt.getParameters();
							this.oGroupSort.sSortKey = oParams.sortItem.getKey();
							this.oGroupSort.bSortDescending = oParams.sortDescending;
							this._groupSortItemTable();
							this.iCurNumItems = 0;
						}, this)
				});
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._lineItemViewDialog);
			}
			this._lineItemViewDialog.open();
		},

		/* Called if sorting or grouping of table is changed */
		_groupSortItemTable: function() {
			var oOverviewBinding;
			var aSorter = [];
			if ((this.oGroupSort.sGroupKey === null)) {
				if (this.oGroupSort.sSortKey === this.PO_ITEMS_TABLE.SORT_KEY.EADAT) {
					aSorter.push(new sap.ui.model.Sorter(this.PO_ITEMS_TABLE.SORT_KEY.EADAT, this.oGroupSort.bSortDescending, false));
				} else {
					if (this.oGroupSort.sSortKey === this.PO_ITEMS_TABLE.SORT_KEY.EBELN) {
						aSorter.push(new sap.ui.model.Sorter(this.PO_ITEMS_TABLE.SORT_KEY.EBELN, this.oGroupSort.bSortDescending, false));
					} else {
						aSorter.push(new sap.ui.model.Sorter(this.oGroupSort.sSortKey, this.oGroupSort.bSortDescending, false));
					}
				}
			}
			oOverviewBinding = this.byId("list").getBinding("items");
			oOverviewBinding.sort(aSorter);
		},

		// handleLiveChange: function(oEvent) {
		// 	var oBinding;
		// 	var vURLCountPR;
		// 	if (oEvent.getParameter("id").indexOf("po") !== -1) {
		// 		oBinding = this.byId("po").getBinding("suggestionItems");
		// 		vURLCountPR = "/EbelnVHSet/$count?" + oBinding.filter([new Filter("Ebeln", "EQ", oEvent.getParameter("value"))]);
		// 	} else {
		// 		if (oEvent.getParameter("id").indexOf("sl") !== -1) {
		// 			oBinding = this.byId("sl").getBinding("suggestionItems");
		// 			vURLCountPR = "/LgortVHSet/$count?" + oBinding.filter([new Filter("Lgobe", "EQ", oEvent.getParameter("value"))]);
		// 		} else {

		// 			if (oEvent.getParameter("id").indexOf("lf") !== -1) {
		// 				oBinding = this.byId("lf").getBinding("suggestionItems");
		// 				vURLCountPR = "/VendorVHSet/$count?" + oBinding.filter([new Filter("Name1", "EQ", oEvent.getParameter("value"))]);
		// 			}
		// 		}
		// 	}
		// 	var oModel = this.getOwnerComponent().getModel();
		// 	sap.ui.core.BusyIndicator.show(0);
		// 	// calling service with user input filters to get table records
		// 	var mParameters = {
		// 		json: true,
		// 		success: (function(oData, response) {
		// 			sap.ui.core.BusyIndicator.hide();
		// 		}),
		// 		error: (function(oError) {
		// 			sap.ui.core.BusyIndicator.hide();
		// 		})
		// 	};
		// 	oModel.read(vURLCountPR, mParameters);
		// 	// oModel.read(vURLCountPR, null, null, true,
		// 	// 	oModel.attachBatchRequestCompleted(function(d, r) {
		// 	// 		sap.ui.core.BusyIndicator.hide();
		// 	// 	}));

		// }
	});
});