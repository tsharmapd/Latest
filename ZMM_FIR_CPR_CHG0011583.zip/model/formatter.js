sap.ui.define([], function() {
	"use strict";
	return {
		/**
		 * itemMaster date change
		 */

		fixDecimals: function(value) {
			if (value) {
				var oInt = parseInt(value).toFixed(2);
				return oInt;
			} else {
				return value;
			}

		},

		date: function(value) {
			if (value) {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "MM/dd/yyyy"
				});
				var date = new Date(value.getUTCFullYear(), value.getMonth(), value.getUTCDate());
				return (oDateFormat.format(new Date(date)));
			} else {
				return value;
			}
		},

		matnr: function(a){
			if (a.slice(0,3) === "FTI") {
				return "";
			} else {
				return a;
			}	
		},
		
		datefr: function(value) {
			if (value) {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "MM/dd/yyyy"
				});
				var date = new Date(value.getUTCFullYear(), value.getMonth(), value.getUTCDate());
				var out =  oDateFormat.format(new Date(date));
				return out;
			} else {
				return value;
			}
		}
	};
});