/*global locatiFonFav */
sap.ui.define([
	"pr/req/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"pr/req/model/formatter",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/m/MessageToast"

], function(BaseController, JSONModel, formatter, MessageBox, Filter, MessageToast) {
	"use strict";

	return BaseController.extend("pr.req.controller.Detail", {

		formatter: formatter,
		/**/
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */
		// called to set cart data 
		onInit: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oModel.read("/DraftitemsSet", {
				success: function(r, s) {
					oJSONModel.setProperty("/cartModel", r.results);
				}
			});
			// to set Rig Number
			oModel.read("/CheckflagSet('B')", {
				success: function(r, s) {
					oJSONModel.setProperty("/RigNum", r);
				}
			});
			oJSONModel.refresh(true);
			//set selected key
			this.sComb = this.byId("selComb").getSelectedKey();
			oJSONModel.setProperty("/SelectedKey", this.sComb);			
		},
			

	
		/// on Search filter with the material num to get all items starting with number of matnr
		onSearchPressed: function(oEvent) {
			this.sSearch = oEvent.getParameter("query");
			var oModel = this.getView().getModel();
			var oJSONModel = this.getView().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/SearchItemsSet", {
				filters: [new Filter("Matkl", "EQ", ""), new Filter("Mfrnr", "EQ",
					""), new Filter("Matnr", "EQ", ""),new Filter("Mfrpn", "EQ", ""), new Filter("Maktx", "EQ", this.sSearch)],
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/tablebindingModel", r.results);
					oJSONModel.refresh("true");
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},

		/// on Search filter with the material num to get all items starting with number of matnr
		onSearchMatnr: function(oEvent) {
			this.sSearch = oEvent.getParameter("query");
			var oModel = this.getView().getModel();
			var oJSONModel = this.getView().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/SearchItemsSet", {
				filters: [new Filter("Matkl", "EQ", ""), new Filter("Mfrnr", "EQ",
					""), new Filter("Maktx", "EQ", ""), new Filter("Mfrpn", "EQ", ""), new Filter("Matnr", "EQ", this.sSearch)],
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/tablebindingModel", r.results);
					oJSONModel.refresh("true");
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},		
		
		// to remove table data
		RefreshTable: function() {
			this.byId("detailsearchField").setValue("");
			this.byId("detailsearchFieldmatnr").setValue("");
			this.getView().getModel("json").setProperty("/tablebindingModel", "");
			this.byId("table").getModel().refresh();
			this.byId("detailsItemHeader").setText("Items(0)");
		},
		//set combobox selection
		onCharge: function(){
			//// To get selectedkey from combobox 
			var oJSONModel = this.getOwnerComponent().getModel("json");
			this.sComb = this.byId("selComb").getSelectedKey();
			oJSONModel.setProperty("/SelectedKey", this.sComb);			
		},
		//	to update the count
		onDetailsTableUpdateFinished: function(oEvent) {
			var sTitle,
				iTotalItems = oEvent.getParameter("total");
			if (oEvent.getSource().getBinding("items").isLengthFinal()) {
				if (iTotalItems) {
					sTitle = this.byId("detailsItemHeader").setText("Items (" + iTotalItems + ")");
				} else {
					//Display 'Line Items' instead of 'Line items (0)'
					sTitle = this.byId("detailsItemHeader").setText("Items(0)");
				}
			}
		},

		//// on delete pressed of the dialog draft items//
		onDeletePressed: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var selctdItem = oEvent.getParameter("listItem").getBindingContext("json").getObject();
			var olinenum = selctdItem.Ebelp;
			var Guid = selctdItem.Guid;
			oModel.remove("/DraftlineSet(Guid='" + Guid + "',Ebelp='" + olinenum + "')", {
				success: function(data, response) {
					sap.ui.core.BusyIndicator.hide();
					oModel.read("/DraftitemsSet", {
						success: function(r, s) {
							oJSONModel.setProperty("/cartModel", r.results);
						}
					});
					MessageToast.show("Draft item successfully removed from cart");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
						}
					});
					oJSONModel.refresh("true");
				}
			});
		},
		//// shopping cart button opens dialog with draft items
		onShoppingCartPressed: function(oEvent) {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show();
			this.getOwnerComponent().getModel().read("/DraftitemsSet", {
				success: function(r) {

					oJSONModel.setProperty("/cartModel", r.results);
					if (r.results.length === "0") {
						oJSONModel.setProperty("/viewCart", false);
					} else {
						oJSONModel.setProperty("/viewCart", true);
					}

					sap.ui.core.BusyIndicator.hide();
				}
			});
			//// To get selectedkey from combobox 
			this.sComb = this.byId("selComb").getSelectedKey();
			oJSONModel.setProperty("/SelectedKey", this.sComb);
			// to open the shopping cart fragment
			if (!this.ocartPress) {
				this.ocartPress = sap.ui.xmlfragment("pr.req.view.fragment.ShoppingCart", this);
				this.getView().addDependent(this.ocartPress);
				this.ocartPress.setModel(oJSONModel);
				oJSONModel.refresh();
			}
			this.ocartPress.setModel(oJSONModel);
			oJSONModel.refresh();
			this.ocartPress.open();
		},

		///// cart dialog cancel closes dialog
		cancel: function() {
			this.ocartPress.close();
		},
		// Router component for navigation
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		//// navigation on View cart press on cart dialog
		ViewCart: function(oEvt) {

			var cartId = "cartId";
			this.getOwnerComponent().getRouter().navTo("cart", {
				cartId: cartId
			});
			this.RefreshTable();
		},
		/// Quick view opens with details
		onQckviewPressed: function(oEvent) {
			if (!this.oQckVwdialog) {
				this.oQckVwdialog = sap.ui.xmlfragment("pr.req.view.fragment.QuickView", this);
			}
			var sObject = oEvent.getSource().getParent().getBindingContext("json").getObject();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oJSONModel.setProperty("/QckvwModel", sObject);
			this.oQckVwdialog.setModel(oJSONModel);
			this.oQckVwdialog.bindElement("/QckvwModel");
			this.oQckVwdialog.openBy(oEvent.getSource());
		},

		/// favorite handling  selection and deselection  add's/delete's item to favorites table
		onFavoriteSelection: function(oEvent) {
			var state = oEvent.getSource().getPressed();
			this.setflag = "X";
			this.setevent = "";
			// action taken based on toggle state of button
			if (state == true) {
				this.setflag = "Y";
				var favObj = oEvent.getSource().getParent().getBindingContext("json").getObject();
				var sfavorite = {};
				sfavorite.Maktx = favObj.Maktx;
				sfavorite.Matkl = favObj.Matkl;
				sfavorite.Matnr = favObj.Matnr;
				sfavorite.Menge = favObj.Menge;
				sfavorite.Mfrnr = favObj.Mfrnr;
				sfavorite.Uom = favObj.Uom;
				sfavorite.Wgbez = favObj.Name1;
				sfavorite.Verpr = favObj.Verpr;
				sfavorite.Waers = favObj.Waers;
				sfavorite.Img = favObj.Image;
				var oModel = this.getOwnerComponent().getModel();
				var oJSONModel = this.getOwnerComponent().getModel("json");
				var that = this;
				oModel.create("/FavoriteSet", sfavorite, {
					success: function(oData, oResponse) {
						MessageToast.show("Item Selected as Favorite");
						oModel.read("/CheckflagSet('F')", {
							success: function(r) {
								oJSONModel.setProperty("/favCount", r);
								that.getOwnerComponent()._oViews._oViews["pr.req.view.Master"].byId("FavList").setInfo(r.Count);
								sap.ui.core.BusyIndicator.hide();
								oJSONModel.refresh(true);
							}
						});
					},
					error: function() {
						sap.ui.core.BusyIndicator.hide();
					}
				});
			}
			// when switching the state of btn from toggled to untoggle removes item from favoriteset
			if (state == false) {
				var oModel = this.getOwnerComponent().getModel();
				var oJSONModel = this.getOwnerComponent().getModel("json");
				var unfavObj = oEvent.getSource().getParent().getBindingContext("json").getObject();
				var unfavorite = {};
				unfavorite.Matnr = unfavObj.Matnr;
				var sMatnr = unfavObj.Matnr;
				var sParseMatnr = sMatnr.replace("#","@");
				var sMatnrr = sParseMatnr.replace("/","$");
				var sMatnrFinal = sMatnrr.replace(":","_");				
				var that = this;
				oModel.remove("/FavoriteSet(Matnr='" + sMatnrFinal + "')", {
					success: function(oData, oResponse) {
						MessageToast.show("Item deselected as favorite");
						oModel.read("/CheckflagSet('F')", {
							success: function(r) {
								sap.ui.core.BusyIndicator.hide();
								oJSONModel.setProperty("/favCount", r);
								that.getOwnerComponent()._oViews._oViews["pr.req.view.Master"].byId("FavList").setInfo(r.Count);
								oJSONModel.refresh(true);
							}
						});
					},
					error: function() {}
				});
			}
		},
		// to refresh table after rendering
		onAfterRendering: function() {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oJSONModel.getProperty("/tablebindingModel");
			oJSONModel.refresh("true");
		},

		//onfilter table data
		onFilter: function() {
			// to open the fragment to filter table data
			if (!this.fDialog) {
				this.fDialog = sap.ui.xmlfragment("pr.req.view.fragment.matmasterFilter", this);
				this.getView().addDependent(this.fDialog);
			}
			var c = [];
			var d = [];
			var oArray = this.getOwnerComponent().getModel("json").getData().tablebindingModel;
			for (var i = 0; i < oArray.length; i++) {
				if (c.indexOf(oArray[i].Maktx) === -1) {
					c.push(oArray[i].Maktx);
				}
			}
			for (var j = 0; j < c.length; j++) {
				var object = {};
				object.Maktx = c[j];
				d.push(object);
			}
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oJSONModel.setProperty("/matmasterFilter", d);
			this.fDialog.setFilterSearchCallback(null);
			this.fDialog.setFilterSearchOperator(sap.m.StringFilterOperator.Contains);
			this.fDialog.open();
		},
		//on filter confirm
		onFiltermatmasterConfirm: function(oEvent) {
			var params = oEvent.getParameters();
			// get the required filter items
			var aFilterItems = params.filterItems;
			var iLength = aFilterItems.length;
			// filter set for the table items
			var aFilter = [];
			if (iLength !== 0) {
				for (var i = 0; i < iLength; i++) {
					if (params.filterItems[i].mBindingInfos.key.binding.sPath == "Maktx") {
						if (params.filterItems[i].mBindingInfos.key.binding.oValue) {
							aFilter.push(new sap.ui.model.Filter(
								"Maktx",
								sap.ui.model.FilterOperator.EQ, params.filterItems[i].mBindingInfos.key.binding.oValue
							));
						}
					}
					var otable = this.byId("table").getBinding("items").filter(aFilter);
				}
			} else {
				var otable = this.byId("table").getBinding("items").filter(aFilter);
			}
		},

		/// on add to cart press adds draft items to shopping cart
		onAddToCartPressed: function(oEvent) {
			var objData = oEvent.getSource().getParent().getBindingContext("json").getObject();
			var i = parseInt(oEvent.getSource().getBindingContext("json").sPath.split("/")[2]);
			var oMenge = oEvent.getSource().getParent().getParent().getParent().getItems()[i].getCells()[6].getValue();
			if (oMenge === "0" || oMenge < 1 || oMenge === "") {
				MessageBox.warning("Quantity should not be Empty or Zero");
			} else {
				var cartData = {};
				cartData.Ebelp = "00010";
				cartData.Knttp = this.byId("selComb").getSelectedKey();
				cartData.Maktx = objData.Maktx;
				cartData.Matkl = objData.Matkl;
				cartData.Matnr = objData.Matnr;
				cartData.Menge = oEvent.getSource().getParent().getParent().getParent().getItems()[i].getCells()[6].getValue();
				cartData.Mfrnr = objData.Mfrnr;
				cartData.Wgbez = objData.Name1;
				cartData.Uom = objData.Uom;
				cartData.Verpr = objData.Verpr;
				cartData.Waers = objData.Waers;
				cartData.Image = objData.Image;
				var oModel = this.getOwnerComponent().getModel();
				var oJSONModel = this.getOwnerComponent().getModel("json");
				sap.ui.core.BusyIndicator.show(0);
				var that = this;
				oEvent.getSource().getParent().getParent().getParent().getItems()[i].getCells()[6].setValue("");
				// to get the selected row index of the table
				var x = oEvent.getSource().getBindingContext("json").getPath().replace(/tablebindingModel\//g, '');
				var Index = x.replace(/\//g, '');
				var oTable = this.byId("table");
			//	oTable.getItems()[Index].getCells()[5].setValue("0.000");
				oModel.create("/DraftitemsSet", cartData, {
					success: function(oData, oResponse) {
						oModel.read("/CheckflagSet('X')", {
							success: function(r) {
								oJSONModel.setProperty("/Flag", r);
								oJSONModel.refresh("true");
								MessageToast.show("Item added to cart");
								sap.ui.core.BusyIndicator.hide();
							}

						});
						// to update the table with the new item created  
						oModel.read("/DraftitemsSet", {
							success: function(r, s) {

								oJSONModel.setProperty("/cartModel", r.results);
								sap.ui.core.BusyIndicator.hide();
							}
						});
						oJSONModel.refresh(true);
					},
					error: function() {
						sap.ui.core.BusyIndicator.hide();
					}
				});

			}
		}

	});
});