sap.ui.define([
	"pr/req/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageBox"
], function(BaseController, JSONModel, Filter, MessageBox) {
	"use strict";

	return BaseController.extend("pr.req.controller.App", {
		// To set the count of cart during initial load
		onInit: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oModel.read("/CheckflagSet('X')", {
				success: function(r) {
					var data = r;
					oJSONModel.setProperty("/Flag", data);
				},
				error: function() {
					MessageBox.error("Unable to retrieve data for flag. Please try again.");
				}
			});
		}
	});
});