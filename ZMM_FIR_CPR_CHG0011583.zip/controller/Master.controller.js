/*global history */
sap.ui.define([
	"pr/req/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"pr/req/model/formatter",
	"sap/m/MessageBox",
	"sap/m/MessageToast"

], function(BaseController, JSONModel, History, Filter, FilterOperator, GroupHeaderListItem, Device, formatter, MessageBox, MessageToast) {
	"use strict";

	return BaseController.extend("pr.req.controller.Master", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the master list controller is instantiated. It sets up the event handling for the master/detail communication and other lifecycle tasks.
		 * @public
		 */
		onInit: function() {

			this.getOwnerComponent().getRouter().getRoute("master").attachPatternMatched(this._onPatternMatched, this);
		},

		_onPatternMatched: function() {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oJSONModel.refresh(true);
//commented the code for defect 1382
			 this.populateCatalogMtrlGrp();
			// this.populateCatalogMnfr();
			// this.populateCatalogMnfrPrtNo();
//commented the code for defect 1382
			this.populateEqpRecords();
			this.favorites();
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */
		//  called on  to fill Material Group in Filter
		populateCatalogMtrlGrp: function() {
			this._oTable = this.getView("table");
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			//oJSONModel.setSizeLimit(20000);
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/SearchmatgrpSet", {
				success: function(r) {
					var matgrp = r.results;
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/MatgrpModel", matgrp);
					// var aData = oJSONModel.getProperty("/MatgrpModel");
					// oJSONModel.setSizeLimit(aData.length);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get Material Data. Please try again.");
				}
			});
		},
		// called to fill Manufacture in Catalogs filter
		populateCatalogMnfr: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show();
			oModel.read("/SearchmanfSet", {
				success: function(r) {
					var manf = r.results;
					oJSONModel.setProperty("/ManufModel", manf);
					// var aData = oJSONModel.getProperty("/ManufModel");
					// oJSONModel.setSizeLimit(aData.length);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get manufacture Data. Please try again.");
				}
			});
		},
		// called to fill manufacture part num in Catalogs filter
		populateCatalogMnfrPrtNo: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show();
			oModel.read("/SearchmfrpnSet", {
				success: function(r) {
					var mnfprtNo = r.results;
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/MnfPrtNoModel", mnfprtNo);
					// var aData = oJSONModel.getProperty("/MnfPrtNoModel");
					// oJSONModel.setSizeLimit(aData.length);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get Manufacture part records. Please try again.");
				}
			});
		},
		// called to fill equipment description for equipment filter
		populateEqpRecords: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			// oModel.read("/searchequtxSet", {
			// 	success: function(r) {
			// 		var EqpDsc = r.results;
			// 		sap.ui.core.BusyIndicator.hide();
			// 		oJSONModel.setProperty("/EqpmntModel", EqpDsc);
			// 	},
			// 	error: function() {
			// 		sap.ui.core.BusyIndicator.hide();
			// 		MessageToast.show("Unable to get Equipment Description records. Please try again.");
			// 	}
			// });
			// PM assebly
			sap.ui.core.BusyIndicator.show();
			oModel.read("/PmassemblySet", {
				success: function(r) {
					var PmAssm = r.results;
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/PmaModel", PmAssm);
					// var aData = oJSONModel.getProperty("/PmaModel");
					// oJSONModel.setSizeLimit(aData.length);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get Equipment Description records. Please try again.");
				}
			});
		},
		// called to set the count for favorites
		favorites: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var oview = this;
			oModel.read("/CheckflagSet('F')", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/favCount", r);
					oview.byId("FavList").setInfo(r.Count);
				}
			});
		},
		// on Create item list press navigation
		onCreateItemPressed: function() {

			var item = "itemname";
			this.getRouter().navTo("createItem", {
				itemname: item

			});
			var n = this.getOwnerComponent().getModel("json").getData().tablebindingModel.length;
			for (var i = 0; i < n; i++) {
				this.getOwnerComponent()._oViews._oViews["pr.req.view.Detail"].byId("table").getItems()[i].getCells()[6].setValue("");
			}
		},
		// on Previous requisition list press navigates to the requisitions screen		
		onPrevReqListPress: function() {
			var prevId = "prevId";
			this.getRouter().navTo("previous", {
				prevId: prevId
			});
			var n = this.getOwnerComponent().getModel("json").getData().tablebindingModel.length;
			for (var i = 0; i < n; i++) {
				this.getOwnerComponent()._oViews._oViews["pr.req.view.Detail"].byId("table").getItems()[i].getCells()[6].setValue("");
			}
		},
		// on Favorites list press navigates to Favorite view
		onFavListPress: function(oEvent) {
			var fav = "favId";
			this.getRouter().navTo("favorite", {
				favId: fav
			});
			var n = this.getOwnerComponent().getModel("json").getData().tablebindingModel.length;
			for (var i = 0; i < n; i++) {
				this.getOwnerComponent()._oViews._oViews["pr.req.view.Detail"].byId("table").getItems()[i].getCells()[6].setValue("");
			}

		},

		// Handler for the filter criteria, which is set by the user 
		onFilterCatalogConfirm: function(oEvent) {
			this._oTable = this.getView().byId("table");
			var params = oEvent.getParameters();
			//setting filter items to call the service
			var aFilterItems = params.filterItems;
			var iLength = aFilterItems.length;
			var aFilter = [];
			for (var i = 0; i < iLength; i++) {
				if (params.filterItems[i].mBindingInfos.key.binding.sPath == "Matkl") {
					if (params.filterItems[i].mBindingInfos.key.binding.oValue) {
						aFilter.push(new sap.ui.model.Filter(
							"Matkl",
							sap.ui.model.FilterOperator.EQ, params.filterItems[i].mBindingInfos.key.binding.oValue
						));
					}
				}
				if (params.filterItems[i].mBindingInfos.key.binding.sPath == "Mfrnr") {
					if (params.filterItems[i].mBindingInfos.key.binding.oValue) {
						aFilter.push(new sap.ui.model.Filter(
							"Mfrnr",
							sap.ui.model.FilterOperator.EQ, params.filterItems[i].mBindingInfos.key.binding.oValue
						));
					}
				}
				if (params.filterItems[i].mBindingInfos.key.binding.sPath == "Mfrpn") {
					if (params.filterItems[i].mBindingInfos.key.binding.oValue) {
						aFilter.push(new sap.ui.model.Filter(
							"Mfrpn",
							sap.ui.model.FilterOperator.EQ, params.filterItems[i].mBindingInfos.key.binding.oValue
						));
					}
				}
			}
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var oModel = this.getView().getModel();
			var that = this;
			sap.ui.core.BusyIndicator.show(0);
			// calling service with user input filters to get table records
			oModel.read("/SearchItemsSet", {
				filters: aFilter,
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/tablebindingModel", r.results);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			});
			var objId = "objectId";
			this.getRouter().navTo("object", {
				objectId: objId
			});
		},

		// Filter criteria for the Equipment 		
		onFilterEquipConfirm: function(oEvent) {
			var params = oEvent.getParameters();
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			// var aFilterItems = params.filterItems;
			var aFilterItems = params.selectedItems;
			var iLength = aFilterItems.length;
			var aFilter = [];
			for (var i = 0; i < iLength; i++) {
				// if (params.filterItems[i].mBindingInfos.key.binding.sPath == "Equnr") {
				// 	if (params.filterItems[i].mBindingInfos.key.binding.oValue) {
				// 		aFilter.push(new sap.ui.model.Filter(
				// 			"Eqktx",
				// 			sap.ui.model.FilterOperator.EQ, params.filterItems[i].mBindingInfos.key.binding.oValue
				// 		));
				// 	}
				// }
				// if (params.filterItems[i].mBindingInfos.key.binding.sPath == "Matnr") {
				// 	if (params.filterItems[i].mBindingInfos.key.binding.oValue) {
				// 		aFilter.push(new sap.ui.model.Filter(
				// 			"Ematnr",
				// 			sap.ui.model.FilterOperator.EQ, params.filterItems[i].mBindingInfos.key.binding.oValue
				// 		));
				// 	}
				// }
				if (aFilterItems[i].getBindingContext("json").getObject().Matnr) {
					aFilter.push(new sap.ui.model.Filter(
						"Ematnr",
						sap.ui.model.FilterOperator.EQ, aFilterItems[i].getBindingContext("json").getObject().Matnr
					));
				}
			}
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/SearchItemsSet", {
				filters: aFilter,
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/tablebindingModel", r.results);
					oJSONModel.refresh(true);
				}
			});
			var objId = "objectId";
			this.getRouter().navTo("object", {
				objectId: objId
			});
		},

		////on Catalog press  opens a filter dialog////
//commented the code for defect 1382
		// onCatalogsListPress: function(oEvent) {
		// 	if (!this._oCatalogDialog) {
		// 		this._oCatalogDialog = sap.ui.xmlfragment("pr.req.view.fragment.CatalogDialog", this);
		// 		this.getView().addDependent(this._oCatalogDialog);
		// 		// forward compact/cozy style into Dialog
		// 		this._oCatalogDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
		// 	}
		// 	this._oCatalogDialog.open();
		// },
//commented the code for defect 1382

		///on Equipment Press///
		onEquipmentListPress: function() {

			if (!this._oEquipDialog) {
				this._oEquipDialog = sap.ui.xmlfragment("pr.req.view.fragment.EquipmentList", this);
				this.getView().addDependent(this._oEquipDialog);
			}
			var oBinding = this._oEquipDialog.getBinding("items");
			oBinding.filter([]);
			this._oEquipDialog.open();
		},

		// To Navigate to previous view
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},

		// To Handle Equipment Search
		handleEquipSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter =
				new Filter({
					filters: [

						new Filter({
							path: "Equnr",
							operator: FilterOperator.Contains,
							value1: sValue
						}),
						new Filter({
							path: "Eqktx",
							operator: FilterOperator.Contains,
							value1: sValue
						}),
						new Filter({
							path: "Matnr",
							operator: FilterOperator.Contains,
							value1: sValue
						}),
						new Filter({
							path: "Maktx",
							operator: FilterOperator.Contains,
							value1: sValue
						})

					],
					and: false
				});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		}
	});
});