/*eslint linebreak-style: ["error", "windows"]*/
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"zfir_mm_srv/model/formatter"
], function(Controller, History, Filter, formatter) {
	"use strict";

	return Controller.extend("zfir_mm_srv.controller.Detail", {

		formatter: formatter,

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf zfir_mm_srv.view.view.Detail

		 */
		onInit: function() {

			var oRouter = this.getRouter();
			oRouter.getRoute("detail").attachMatched(this._onRouteMatched, this);

		},

		/**
		 * called to get router instance
		 */
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		/**
		 * called on navigation to Master view
		 */
		onBack: function() {
			var oHistory = History.getInstance();
			var oPrevHash = oHistory.getPreviousHash();
			if (oPrevHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("overview", true);
			}
		},

		/**
		 *called on Add New Service
		 */
		onAdd: function() {
			if (!this.addDialog) {
				this.addDialog = sap.ui.xmlfragment("zfir_mm_srv.view.AddItem", this);
				this.getView().addDependent(this.addDialog);
			}
			this.addDialog.open();
			sap.ui.getCore().byId("shTextId").setValue("");
			sap.ui.getCore().byId("shTextId").setValueState("None");
			sap.ui.getCore().byId("qtyId").setValue("");
			sap.ui.getCore().byId("qtyId").setValueState("None");
			sap.ui.getCore().byId("uom").setSelectedKey("");
			sap.ui.getCore().byId("uom").setValueState("None");
			sap.ui.getCore().byId("grosValId").setValue("");
			sap.ui.getCore().byId("grosValId").setValueState("None");
			sap.ui.getCore().byId("grosValId").setValueState("None");
		},

		/**
		 * called when item is selected
		 **/
		onPress: function(oEvent) {
			if (!this._oRemoveItem) {
				this._oRemoveItem = sap.ui.xmlfragment("zfir_mm_srv.view.RemoveItem", this);
				this.getView().addDependent(this._oRemoveItem);
			}

			var oValue = oEvent.getParameters().listItem.getBindingContext("json").getObject();
			if (!oValue) {
				this._oRemoveItem.close();
			} else {
				if (!oValue.InputQty) {
					var JSONModel = this.getOwnerComponent().getModel("json");
					var oReset = [];
					JSONModel.setProperty("/Index", oReset);
					JSONModel.setProperty("/Index", oValue);
					var oTableData = this.getOwnerComponent().getModel("json").getData().TableDataModel;
					oTableData.splice(oTableData.indexOf(oValue), 1);
					JSONModel.setProperty("/TableDataModel", oTableData);
					var oTable = this.byId("itemsTable");
					oTable.getModel().refresh();
					var oTable = this.byId("itemsTable");
					sap.ui.getCore().byId("rshTextId").setValue(oValue.ShortText);
					sap.ui.getCore().byId("rshTextId").setValueState("None");
					sap.ui.getCore().byId("rqtyId").setValue(oValue.Quantity);
					sap.ui.getCore().byId("rqtyId").setValueState("None");
					sap.ui.getCore().byId("ruom").setSelectedKey(oValue.BaseUom);
					sap.ui.getCore().byId("ruom").setValueState("None");
					if (oValue.Quantity && oValue.GrossVal) {
						sap.ui.getCore().byId("rgrosValId").setValue((oValue.GrossVal / oValue.Quantity).toFixed(2));
					} else {
						sap.ui.getCore().byId("rgrosValId").setValue("0.00");
					}
					sap.ui.getCore().byId("rgrosValId").setValueState("None");
					sap.ui.getCore().byId("ebelpn").setValue(oValue.Ebelp);
					this._oRemoveItem.open();
				} else {
					sap.m.MessageToast.show("Not an unplanned service!!Only Unplanned service can be changed!!");
				}
			}
		},

		/*
		 * called on Cancel from pop-up
		 */
		onAddItemCancel: function() {
			this.addDialog.close();
			this._oRemoveItem.close()
		},

		/**
		 * called on Save from pop-up
		 */

		onRemoveItemDelete: function(oEvent) {
			this._oRemoveItem.close();
		},
		/**
		 * called on Save from pop-up
		 */
		onAddItemSave: function(oEvent) {
			//get values entered on pop-up
			var oShortText = sap.ui.getCore().byId("shTextId").getValue();
			var oQty = sap.ui.getCore().byId("qtyId").getValue();
			var oGrosVal = sap.ui.getCore().byId("grosValId").getValue();
			var oValue = sap.ui.getCore().byId("ebelpn").getValue();
			//validations
			var canContinue = true;
			if (sap.ui.getCore().byId("shTextId").getValue() === "") {
				sap.ui.getCore().byId("shTextId").setValueState("Error");
				sap.ui.getCore().byId("shTextId").setValueStateText("Please enter the Text");
				canContinue = false;
			}
			if (sap.ui.getCore().byId("qtyId").getValue() === "") {
				sap.ui.getCore().byId("qtyId").setValueState("Error");
				sap.ui.getCore().byId("qtyId").setValueStateText("Enter Quantity");
				canContinue = false;
			}
			if (sap.ui.getCore().byId("grosValId").getValue() === "") {
				sap.ui.getCore().byId("grosValId").setValueState("Error");
				sap.ui.getCore().byId("grosValId").setValueStateText("Enter Gross Value");
				canContinue = false;
			}
			if (sap.ui.getCore().byId("uom").getSelectedKey() === "") {
				sap.ui.getCore().byId("uom").setValueState("Error");
				sap.ui.getCore().byId("uom").setValueStateText("Enter Unit of Measure");
				canContinue = false;
			}
			//get table instance
			var oTable = this.byId('itemsTable');
			//get BaseUom for description 

			var oUom;
			var oPkg;
			var oEbelpMax;
			var oEbelpNewN;
			var oEbelpNewN;
			var oEbelpNewS;
			var oEbeln;
			var tabMod = this.getOwnerComponent().getModel("json").getData().TableDataModel;
			this.getOwnerComponent().getModel("json").getData().TableDataModel.sort(function(a, b) {
				return parseInt(b.Ebelp) - parseFloat(a.Ebelp);
			});
			var maxIndex = this.getOwnerComponent().getModel("json").getData().TableDataModel.length;
			var oLine1 = this.getOwnerComponent().getModel("json").getData().TableDataModel[0];
			if (oLine1 !== undefined) {
				oUom = sap.ui.getCore().byId("uom").getSelectedKey();
				oPkg = oLine1.PckgNo;
				oEbelpMax = oLine1.Ebelp;
				oEbelpNewN = parseInt(oEbelpMax);
				oEbelpNewN = oEbelpNewN + 10;
				oEbelpNewS = '' + oEbelpNewN;
				oEbelpNewS = '000' + oEbelpNewS;
				oEbeln = this.getOwnerComponent().getModel("json").getData().Ebeln[0].Ebeln;
			} else {
				oUom = sap.ui.getCore().byId("uom").getSelectedKey();
				oPkg = "";
				oEbelpNewS = "00010";
				oEbeln = this.getOwnerComponent().getModel("json").getData().Ebeln[0].Ebeln;
			}

			var newItem = {}
			newItem.Ebeln = oEbeln;
			newItem.Ebelp = oEbelpNewS;
			newItem.ShortText = oShortText;
			newItem.Quantity = oQty;
			newItem.BaseUom = oUom;
			if (oGrosVal && oQty) {
				newItem.GrossVal = (oGrosVal * newItem.Quantity).toFixed(2);
			}
			newItem.HeaderText = "";
			newItem.PckgNo = oPkg;
			//update binding with the new object 
			if (canContinue === true) {
				var updateModel = this.getOwnerComponent().getModel("json").getData().TableDataModel.unshift(newItem);
				this.getOwnerComponent().getModel("json").refresh(true);
				this.addDialog.close();
			}
		},

		/**
		 * on save from remove fragment
		 **/
		onRemoveItemSave: function(oEvent) {
			//get values entered on pop-up
			var oShortText = sap.ui.getCore().byId("rshTextId").getValue();
			var oQty = sap.ui.getCore().byId("rqtyId").getValue();
			var oGrosVal = sap.ui.getCore().byId("rgrosValId").getValue();
			var oValue = sap.ui.getCore().byId("ebelpn").getValue();
			//validations
			var canContinue = true;
			if (sap.ui.getCore().byId("rshTextId").getValue() === "") {
				sap.ui.getCore().byId("rshTextId").setValueState("Error");
				sap.ui.getCore().byId("rshTextId").setValueStateText("Please enter the Text");
				canContinue = false;
			}
			if (sap.ui.getCore().byId("rqtyId").getValue() === "") {
				sap.ui.getCore().byId("rqtyId").setValueState("Error");
				sap.ui.getCore().byId("rqtyId").setValueStateText("Enter Quantity");
				canContinue = false;
			}
			if (sap.ui.getCore().byId("rgrosValId").getValue() === "") {
				sap.ui.getCore().byId("rgrosValId").setValueState("Error");
				sap.ui.getCore().byId("rgrosValId").setValueStateText("Enter Gross Value");
				canContinue = false;
			}
			if (sap.ui.getCore().byId("ruom").getSelectedKey() === "") {
				sap.ui.getCore().byId("ruom").setValueState("Error");
				sap.ui.getCore().byId("ruom").setValueStateText("Enter Unit of Measure");
				canContinue = false;
			}
			//get table instance
			var oTable = this.byId('itemsTable');
			//get BaseUom for description 

			var oUom;
			var oPkg;
			var oEbelpNewS;
			var oEbeln;
			var oLine1 = this.getOwnerComponent().getModel("json").getData().TableDataModel[0];
			if (oLine1 !== undefined) {
				oUom = sap.ui.getCore().byId("uom").getSelectedKey();
				oPkg = oLine1.PckgNo;
				oEbelpNewS = oValue;
				oEbeln = this.getOwnerComponent().getModel("json").getData().Ebeln[0].Ebeln;
			} else {
				oUom = sap.ui.getCore().byId("uom").getSelectedKey();
				oPkg = "";
				oEbelpNewS = "00010";
				oEbeln = this.getOwnerComponent().getModel("json").getData().Ebeln[0].Ebeln;
			}

			var newItem = {}
			newItem.Ebeln = oEbeln;
			newItem.Ebelp = oEbelpNewS;
			newItem.ShortText = oShortText;
			newItem.Quantity = oQty;
			newItem.BaseUom = oUom;
			if (oGrosVal && oQty) {
				newItem.GrossVal = (oGrosVal * newItem.Quantity).toFixed(2);
			}
			newItem.HeaderText = "";
			newItem.PckgNo = oPkg;
			//update binding with the new object 
			if (canContinue === true) {
				var updateModel = this.getOwnerComponent().getModel("json").getData().TableDataModel.unshift(newItem);
				this.getOwnerComponent().getModel("json").refresh(true);
				this._oRemoveItem.close();
			}
		},
		/**
		 * called on Quantity Change
		 */
		 onChangeQty: function(oEvent) {
          var oValue = oEvent.getParameter("value"); //Get the Input Value
          var oItem = oEvent.getSource().getParent(); //Get the Item
          var oInput = oEvent.getSource(); //Get the Input
          var oBindingValue = oInput.getBinding("value"); //Get value binding of Input
          //Get the model property.
          var  oInputPath =  oBindingValue.getPath() //Model Path
          var  oItemPath = oBindingValue.getContext().getPath(); //Item Path
          var oTableModel = this.getOwnerComponent().getModel("json"); //Target Model
          oTableModel.setProperty(oItemPath + "/" + oInputPath + "/", oValue); //Set the property
        },
		/**
		 * called on SAVE
		 */
		onSave: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel("json").getData().TableDataModel;
			var oTable = this.byId("itemsTable").getItems();
			//store all the context/contextPath of the table in an array
			var oMaster = {};
			var oItemData = [];
			var complete = this.byId("complete").getSelected();
			for (var i = 0; i < oModel.length; i++) {
				if (oMaster.Ebeln == null) {
					// create header			
					oMaster.Ebeln = oModel[i].Ebeln;
					oMaster.Ebelp = this.getOwnerComponent().getModel("json").getData().Ebeln[0].Ebelp;
					oMaster.Name1 = "abc";
					oMaster.FinEntry = complete;
				}
				//create item 
				var oDetail = {};
				var flagnoitem;
				oDetail.Ebeln = oModel[i].Ebeln;
				oDetail.Ebelp = oModel[i].Ebelp;
				if (oModel[i].Quantity) {
					oDetail.Quantity = oModel[i].Quantity;
				} else {
					oDetail.Quantity = "0.00";
				}
				oDetail.BaseUom = oModel[i].BaseUom;
				oDetail.GrossVal = oModel[i].GrossVal;
				oDetail.OpenQty = oModel[i].OpenQty;
				oDetail.InputQty = oModel[i].InputQty;
				oDetail.ShortText = oModel[i].ShortText;
				oDetail.HeaderText = this.byId("st").getValue();
				oDetail.PckgNo = oModel[i].PckgNo;
				oDetail.FlagOpen = oModel[i].FlagOpen;
				oDetail.Flagnolimit = oModel[i].Flagnolimit;
				oDetail.ShortText = oModel[i].ShortText;
				//get reference number
				oDetail.ExtNumber = this.byId("ref").getValue();
				oItemData.push(oDetail);
			}

			// insert item data into header data
			oMaster.nav_htoi = oItemData;
			//check if flagnoitem is set meaning there is no item available for posting
			//get model instance
			var oModelMain = this.getOwnerComponent().getModel();
			//set http header with tokem fetch
			oModelMain.setHeaders({
				"Access-Control-Allow-Origin": "*",
				"Content-Type": "application/x-www-form-urlencoded",
				"X-CSRF-Token": "Fetch"
			});
			//fetch token and get reponse
			var token;
			oModelMain.read('/SesHeaderSet', null, null, false, function(oData, oResponse) {
						token = oResponse.headers['x-csrf-token'];

					},
					function() {
						sap.m.MessageToast.show("Data not found!!");
					})
				//set http header for POST rest with token fetched from read
			oModelMain.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/json",
				"DataServiceVersion": "2.0",
				"Accept": "application/atom+xml,application/atomsvc+xml,application/xml",
				"X-CSRF-Token": token
			});
			//call POST method
			sap.ui.core.BusyIndicator.show();
			var that = this;
			oModelMain.create("/SesHeaderSet", oMaster, {
				success: function(oData, oResponse) {
					// Success
					sap.ui.core.BusyIndicator.hide();
					var oMsg = oResponse.headers;
					var oEsheet = oResponse.data.Name1;
					var jsonStr = oMsg["sap-message"];
					sap.m.MessageToast.show((JSON.parse(jsonStr).message));
					//add create operation for uploading files to backend
					var oFileName = that.byId("attach");
					if (oFileName.getValue()) {
						var sPath = "/sap/opu/odata/sap/ZMM_ODATA_CSES_NEW_SRV/SesAttachSet";
						var sFileVal = oFileName.getValue();
						var sEbeln = oMaster.Ebeln;
						var sUrl = sPath + "(Filename='" + sFileVal + "',Ebeln='" + sEbeln + "')/$value";
						oFileName.setUploadUrl(sUrl);
						oFileName.setSendXHR(true);
						//add header parameters
						that.getOwnerComponent().getModel().refreshSecurityToken();
						var file = jQuery.sap.domById(oFileName.getId() + "-fu").files[0];
						var base64_marker = 'data:' + file.type + ';base64,';
						var reader = new FileReader();
						reader.onload = (function(theFile) {
							return function(evt) {
								var base64Index = evt.target.result.indexOf(base64_marker) + base64_marker.length;
								var base64 = evt.target.result.substring(base64Index);
								var token = that.getOwnerComponent().getModel().getHeaders()['x-csrf-token'];
								$.ajaxSetup({
									cache: false
								});

								jQuery.ajax({
									url: sPath,
									async: false,
									dataType: 'json',
									cache: false,
									data: base64,
									type: "POST",
									beforeSend: function(xhr) {
										xhr.setRequestHeader("X-CSRF-Token", token);
										xhr.setRequestHeader("Content-Type", file.type);
										xhr.setRequestHeader("slug", sFileVal + "," + oEsheet + "," + file.name);
									},
									success: function(odata) {
										oFileName.setValue("");
									}
								});
							};
						})(file);
						reader.readAsDataURL(file);

					} //get value from file if condition
					that.getRouter().navTo("master");
					sap.m.MessageToast.show((JSON.parse(jsonStr).message));
				},
				error: function(oError) {
					// Error
					sap.ui.core.BusyIndicator.hide();
					jQuery.sap.require("sap.m.MessageBox");
					sap.m.MessageBox.show((JSON.parse(oError.responseText).error.message.value), {
						icon: sap.m.MessageBox.Icon.Information,
						title: "Message Box"
					});
				}
			});
		},
		/**
		 * search help for service master
		 */
		//addf4 valuehelp for Storage Locations
		handleValueHelpSr: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._oSRf4) {
				this._oSRf4 = sap.ui.xmlfragment(
					"zfir_mm_srv.view.SRf4",
					this
				);
				this.getView().addDependent(this._oSRf4);
			}
			// create a filter for the binding
			this._oSRf4.getBinding("items").filter([new Filter(
				"Asktx",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);
			// open value help dialog filtered by the input value
			this._oSRf4.open(sInputValue);
		},
		_handleValueHelpSearch: function(evt) {
			var oDialog = evt.getParameter("id");
			var sValue = evt.getParameter("value");
			var oFilter;
			if (oDialog === "srd") {
				oFilter = new Filter(
					"Asktx",
					sap.ui.model.FilterOperator.Contains, sValue
				);
			}
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpClose: function(evt) {
			var srvInput;
			var oDialog = evt.getParameter("id");
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				if (oDialog === "srd") {
					srvInput = sap.ui.getCore().byId("shTextId");
					srvInput.setValue(oSelectedItem.getTitle());
				}
			}
			evt.getSource().getBinding("items").filter([]);
		},
		/**
		 *called for route matching
		 */
		_onRouteMatched: function(oEvent) {
			//get the argument value and set it as path for fetching associated values
			var oArgs, oView;
			oArgs = oEvent.getParameter("arguments");
			oView = this.getView();
			var oEbeln = ("Ebeln=" + "'" + oArgs.ebeln + "'");
			var oEbelp = ("Ebelp=" + "'" + oArgs.ebelp + "'");
			var sObjectPath = ("(" + oEbeln + "," + oEbelp + ")");
			var oModel = this.getOwnerComponent().getModel();
			var JSONModel = this.getOwnerComponent().getModel("json");
			var that = this;
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/SesHeaderSet" + sObjectPath, {
				urlParameters: {
					$expand: "nav_htoi"
				},
				success: function(r) {
					var data = r.nav_htoi.results;
					if (data) {
						var oButton = that.byId("editButton");
						oButton.setEnabled(data[0].FlagNolimit);
						if (!data[0].Ebeln) {
							data = [];
						}
					}
					JSONModel.setProperty("/TableDataModel", data);
					var oTitle = that.byId("title");
					var oSt = that.byId("st").setValue("");
					var oRef = that.byId("ref").setValue("");
					var oComplete = that.byId("complete").setSelected("");
					oTitle.setText("Order - " + oArgs.ebeln + " / " + oArgs.ebelp);
					var sEbeln = [];
					var sOdata = {};
					sOdata.Ebeln = oArgs.ebeln;
					sOdata.Ebelp = oArgs.ebelp;
					sEbeln.push(sOdata);
					JSONModel.setProperty("/Ebeln", sEbeln);
					sap.ui.core.BusyIndicator.hide(0);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("Data not found!!");
				}
			});
		}
	});
});