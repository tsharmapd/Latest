sap.ui.define([
	], function () {
		"use strict";

		return {
			/**
			 * Rounds the currency value to 2 digits
			 *
			 * @public
			 * @param {string} sValue value to be formatted
			 * @returns {string} formatted currency value with 2 digits
			 */
			currencyValue : function (sValue) {
				if (!sValue) {
					return "";
				}

				return parseFloat(sValue).toFixed(2);
			},
			statusText: function (sValue) {
				if (sValue === "Drilling") {
					return "Success";
				}
				else if (sValue === "Racked" || sValue === "Stacked"  ) {
					return "Error";
				}
				else if (sValue === "Moving") {
					return "Warning";
				}
			},
			rigValue: function(sValue) {
				try {
					return sValue.length > 3 ? sValue.substring(sValue.length - 3) : sValue;
				} catch (e) {
					return sValue;
				}
			}
		};

	}
);