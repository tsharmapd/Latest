sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"pr/req/v2/model/formatter"
], function(Controller, MessageToast, MessageBox, formatter) {
	"use strict";

	return Controller.extend("pr.req.v2.controller.Favorite", {
		formatter: formatter,
		onInit: function() {

		},

		/// router for navigation	
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		// navigates back to previous screen		
		onFavNavBack: function() {
			var objId = "objectId";
			this.getRouter().navTo("object", {
				objectId: objId
			});
		},
		// to get the quantity value
		handleChange: function(oEvent) {
			var that = this;
			var qty = oEvent.getSource().getValue();
			var oJSONModel = that.getOwnerComponent().getModel("json");
			oJSONModel.setProperty("/favQty", qty);

		},
		// to set the count of table
		onListUpdateFinished: function(oEvent) {
			var sTitle,
				fOrderTotal = 0,
				iTotalItems = oEvent.getParameter("total"),
				oJSONModel = this.getOwnerComponent().getModel("json");
			if (oEvent.getSource().getBinding("items").isLengthFinal()) {
				if (iTotalItems) {
					sTitle = this.byId("lineItemsHeader").setText("Fav Items (" + iTotalItems + ")");
				} else {
					//Display 'Line Items' instead of 'Line items (0)'
					sTitle = this.byId("lineItemsHeader").setText("Fav Items(0)");
				}
			}
		},
		// called to set the cart data
		onFavShoppingCartPressed: function(oEvent) {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show();
			this.getOwnerComponent().getModel().read("/DraftitemsSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/cartModel", r.results);
				}
			});
			// to open shopping cart fragment
			if (!this.oFavcartPress) {
				this.oFavcartPress = sap.ui.xmlfragment("pr.req.v2.view.fragment.ShoppingCart", this);
				this.getView().addDependent(this.oFavcartPress);
				this.oFavcartPress.setModel(oJSONModel);
				oJSONModel.refresh();
			}
			this.oFavcartPress.setModel(oJSONModel);
			oJSONModel.refresh();
			this.oFavcartPress.open();
		},
		/// to delete the items from cart 
		onDeletePressed: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var selctdItem = oEvent.getParameter("listItem").getBindingContext("json").getObject();
			var olinenum = selctdItem.Ebelp;
			var Guid = selctdItem.Guid;
			//	sap.ui.core.BusyIndicator.show(0);
			oModel.remove("/DraftlineSet(Guid='" + Guid + "',Ebelp='" + olinenum + "')", {
				success: function(data, response) {
					sap.ui.core.BusyIndicator.hide();
					oModel.read("/DraftitemsSet", {
						success: function(r, s) {
							oJSONModel.setProperty("/cartModel", r.results);
						}
					});
					MessageToast.show("Draft item successfully removed from cart");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
						}
					});
					oJSONModel.refresh("true");
				}
			});
		},

		///// cart dialog cancel closes dialog
		cancel: function() {
			this.oFavcartPress.close();
		},
		//// navigation on View cart press on cart dialog
		ViewCart: function(oEvt) {
			var cartId = "cartId";
			this.getOwnerComponent().getRouter().navTo("cart", {
				cartId: cartId
			});
		},

		// quick view  opens with product details
		onFavQckviewPressed: function(oEvent) {
			if (!this.oQckVwdialog) {
				this.oQckVwdialog = sap.ui.xmlfragment("pr.req.v2.view.fragment.qckViewFavorite", this);
			}
			var sObject = oEvent.getSource().getBindingContext().getObject();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oJSONModel.setProperty("/QckvwModel", sObject);
			this.oQckVwdialog.setModel(oJSONModel);
			this.oQckVwdialog.bindElement("/QckvwModel");
			this.oQckVwdialog.openBy(oEvent.getSource());
		},
		// To unfavorite the fav Item		
		toUnFavoriteItem: function(oEvent) {
			var pressedstate = oEvent.getSource().getPressed();
			if (pressedstate == false) {
				var oModel = this.getOwnerComponent().getModel();
				var oJSONModel = this.getOwnerComponent().getModel("json");
				var unfavObj = oEvent.getSource().getBindingContext().getObject();
				// var unfavorite = {};
				// unfavorite.Maktx = unfavObj.Maktx;
				var sMatnr = unfavObj.Matnr;
				var sParseMatnr = sMatnr.replace("#", "@");
				var sMatnrr = sParseMatnr.replace("/", "$");
				var sMatnrFinal = sMatnrr.replace(":", "_");
				var sPath = "/FavoriteSet(Matnr='" + sMatnrFinal + "')";
				var that = this;
				sap.ui.core.BusyIndicator.show(0);
				oModel.remove(sPath, {
					success: function(oData, oResponse) {
						sap.ui.core.BusyIndicator.hide();
						MessageToast.show("Item removed from favorites");
						oModel.read("/CheckflagSet('F')", {
							success: function(r) {
								oJSONModel.setProperty("/favCount", r);
								that.getOwnerComponent()._oViews._oViews["pr.req.v2.view.Master"].byId("FavList").setInfo(r.Count);
								oJSONModel.refresh(true);
							}
						});
					},
					error: function() {
						sap.ui.core.BusyIndicator.hide();
					}
				});
			}
		},

		//on add favorite item to cart
		onFavAddToCartPressed: function(oEvent) {
			//get item count in cart
			var count = this.getOwnerComponent()._oViews._oViews["pr.req.v2.view.Detail"].byId("headerCartBtn").getText();
			if (count >= 100) {
				var flagC = false;
			} else {
				flagC = true;
			}
			if (flagC) {
				// to get the object from event
				var objData = oEvent.getSource().getBindingContext().getObject();
				var oModel = this.getOwnerComponent().getModel();
				var oJSONModel = this.getOwnerComponent().getModel("json");
				var that = this;
				var i = oEvent.getSource().getParent().getParent().getParent().indexOfItem(oEvent.getSource().getParent().getParent());
				var oMenge = oEvent.getSource().getParent().getParent().getParent().getItems()[i].getCells()[6].getValue();
				if (oMenge === "0" || oMenge < 1 || oMenge === "") {
					MessageBox.warning("Quantity should not be Empty or Zero");
				} else {

					//setting cartdata payload for create
					var cartData = {};
					cartData.Ebelp = "00010";
					cartData.Maktx = objData.Maktx;
					cartData.Matkl = objData.Matkl;
					cartData.Matnr = objData.Matnr;
					cartData.Menge = oJSONModel.getData().favQty;
					cartData.Mfrnr = objData.Mfrnr;
					cartData.Uom = objData.Uom;
					cartData.Verpr = objData.Verpr;
					cartData.Wgbez = objData.Wgbez;
					cartData.Image = objData.Img;
					cartData.Waers = objData.Waers;
					cartData.Text1 = objData.Text;
					var eQty = "0.000";
					oEvent.getSource().getParent().getParent().getCells()[6].setValue("");
					sap.ui.core.BusyIndicator.show(0);
					oModel.create("/DraftitemsSet", cartData, {
						success: function(oData, oResponse) {
							objData.Menge = "0.000";
							that.getOwnerComponent().getModel().refresh("true");
							// to reset the qty to 0.000 after posting
							oJSONModel.setProperty("/favQty", eQty);
							oJSONModel.refresh("true");
							MessageToast.show("Item added to the cart");
							// to set the cart count after creating new item
							oModel.read("/CheckflagSet('X')", {
								success: function(r) {
									sap.ui.core.BusyIndicator.hide();
									oJSONModel.setProperty("/Flag", r);
									oJSONModel.refresh("true");
								}
							});

							// to update the table with the new item created  
							oModel.read("/DraftitemsSet", {
								success: function(r, s) {
									sap.ui.core.BusyIndicator.hide();
									oJSONModel.setProperty("/cartModel", r.results);
								}
							});

							oJSONModel.refresh("true");
						},
						error: function() {
							sap.ui.core.BusyIndicator.hide();
						}
					});
				}
			} else {
				MessageToast.show("Maximum item count(100) for the cart has acheived. No new item can be added to cart", {
					duration: 6000,
					width: "20em"
				});
			}
		}

	});
});