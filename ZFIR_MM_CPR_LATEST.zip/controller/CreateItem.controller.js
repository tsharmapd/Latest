sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/model/Filter"
], function(Controller, MessageBox, MessageToast, Filter) {
	"use strict";

	return Controller.extend("pr.req.v2.controller.CreateItem", {
		onInit: function() {
			this.byId("deldtId").setDateValue(new Date());
		},

		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		//Shopping cart press
		onCreateShoppingCartPressed: function(oEvent) {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show();
			this.getOwnerComponent().getModel().read("/DraftitemsSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/cartModel", r.results);
				}
			});
			// to open shopping cart fragment from favorite view	
			if (!this.ocartPress) {
				this.ocartPress = sap.ui.xmlfragment("pr.req.v2.view.fragment.ShoppingCart", this);
				this.getView().addDependent(this.ocartPress);
				this.ocartPress.setModel(oJSONModel);
				oJSONModel.refresh();
			}
			//setting model to the cart
			this.ocartPress.setModel(oJSONModel);
			oJSONModel.refresh();
			this.ocartPress.open();
		},
		validateInput: function(oEvent) {
			if (oEvent.getSource().getValue() !== "") {
				oEvent.getSource().setValueState("None");
			}
		},
		//material group selection
		handleLoadItems: function(oControlEvent) {
			oControlEvent.getSource().getBinding("items").resume();
		},
		stateChange: function(oEvent) {
			if (oEvent.getSource().getSelectedKey() !== "") {
				oEvent.getSource().setValueState("None");
			}
		},
		// called to add the created item to the favorites 
		onAddCreatedItemToFavPress: function() {
			//validations
			var canProceed = true;
			var shText = this.byId("shtextId");
			if (shText.getValue() === "") {
				shText.setValueState("Error");
				shText.setValueStateText("Enter short text");
				canProceed = false;
			}

			var qtyVal = this.byId("qtyId");
			if (qtyVal.getValue() === "" || qtyVal.getValue() === 0 || qtyVal.getValue() < 1) {
				qtyVal.setValueState("Error");
				qtyVal.setValueStateText("Invalid Quantity");
				canProceed = false;
			}
			var UomId = this.byId("UomId");
			if (UomId.getSelectedKey() === "") {
				UomId.setValueState("Error");
				UomId.setValueStateText("Enter Unit of Measure");
				canProceed = false;
			}
			var valPric = this.byId("valprId");
			if (valPric.getValue() === "") {
				valPric.setValueState("Error");
				valPric.setValueStateText("Enter Valuation Price");
				canProceed = false;
			}
			var omat = this.byId("matgrpId");
			if (omat.getSelectedKey() === "") {
				omat.setValueState("Error");
				canProceed = false;
			}
			var CrcyId = this.byId("crcyId");
			if (CrcyId.getSelectedKey() === "") {
				CrcyId.setValueState("Error");
				CrcyId.setValueStateText("Enter Unit of Measure");
				canProceed = false;
			}
			var date = this.byId("deldtId");
			if (date.getValue() === "") {
				date.setValueState("Error");
				date.setValueStateText("Enter delivery date");
				canProceed = false;
			}
			// when validations are satisfied
			if (canProceed) {
				var oModel = this.getOwnerComponent().getModel();
				var oJSONModel = this.getOwnerComponent().getModel("json");
				var crcyVal = CrcyId.getSelectedKey();
				var addToCart = {};
				addToCart.Maktx = shText.getValue();
				addToCart.Menge = qtyVal.getValue();
				addToCart.Uom = UomId.getSelectedKey();
				addToCart.Verpr = valPric.getValue();
				addToCart.Waers = crcyVal;
				addToCart.Wgbez = this.byId("matgrpId").getSelectedItem().getProperty("text");
				var matrlNum = oJSONModel.getData().Matrlnumber;
				addToCart.Matkl = this.byId("matgrpId").getSelectedKey();
				addToCart.Text = this.byId("cmntsId").getValue();
				var that = this;
				oModel.create("/FavoriteSet", addToCart, {
					success: function(oData, oResponse) {
						MessageToast.show("Item Added to Favorites");
						oModel.read("/CheckflagSet('F')", {
							success: function(r) {
								oJSONModel.setProperty("/favCount", r);
								// after adding create item to favorites , to set the favorites count on the master view
								that.getOwnerComponent()._oViews._oViews["pr.req.v2.view.Master"].byId("FavList").setInfo(r.Count);
								oJSONModel.refresh(true);
							}
						});
					},
					error: function() {
						sap.ui.core.BusyIndicator.hide();
					}
				});
			} else {
				MessageBox.warning("Please fill all the fields to add as favoite Item");
			}
		},
		// to refresh all the entries
		refreshCreateItem: function() {
			this.byId("shtextId").setValue("");
			this.byId("shtextId").setValueState("None");
			this.byId("qtyId").setValue("");
			this.byId("qtyId").setValueState("None");
			this.byId("UomId").setSelectedKey("");
			this.byId("UomId").setValueState("None");
			this.byId("valprId").setValue("");
			this.byId("valprId").setValueState("None");
			this.byId("deldtId").setDateValue(new Date());
			this.byId("deldtId").setValueState("None");
			this.byId("matgrpId").setSelectedKey("");
			this.byId("cmntsId").setValue("");
		},
		// to delete the draft items from the cart  
		onDeletePressed: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var selctdItem = oEvent.getParameter("listItem").getBindingContext("json").getObject();
			var olinenum = selctdItem.Ebelp;
			var Guid = selctdItem.Guid;
			//delete method to remove cart  items
			oModel.remove("/DraftlineSet(Guid='" + Guid + "',Ebelp='" + olinenum + "')", {
				success: function(data, response) {
					sap.ui.core.BusyIndicator.hide();
					oModel.read("/DraftitemsSet", {
						success: function(r, s) {
							oJSONModel.setProperty("/cartModel", r.results);
						}
					});
					MessageToast.show("Draft item successfully removed from cart");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
						}
					});
				}
			});
		},

		///// cart dialog cancel closes dialog
		cancel: function() {
			this.ocartPress.close();
		},
		//// navigation on View cart press on cart dialog
		ViewCart: function(oEvt) {
			var cartId = "cartId";
			this.getOwnerComponent().getRouter().navTo("cart", {
				cartId: cartId
			});
		},
		// to add the created item to cart
		onCreateItemPress: function() {
			//get number of items in cart
			var count = this.getOwnerComponent()._oViews._oViews["pr.req.v2.view.Detail"].byId("headerCartBtn").getText();
			if (count >= 100) {
				var flagC = false;
			} else {
				flagC = true;
			}
			if (flagC) {
				//validations
				var canProceed = true;
				var shText = this.byId("shtextId");
				if (shText.getValue() === "") {
					shText.setValueState("Error");
					shText.setValueStateText("Enter short text");
					canProceed = false;
				}

				var qtyVal = this.byId("qtyId");
				if (qtyVal.getValue() === "" || qtyVal.getValue() === 0 || qtyVal.getValue() < 1) {
					qtyVal.setValueState("Error");
					qtyVal.setValueStateText("Invalid Quantity");
					canProceed = false;
				}
				var UomId = this.byId("UomId");
				if (UomId.getSelectedKey() === "") {
					UomId.setValueState("Error");
					UomId.setValueStateText("Enter Unit of Measure");
					canProceed = false;
				}
				var valPric = this.byId("valprId");
				if (valPric.getValue() === "") {
					valPric.setValueState("Error");
					valPric.setValueStateText("Enter Valuation Price");
					canProceed = false;
				}

				var updatedFormat;
				var delvyDt = this.byId("deldtId").getDateValue();
				if (!this.byId("deldtId").getDateValue()) {
					updatedFormat = null;
					this.byId("deldtId").setValueState("Error");
					this.byId("deldtId").setValueStateText("please enter date");
					canProceed = false;

				} else {
					var oDate = new Date(delvyDt);
					// to update date in system date format
					updatedFormat = [oDate.getFullYear(), oDate.getMonth() + 1, oDate.getDate()].join("-");
					//dfct419
					var nDate = sap.ui.core.format.DateFormat.getDateInstance({
						pattern: "yyyy-MM-dd"
					});
					var oDatef = nDate.format(new Date(delvyDt));
					var oDateout = oDatef + 'T00:00:00';
				}
				var omat = this.byId("matgrpId");
				if (omat.getSelectedKey() === "") {
					omat.setValueState("Error");
					canProceed = false;
				}

				var matrlGrp = this.byId("matgrpId").getSelectedKey();

				var CrcyId = this.byId("crcyId");
				if (CrcyId.getSelectedKey() === "") {
					CrcyId.setValueState("Error");
					CrcyId.setValueStateText("Enter Currency");
					canProceed = false;
				}
				if (canProceed) {
					var oModel = this.getOwnerComponent().getModel();
					var oJSONModel = this.getOwnerComponent().getModel("json");
					var matrlNum = oJSONModel.getData().Matrlnumber;
					var crcyVal = CrcyId.getSelectedKey();
					var addToCart = {};
					addToCart.Text1 = this.byId("cmntsId").getValue();
					addToCart.Maktx = shText.getValue();
					addToCart.Menge = qtyVal.getValue();
					addToCart.Uom = UomId.getSelectedKey();
					addToCart.Verpr = valPric.getValue();
					addToCart.Preis = valPric.getValue();
					addToCart.Waers = crcyVal;
					addToCart.Wgbez = this.byId("matgrpId").getSelectedItem().getProperty("text");
					addToCart.Lfdat = oDateout;
					addToCart.Matkl = this.byId("matgrpId").getSelectedKey();
					addToCart.Knttp = oJSONModel.getProperty("/SelectedKey");
					oModel.create("/DraftitemsSet", addToCart, {
						success: function(oData, oResponse) {
							MessageToast.show("Draft Item Successfully created");
							oModel.read("/CheckflagSet('X')", {
								success: function(r) {
									sap.ui.core.BusyIndicator.hide();
									oJSONModel.setProperty("/Flag", r);
									oJSONModel.refresh("true");
								}
							});
						},
						error: function() {
							sap.ui.core.BusyIndicator.hide();
						}
					});
				} else {
					MessageBox.warning("please fill all the fields to add item to Cart");
				}
			} else {
				MessageToast.show("Maximum item count(100) for the cart has acheived. No new item can be added to cart", {
					duration: 6000,
					width: "20em"
				});
			}
		},

		// on decline press  reset all the entered values 	
		onDeleteCreateItem: function() {
			this.byId("shtextId").setValue("");
			this.byId("shtextId").setValueState("None");
			this.byId("qtyId").setValue("");
			this.byId("qtyId").setValueState("None");
			this.byId("UomId").setSelectedKey("");
			this.byId("UomId").setValueState("None");
			this.byId("valprId").setValue("");
			this.byId("valprId").setValueState("None");
			this.byId("deldtId").setDateValue(new Date());
			this.byId("deldtId").setValueState("None");
			this.byId("matgrpId").setSelectedKey("");
			this.byId("cmntsId").setValue("");
		},

		// navigation back from create item view
		onCrtItemNavBack: function(oEvent) {
			var objId = "objectId";
			this.getRouter().navTo("object", {
				objectId: objId
			});
		}

	});
});