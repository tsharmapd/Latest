/*global locatiFonFav */
sap.ui.define([
	"pr/req/v2/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"pr/req/v2/model/formatter",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/m/MessageToast"

], function(BaseController, JSONModel, formatter, MessageBox, Filter, MessageToast) {
	"use strict";

	return BaseController.extend("pr.req.v2.controller.Detail", {

		formatter: formatter,
		/**/
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */
		// called to set cart data 
		onInit: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oModel.read("/DraftitemsSet", {
				success: function(r) {
					oJSONModel.setProperty("/cartModel", r.results);
				}
			});
			// to set Rig Number
			oModel.read("/CheckflagSet('B')", {
				success: function(r) {
					oJSONModel.setProperty("/RigNum", r);
				}
			});
			oJSONModel.refresh(true);
			//set selected key
			this.sComb = this.byId("selComb").getSelectedKey();
			oJSONModel.setProperty("/SelectedKey", this.sComb);

		},
		/// on Search filter with the material num to get all items starting with number of matnr
		onSearchPressed: function(oEvent) {
			this.sSearch = oEvent.getParameter("query");
			var oModel = this.getView().getModel();
			var oBinding = this.getOwnerComponent()._oViews._oViews["pr.req.v2.view.Detail"].byId("table").getBinding("items");
			var vURLCountPR = "/SearchItemsSet/$count?" + oBinding.filter([new Filter("Matkl", "EQ", ""), new Filter("Mfrnr", "EQ",
				""), new Filter("Matnr", "EQ", ""), new Filter("Mfrpn", "EQ", ""), new Filter("Maktx", "EQ", this.sSearch)]);
			sap.ui.core.BusyIndicator.show(0);
			// calling service with user input filters to get table records
			var mParameters = {
				json: true,
				success: function() {
					sap.ui.core.BusyIndicator.hide();
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			};
			oModel.read(vURLCountPR, mParameters);
		},

		/// on Search filter with the material num to get all items starting with number of matnr
		onSearchMatnr: function(oEvent) {
			this.sSearch = oEvent.getParameter("query");
			var oModel = this.getView().getModel();
			var oBinding = this.getOwnerComponent()._oViews._oViews["pr.req.v2.view.Detail"].byId("table").getBinding("items");
			var vURLCountPR = "/SearchItemsSet/$count?" + oBinding.filter([new Filter("Matkl", "EQ", ""), new Filter("Mfrnr", "EQ",
				""), new Filter("Maktx", "EQ", ""), new Filter("Mfrpn", "EQ", ""), new Filter("Matnr", "EQ", this.sSearch)]);
			sap.ui.core.BusyIndicator.show(0);
			// calling service with user input filters to get table records
			var mParameters = {
				json: true,
				success: function() {
					sap.ui.core.BusyIndicator.hide();
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			};
			oModel.read(vURLCountPR, mParameters);
		},
		/// on Search filter with the material group to get all items with search material group
		onSearchMatkl: function() {
			this.byId("detailsearchFieldMaktx").setValue("");
			this.byId("detailsearchFieldmatnr").setValue("");
			this.byId("detailsearchFieldMfrpn").removeAllTokens();
			this.byId("detailsearchFieldMfrnr").removeAllTokens();
			this.sSearch = this.byId("matGrp").getSelectedKey();
			var oModel = this.getView().getModel();
			var oBinding = this.getOwnerComponent()._oViews._oViews["pr.req.v2.view.Detail"].byId("table").getBinding("items");
			var vURLCountPR = "/SearchItemsSet/$count?" + oBinding.filter([new Filter("Matkl", "EQ", this.sSearch), new Filter("Mfrnr", "EQ",
				""), new Filter("Maktx", "EQ", ""), new Filter("Mfrpn", "EQ", ""), new Filter("Matnr", "EQ", "")]);
			sap.ui.core.BusyIndicator.show(0);
			// calling service with user input filters to get table records
			var mParameters = {
				json: true,
				success: function() {
					sap.ui.core.BusyIndicator.hide();
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			};
			oModel.read(vURLCountPR, mParameters);
		},
		//addf4 valuehelp for OEM Part#
		handleVhMfrpn: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._oOEM) {
				this._oOEM = sap.ui.xmlfragment(
					"pr.req.v2.view.fragment.OEM",
					this
				);
				this.getView().addDependent(this._oOEM);
			}
			// // create a filter for the binding
			// this._oOEM.getBinding("items").filter([new Filter(
			// 	"Mfrpn",
			// 	sap.ui.model.FilterOperator.Contains, sInputValue
			// )]);
			// // open value help dialog filtered by the input value
			this._oOEM.open();
		},
		//addf4 valuehelp for OEM Part#
		handleVhMfrnr: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._oManufacturer) {
				this._oManufacturer = sap.ui.xmlfragment(
					"pr.req.v2.view.fragment.Manufacturer",
					this
				);
				this.getView().addDependent(this._oManufacturer);
			}
			// // create a filter for the binding
			// this._oManufacturer.getBinding("items").filter([new Filter(
			// 	"Name1",
			// 	sap.ui.model.FilterOperator.Contains, sInputValue
			// )]);
			// open value help dialog filtered by the input value
			this._oManufacturer.open();
		},
		_handleValueHelpSearch: function(evt) {
			var oDialog = evt.getParameter("id");
			var sValue = evt.getParameter("value");
			var oFilter;
			if (oDialog === "Mfrpn") {
				oFilter = new Filter(
					"Mfrpn",
					sap.ui.model.FilterOperator.Contains, sValue
				);
			} else {
				if (oDialog === "Mfrnr") {
					oFilter = new Filter(
						"Name1",
						sap.ui.model.FilterOperator.Contains, sValue
					);
				}
			}
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpClose: function(evt) {
			var orderInput;
			var valueArray = [];
			var aFilter = [];
			var oDialog = evt.getParameter("id");
			var oSelectedItem = evt.getParameter("selectedItems");
			var oModel = this.getView().getModel();
			var oBinding = this.getOwnerComponent()._oViews._oViews["pr.req.v2.view.Detail"].byId("table").getBinding("items");
			if (oSelectedItem) {
				if (oDialog === "Mfrpn") {
					orderInput = this.byId("detailsearchFieldMfrpn");
					if (oSelectedItem.length !== 0) {
						for (var i = 0; i < oSelectedItem.length; i++) {
							valueArray.push(new sap.m.Token({
								text: oSelectedItem[i].getBindingContext().getObject().Mfrpn //getProperty("title")
							}));

							aFilter.push(new sap.ui.model.Filter(
								"Mfrpn",
								sap.ui.model.FilterOperator.EQ, oSelectedItem[i].getBindingContext().getObject().Mfrpn //getProperty("title")
							));

						}
					}
					orderInput.setTokens(valueArray);
					this.byId("detailsearchFieldMaktx").setValue("");
					this.byId("detailsearchFieldmatnr").setValue("");
					this.byId("detailsearchFieldMfrnr").removeAllTokens();
					this.byId("matGrp").setSelectedKey("");
					var vURLCountPR = "/SearchItemsSet/$count?" + oBinding.filter(aFilter);
					sap.ui.core.BusyIndicator.show(0);
					// calling service with user input filters to get table records
					var mParameters = {
						json: true,
						success: function() {
							sap.ui.core.BusyIndicator.hide();
						},
						error: function() {
							sap.ui.core.BusyIndicator.hide();
						}
					};
					oModel.read(vURLCountPR, mParameters);
				} else {
					if (oDialog === "Mfrnr") {
						orderInput = this.byId("detailsearchFieldMfrnr");
						if (oSelectedItem.length !== 0) {
							for (i = 0; i < oSelectedItem.length; i++) {
								valueArray.push(new sap.m.Token({
									text: oSelectedItem[i].getBindingContext().getObject().Name1,
									key: oSelectedItem[i].getBindingContext().getObject().Mfrnr
								}));

								aFilter.push(new sap.ui.model.Filter(
									"Mfrnr",
									sap.ui.model.FilterOperator.EQ, oSelectedItem[i].getBindingContext().getObject().Mfrnr
								));

							}
						}
						orderInput.setTokens(valueArray);
						this.byId("detailsearchFieldMaktx").setValue("");
						this.byId("detailsearchFieldmatnr").setValue("");
						this.byId("detailsearchFieldMfrpn").removeAllTokens();
						this.byId("matGrp").setSelectedKey("");
						vURLCountPR = "/SearchItemsSet/$count?" + oBinding.filter(aFilter);
						sap.ui.core.BusyIndicator.show(0);
						// calling service with user input filters to get table records
						mParameters = {
							json: true,
							success: function() {
								sap.ui.core.BusyIndicator.hide();
							},
							error: function() {
								sap.ui.core.BusyIndicator.hide();
							}
						};
						oModel.read(vURLCountPR, mParameters);
					}
				}
			}
			evt.getSource().getBinding("items").filter([]);
		},
		// /// on Search filter with the manufacturer
		// onSearchMfrnr: function(oEvent) {
		// 	this.sSearch = oEvent.getParameter("query");
		// 	var oModel = this.getView().getModel();
		// 	var oBinding = this.getOwnerComponent()._oViews._oViews["pr.req.v2.view.Detail"].byId("table").getBinding("items");
		// 	var vURLCountPR = "/SearchItemsSet/$count?" + oBinding.filter([new Filter("Matkl", "EQ", ""), new Filter("Name2", "EQ",
		// 		this.sSearch), new Filter("Maktx", "EQ", ""), new Filter("Mfrpn", "EQ", ""), new Filter("Matnr", "EQ", "")]);
		// 	sap.ui.core.BusyIndicator.show(0);
		// 	// calling service with user input filters to get table records
		// 	var mParameters = {
		// 		json: true,
		// 		success: function() {
		// 			sap.ui.core.BusyIndicator.hide();
		// 		},
		// 		error: function() {
		// 			sap.ui.core.BusyIndicator.hide();
		// 		}
		// 	};
		// 	oModel.read(vURLCountPR, mParameters);
		// },
		// /// on Search filter with the manufacturer part number
		// onSearchMfrpn: function(oEvent) {
		// 	this.sSearch = oEvent.getParameter("query");
		// 	var oModel = this.getView().getModel();
		// 	var oBinding = this.getOwnerComponent()._oViews._oViews["pr.req.v2.view.Detail"].byId("table").getBinding("items");
		// 	var vURLCountPR = "/SearchItemsSet/$count?" + oBinding.filter([new Filter("Matkl", "EQ", ""), new Filter("Name2", "EQ",
		// 		""), new Filter("Maktx", "EQ", ""), new Filter("Mfrpn", "EQ", this.sSearch), new Filter("Matnr", "EQ", "")]);
		// 	sap.ui.core.BusyIndicator.show(0);
		// 	// calling service with user input filters to get table records
		// 	var mParameters = {
		// 		json: true,
		// 		success: function() {
		// 			sap.ui.core.BusyIndicator.hide();
		// 		},
		// 		error: function() {
		// 			sap.ui.core.BusyIndicator.hide();
		// 		}
		// 	};
		// 	oModel.read(vURLCountPR, mParameters);
		// },
		// to remove table data
		refreshTable: function() {
			this.byId("detailsearchFieldMaktx").setValue("");
			this.byId("detailsearchFieldmatnr").setValue("");
			this.getView().getModel("json").setProperty("/tablebindingModel", "");
			this.byId("table").getModel().refresh();
			this.byId("detailsItemHeader").setText("Items(0)");
		},
		//set combobox selection
		onCharge: function() {
			//// To get selectedkey from combobox 
			var oJSONModel = this.getOwnerComponent().getModel("json");
			this.sComb = this.byId("selComb").getSelectedKey();
			oJSONModel.setProperty("/SelectedKey", this.sComb);
		},
		//	to update the count
		onDetailsTableUpdateFinished: function(oEvent) {
			var iTotalItems = oEvent.getParameter("actual");
			if (iTotalItems) {
				this.byId("detailsItemHeader").setText("Items (" + oEvent.getParameter("actual") + "/" + oEvent.getParameter("total") + ")");
			} else {
				//Display 'Line Items' instead of 'Line items (0)'
				this.byId("detailsItemHeader").setText("Items(0)");
			}
		},

		onClearfb: function() {
			this.byId("matGrp").setSelectedKey("");
			this.byId("detailsearchFieldMaktx").setValue("");
			this.byId("detailsearchFieldmatnr").setValue("");
			this.byId("detailsearchFieldMfrpn").removeAllTokens();
			this.byId("detailsearchFieldMfrnr").removeAllTokens();
		},

		onToken: function(e) {
			var aFilter = [];
			var sTokens;
			var sRemoved = e.getParameter("removedTokens");
			if ((e.getSource().sId).indexOf("Mfrpn") !== -1) {
				sTokens = this.byId("detailsearchFieldMfrpn").getTokens();
			} else {
				sTokens = this.byId("detailsearchFieldMfrnr").getTokens();
			}
			for (var i = 0; i < sTokens.length; i++) {
				if (sTokens[i].getProperty("text") !== sRemoved[0].getProperty("text")) {
					if ((e.getSource().sId).indexOf !== "Mfrpn") {
						aFilter.push(new sap.ui.model.Filter(
							"Mfrpn",
							sap.ui.model.FilterOperator.EQ, sTokens[i].getProperty("text")
						));
					} else {
						aFilter.push(new sap.ui.model.Filter(
							"Mfrnr",
							sap.ui.model.FilterOperator.EQ, sTokens[i].getProperty("key")
						));
					}

				}
			}
			var oModel = this.getView().getModel();
			var oBinding = this.getOwnerComponent()._oViews._oViews["pr.req.v2.view.Detail"].byId("table").getBinding("items");
			var vURLCountPR = "/SearchItemsSet/$count?" + oBinding.filter(aFilter);
			sap.ui.core.BusyIndicator.show(0);
			// calling service with user input filters to get table records
			var mParameters = {
				json: true,
				success: function() {
					sap.ui.core.BusyIndicator.hide();
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			};
			oModel.read(vURLCountPR, mParameters);
		},

		onliveChangeSearch: function(e) {
			if (e.getParameter("id").indexOf("Maktx") !== -1) {
				this.byId("matGrp").setSelectedKey("");
				this.byId("detailsearchFieldmatnr").setValue("");
				this.byId("detailsearchFieldMfrpn").removeAllTokens();
				this.byId("detailsearchFieldMfrnr").removeAllTokens();
				this.byId("table").destroyItems();
				this.byId("detailsItemHeader").setText("Items(0)");
			} else {
				if (e.getParameter("id").indexOf("matnr") !== -1) {
					this.byId("matGrp").setSelectedKey("");
					this.byId("detailsearchFieldMaktx").setValue("");
					this.byId("detailsearchFieldMfrpn").removeAllTokens();
					this.byId("detailsearchFieldMfrnr").removeAllTokens();
					this.byId("table").destroyItems();
					this.byId("detailsItemHeader").setText("Items(0)");
				} else {
					if (e.getParameter("id").indexOf("Mfrnr") !== -1) {
						this.byId("matGrp").setSelectedKey("");
						this.byId("detailsearchFieldMaktx").setValue("");
						this.byId("detailsearchFieldMfrpn").removeAllTokens();
						this.byId("detailsearchFieldmatnr").setValue("");
					} else {
						if (e.getParameter("id").indexOf("Mfrpn") !== -1) {
							this.byId("matGrp").setSelectedKey("");
							this.byId("detailsearchFieldMaktx").setValue("");
							this.byId("detailsearchFieldmatnr").setValue("");
							this.byId("detailsearchFieldMfrnr").removeAllTokens();
						}
					}
				}
			}
		},

		//// on delete pressed of the dialog draft items//
		onDeletePressed: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var selctdItem = oEvent.getParameter("listItem").getBindingContext("json").getObject();
			var olinenum = selctdItem.Ebelp;
			var Guid = selctdItem.Guid;
			oModel.remove("/DraftlineSet(Guid='" + Guid + "',Ebelp='" + olinenum + "')", {
				success: function(data, response) {
					sap.ui.core.BusyIndicator.hide();
					oModel.read("/DraftitemsSet", {
						success: function(r, s) {
							oJSONModel.setProperty("/cartModel", r.results);
						}
					});
					MessageToast.show("Draft item successfully removed from cart");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
						}
					});
					oJSONModel.refresh("true");
				}
			});
		},
		//// shopping cart button opens dialog with draft items
		onShoppingCartPressed: function() {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show();
			this.getOwnerComponent().getModel().read("/DraftitemsSet", {
				success: function(r) {

					oJSONModel.setProperty("/cartModel", r.results);
					if (r.results.length === "0") {
						oJSONModel.setProperty("/viewCart", false);
					} else {
						oJSONModel.setProperty("/viewCart", true);
					}

					sap.ui.core.BusyIndicator.hide();
				}
			});
			//// To get selectedkey from combobox 
			this.sComb = this.byId("selComb").getSelectedKey();
			oJSONModel.setProperty("/SelectedKey", this.sComb);
			// to open the shopping cart fragment
			if (!this.ocartPress) {
				this.ocartPress = sap.ui.xmlfragment("pr.req.v2.view.fragment.ShoppingCart", this);
				this.getView().addDependent(this.ocartPress);
				this.ocartPress.setModel(oJSONModel);
				oJSONModel.refresh();
			}
			this.ocartPress.setModel(oJSONModel);
			oJSONModel.refresh();
			this.ocartPress.open();
		},

		///// cart dialog cancel closes dialog
		cancel: function() {
			this.ocartPress.close();
		},
		// Router component for navigation
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		//// navigation on View cart press on cart dialog
		ViewCart: function() {

			var cartId = "cartId";
			this.getOwnerComponent().getRouter().navTo("cart", {
				cartId: cartId
			});
			this.refreshTable();
		},
		/// Quick view opens with details
		onQckviewPressed: function(oEvent) {
			if (!this.oQckVwdialog) {
				this.oQckVwdialog = sap.ui.xmlfragment("pr.req.v2.view.fragment.QuickView", this);
			}
			var sObject = oEvent.getSource().getParent().getBindingContext().getObject();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oJSONModel.setProperty("/QckvwModel", sObject);
			this.oQckVwdialog.setModel(oJSONModel);
			this.oQckVwdialog.bindElement("/QckvwModel");
			this.oQckVwdialog.openBy(oEvent.getSource());
		},

		/// favorite handling  selection and deselection  add's/delete's item to favorites table
		onFavoriteSelection: function(oEvent) {
			var state = oEvent.getSource().getPressed();
			this.setflag = "X";
			this.setevent = "";
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			// action taken based on toggle state of button
			if (state == true) {
				this.setflag = "Y";
				var favObj = oEvent.getSource().getParent().getBindingContext().getObject();
				var sfavorite = {};
				sfavorite.Maktx = favObj.Maktx;
				sfavorite.Matkl = favObj.Matkl;
				sfavorite.Matnr = favObj.Matnr;
				sfavorite.Menge = favObj.Menge;
				sfavorite.Mfrnr = favObj.Mfrnr;
				sfavorite.Uom = favObj.Uom;
				sfavorite.Wgbez = favObj.Name1;
				sfavorite.Verpr = favObj.Verpr;
				sfavorite.Waers = favObj.Waers;
				sfavorite.Img = favObj.Image;
				sfavorite.Text = favObj.Text;
				var that = this;
				oModel.create("/FavoriteSet", sfavorite, {
					success: function(oData, oResponse) {
						MessageToast.show("Item Selected as Favorite");
						oModel.read("/CheckflagSet('F')", {
							success: function(r) {
								oJSONModel.setProperty("/favCount", r);
								that.getOwnerComponent()._oViews._oViews["pr.req.v2.view.Master"].byId("FavList").setInfo(r.Count);
								sap.ui.core.BusyIndicator.hide();
								oJSONModel.refresh(true);
							}
						});
					},
					error: function() {
						sap.ui.core.BusyIndicator.hide();
					}
				});
			}
			// when switching the state of btn from toggled to untoggle removes item from favoriteset
			if (state == false) {
				var unfavObj = oEvent.getSource().getParent().getBindingContext().getObject();
				var unfavorite = {};
				unfavorite.Matnr = unfavObj.Matnr;
				var sMatnr = unfavObj.Matnr;
				var sParseMatnr = sMatnr.replace("#", "@");
				var sMatnrr = sParseMatnr.replace("/", "$");
				var sMatnrFinal = sMatnrr.replace(":", "_");
				var that = this;
				oModel.remove("/FavoriteSet(Matnr='" + sMatnrFinal + "')", {
					success: function(oData, oResponse) {
						MessageToast.show("Item deselected as favorite");
						oModel.read("/CheckflagSet('F')", {
							success: function(r) {
								sap.ui.core.BusyIndicator.hide();
								oJSONModel.setProperty("/favCount", r);
								that.getOwnerComponent()._oViews._oViews["pr.req.v2.view.Master"].byId("FavList").setInfo(r.Count);
								oJSONModel.refresh(true);
							}
						});
					},
					error: function() {}
				});
			}
		},
		// to refresh table after rendering
		onAfterRendering: function() {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oJSONModel.getProperty("/tablebindingModel");
			oJSONModel.refresh("true");
		},

		/// on add to cart press adds draft items to shopping cart
		onAddToCartPressed: function(oEvent) {
			var count = this.byId("headerCartBtn").getText();
			if (count >= 100) {
				var flagC = false;
			} else {
				flagC = true;
			}
			if (flagC) {
				var objData = oEvent.getSource().getParent().getParent().getBindingContext().getObject();
				var i = oEvent.getSource().getParent().getParent().getParent().indexOfItem(oEvent.getSource().getParent().getParent());
				var oMenge = oEvent.getSource().getParent().getParent().getParent().getItems()[i].getCells()[6].getValue();
				if (oMenge === "0" || oMenge < 1 || oMenge === "") {
					MessageBox.warning("Quantity should not be Empty or Zero");
				} else {
					var cartData = {};
					cartData.Ebelp = "00010";
					cartData.Knttp = this.byId("selComb").getSelectedKey();
					cartData.Maktx = objData.Maktx;
					cartData.Matkl = objData.Matkl;
					cartData.Matnr = objData.Matnr;
					cartData.Menge = oEvent.getSource().getParent().getParent().getParent().getItems()[i].getCells()[6].getValue();
					cartData.Mfrnr = objData.Mfrnr;
					cartData.Wgbez = objData.Name1;
					cartData.Uom = objData.Uom;
					cartData.Verpr = objData.Verpr;
					cartData.Waers = objData.Waers;
					cartData.Image = objData.Image;
					var oModel = this.getOwnerComponent().getModel();
					var oJSONModel = this.getOwnerComponent().getModel("json");
					sap.ui.core.BusyIndicator.show(0);
					oEvent.getSource().getParent().getParent().getParent().getItems()[i].getCells()[6].setValue("");
					// to get the selected row index of the table
					oModel.create("/DraftitemsSet", cartData, {
						success: function(oData, oResponse) {
							oModel.read("/CheckflagSet('X')", {
								success: function(r) {
									oJSONModel.setProperty("/Flag", r);
									oJSONModel.refresh("true");
									MessageToast.show("Item added to cart");
									sap.ui.core.BusyIndicator.hide();
								}

							});
							// to update the table with the new item created  
							oModel.read("/DraftitemsSet", {
								success: function(r) {

									oJSONModel.setProperty("/cartModel", r.results);
									sap.ui.core.BusyIndicator.hide();
								}
							});
							oJSONModel.refresh(true);
						},
						error: function() {
							sap.ui.core.BusyIndicator.hide();
						}
					});
				}
			} else {
				MessageToast.show("Maximum item count(100) for the cart has acheived. No new item can be added to cart", {
					duration: 6000,
					width: "20em"
				});
			}

		}
	});
});