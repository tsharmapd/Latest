sap.ui.define([
	"pr/req/v2/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function(BaseController, JSONModel, Filter, MessageBox,MessageToast) {
	"use strict";

	return BaseController.extend("pr.req.v2.controller.App", {
		// To set the count of cart during initial load
		onInit: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oModel.read("/CheckflagSet('X')", {
				success: function(r) {
					var data = r;
					oJSONModel.setProperty("/Flag", data);
					if (r.Count >= 100) {
						MessageToast.show("Maximum item count(100) for the cart has acheived. No new item can be added to cart",{
    						duration: 6000,
					    	width: "20em" 
						});
					}
				},
				error: function() {
					MessageBox.error("Unable to retrieve data for flag. Please try again.");
				}
			});
		}
	});
});