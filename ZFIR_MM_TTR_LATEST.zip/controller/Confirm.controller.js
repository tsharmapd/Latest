sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/m/MessageToast"
], function(Controller, History, MessageBox, Filter, MessageToast) {
	"use strict";

	return Controller.extend("va.controller.Confirm", {
		onInit: function() {
			this.getOwnerComponent().getRouter().getRoute("confirm").attachPatternMatched(this._onMatched, this);

		},
		_onMatched: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oJSONModel.setProperty("/selKey", "T");
			this.byId("selComb").setSelectedKey(oJSONModel.getProperty("/selKey"));
			var oTable = this.byId("tabId");
			oTable.setVisible(false);
			var that = this;
			this.oBusy = new sap.m.BusyDialog();
			this.oBusy.open();

			oModel.read("/HeadSet", {
				success: function(r) {
					that.oBusy.close();
					oJSONModel.setProperty("/headModel", r.results);
				},
				error: function() {
					that.oBusy.close();
					MessageToast.show("Unable to get records from Header Please try again.");
				}
			});
			oModel.read("/CheckflagSet('B')", {
				success: function(r, s) {
					oJSONModel.setProperty("/RigNum", r);
				}
			});
			oJSONModel.refresh();
		},

		/// navigation back to previous hash
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
			this.getOwnerComponent().getModel("json").setProperty("/selKey", "K");
		},
		onChangeSel: function(oEvt) {
			this.sComb = this.byId("selComb").getSelectedKey();
			var oJsonModel = this.getOwnerComponent().getModel("json");
			oJsonModel.setProperty("/selKey", this.sComb);
			if (this.sComb === "K") {

				this.getOwnerComponent().getRouter().navTo("worklist", {});
				this.byId("selComb").setSelectedKey(oJsonModel.getProperty("/selKey"));
			}
			if (this.sComb === "R") {
				var historyId = "historyId";
				this.getOwnerComponent().getRouter().navTo("history", {
					historyId: historyId
				});
				this.byId("selComb").setSelectedKey(oJsonModel.getProperty("/selKey"));
			}
		},
		onFilter: function() {
			// to open the fragment to filter table data
			if (!this.fDialog) {
				this.fDialog = sap.ui.xmlfragment("va.view.ttrFilter", this);
				this.getView().addDependent(this.fDialog);
			}
			this.fDialog.setFilterSearchCallback(null);
			this.fDialog.setFilterSearchOperator(sap.m.StringFilterOperator.Contains);
			this.fDialog.open();
		},
		//on filter confirm
		onFilterttrConfirm: function(oEvent) {
			var params = oEvent.getParameters();
			// get the required filter items
			var aFilterItems = params.filterItems;
			var iLength = aFilterItems.length;
			// filter set for the table items
			var aFilter = [];
			if (iLength !== 0) {
				for (var i = 0; i < iLength; i++) {
					if (params.filterItems[i].mBindingInfos.key.binding.sPath == "Ttr") {
						if (params.filterItems[i].mBindingInfos.key.binding.oValue) {
							aFilter.push(new sap.ui.model.Filter(
								"Ttr",
								sap.ui.model.FilterOperator.EQ, params.filterItems[i].mBindingInfos.key.binding.oValue
							));
						}
					}
					this.byId("headTable").getBinding("items").filter(aFilter);
					var oTable = this.byId("tabId");
					oTable.setVisible(false);
				}
			} else {
				this.byId("headTable").getBinding("items").filter(aFilter);
			}
		},
		onSelectedItem: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var selctdItem = oEvent.getParameter("listItem").getBindingContext("json").getObject();
			var Mtr = selctdItem.Ttr;
			var that = this;
			var Flg = "X";
			var f = [];
			// this.sSearch = oEvent.getParameter("query");
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter(
				"Mtrnum",
				sap.ui.model.FilterOperator.EQ, Mtr
			));
			aFilter.push(new sap.ui.model.Filter(
				"Flag",
				sap.ui.model.FilterOperator.EQ, Flg
			));
			aFilter.push(new sap.ui.model.Filter(
				"Item",
				sap.ui.model.FilterOperator.EQ, ""
			));

			sap.ui.core.BusyIndicator.show();
			oModel.read("/DraftitemsSet", {
				filters: aFilter,
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/confModel", r.results);
					oJSONModel.refresh("true");
					var oTable = that.byId("tabId");
					oTable.setVisible(true);
					for (var i = 0; i < r.results.length; i++) {
						oJSONModel.setProperty("/batModel" + i, f);
						that.byId("tabId").getItems()[i].getCells()[6].setValue(r.results[i].Tocharg);
						that.byId("tabId").getItems()[i].getCells()[6].setSelectedKey(r.results[i].Tocharg);
					}

				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			});
			oJSONModel.refresh();
		},
		// On Reject
		onRejectPressed: function() {

			// var oModel = this.getOwnerComponent().getModel("json").getData().confModel;
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var oMaster = {};
			var oItemData = [];
			var Items = [];
			var oTable = this.byId("tabId");
			var selectedItems = oTable.getSelectedItems();
			if (selectedItems.length === 0) {
				MessageToast.show("Please select at least one line item");
			} else {
				sap.ui.core.BusyIndicator.show();
				for (var i = 0; i < selectedItems.length; i++) {
					Items.push({
						"Mtrnum": selectedItems[i].getCells()[0].getText(),
						"Item": selectedItems[i].getCells()[1].getText(),
						"Matnr": selectedItems[i].getCells()[2].getText(),
						"Charg": selectedItems[i].getCells()[5].getText(),
						"Tocharg": selectedItems[i].getCells()[6].getValue(),
						"Towerks": selectedItems[i].getCells()[7].getText(),
						"Tolgort": selectedItems[i].getCells()[8].getText(),
						"Comments": selectedItems[i].getCells()[12].getValue(),
						"EntryQty": selectedItems[i].getCells()[11].getValue()

					});
				}
				oJSONModel.setProperty("/Payload", Items);
				var oModel = this.getOwnerComponent().getModel("json").getData().Payload;
				for (i = 0; i < selectedItems.length; i++) {
					if (oMaster.Flag !== "Z") {
						oMaster.Flag = "Z";
						oMaster.Mtrnum = oModel[i].Mtrnum;
					}
					var oDetail = {};
					oDetail.Mtrnum = oModel[i].Mtrnum;
					oDetail.Item = oModel[i].Item;
					oDetail.Matnr = oModel[i].Matnr;
					oDetail.Charg = oModel[i].Charg;
					oDetail.Tocharg = oModel[i].Tocharg;
					oDetail.Towerks = oModel[i].Towerks;
					oDetail.Tolgort = oModel[i].Tolgort;
					oDetail.Comments = oModel[i].Comments;
					oDetail.EntryQty = oModel[i].EntryQty;
					oItemData.push(oDetail);
				}
				// insert item data into header data
				oMaster.nav_htoi = oItemData;
				//get model instance
				var oModelMain = this.getOwnerComponent().getModel();
				oModelMain.setHeaders({
					"Access-Control-Allow-Origin": "*",
					"Content-Type": "application/x-www-form-urlencoded",
					"X-CSRF-Token": "Fetch"
				});
				//fetch token and get reponse
				var token;
				oModelMain.read('/DraftitemsSet', null, null, false, function(oData, oResponse) {
						token = oResponse.headers['x-csrf-token'];
					},
					function() {

					});
				//set http header for POST rest with token fetched from read
				oModelMain.setHeaders({
					"X-Requested-With": "XMLHttpRequest",
					"Content-Type": "application/json",
					"DataServiceVersion": "2.0",
					"Accept": "application/atom+xml,application/atomsvc+xml,application/xml",
					"X-CSRF-Token": token
				});
				//call POST method
				sap.ui.core.BusyIndicator.show(0);
				var that = this;
				oModel = this.getOwnerComponent().getModel();
				oJSONModel = this.getOwnerComponent().getModel("json");

				oModelMain.create("/CheckflagSet", oMaster, {
					success: function(oData, oResponse) {
						// Success
						sap.ui.core.BusyIndicator.hide();
						MessageToast.show("TTR Rejected");

						oModel.read("/HeadSet", {
							success: function(r) {
								that.oBusy.close();
								oJSONModel.setProperty("/headModel", r.results);
								oJSONModel.refresh();
							}
						});
						var oTab = that.byId("tabId");
						oTab.setVisible(false);
						oTab.removeSelections(true);
						var oTab1 = that.byId("headTable");
						oTab1.removeSelections(true);
					},
					error: function(oError) {
						sap.ui.core.BusyIndicator.hide();
						jQuery.sap.require("sap.m.MessageBox");
						sap.m.MessageBox.show((JSON.parse(oError.responseText).error.message.value), {
							icon: sap.m.MessageBox.Icon.Information,
							title: "Message Box"
						});
					}
				});
			}
		},

		//On confirm
		onConfirmPressed: function() {
			sap.ui.core.BusyIndicator.show();
			// var oModel = this.getOwnerComponent().getModel("json").getData().confModel;
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var oMaster = {};
			var Items = [];
			var oItemData = [];
			var oTable = this.byId("tabId");
			var selectedItems = oTable.getSelectedItems();
			if (selectedItems.length === 0) {
				MessageToast.show("Please select at least one line item");
				sap.ui.core.BusyIndicator.hide();
			} else {

				for (var i = 0; i < selectedItems.length; i++) {
					Items.push({
						"Mtrnum": selectedItems[i].getCells()[0].getText(),
						"Item": selectedItems[i].getCells()[1].getText(),
						"Matnr": selectedItems[i].getCells()[2].getText(),
						"Charg": selectedItems[i].getCells()[5].getText(),
						"Tocharg": selectedItems[i].getCells()[6].getValue(),
						"Towerks": selectedItems[i].getCells()[7].getText(),
						"Tolgort": selectedItems[i].getCells()[8].getText(),
						"Comments": selectedItems[i].getCells()[12].getValue(),
						"EntryQty": selectedItems[i].getCells()[11].getValue()
					});
				}
				oJSONModel.setProperty("/finalload", Items);
				var oModel = this.getOwnerComponent().getModel("json").getData().finalload;

				for (i = 0; i < selectedItems.length; i++) {
					if (oMaster.Flag !== "Y") {
						oMaster.Flag = "Y";
						oMaster.Mtrnum = oModel[i].Mtrnum;
					}
					var oDetail = {};
					oDetail.Mtrnum = oModel[i].Mtrnum;
					oDetail.Item = oModel[i].Item;
					oDetail.Matnr = oModel[i].Matnr;
					oDetail.Charg = oModel[i].Charg;
					oDetail.Tocharg = oModel[i].Tocharg;
					oDetail.Towerks = oModel[i].Towerks;
					oDetail.Tolgort = oModel[i].Tolgort;
					oDetail.Comments = oModel[i].Comments;
					oDetail.EntryQty = oModel[i].EntryQty;
					oItemData.push(oDetail);
				}
				// insert item data into header data
				oMaster.nav_htoi = oItemData;
				//get model instance
				var oModelMain = this.getOwnerComponent().getModel();
				oModelMain.setHeaders({
					"Access-Control-Allow-Origin": "*",
					"Content-Type": "application/x-www-form-urlencoded",
					"X-CSRF-Token": "Fetch"
				});
				//fetch token and get reponse
				var token;
				oModelMain.read('/DraftitemsSet', null, null, false, function(oData, oResponse) {
						token = oResponse.headers['x-csrf-token'];
					},
					function() {

					});
				//set http header for POST rest with token fetched from read
				oModelMain.setHeaders({
					"X-Requested-With": "XMLHttpRequest",
					"Content-Type": "application/json",
					"DataServiceVersion": "2.0",
					"Accept": "application/atom+xml,application/atomsvc+xml,application/xml",
					"X-CSRF-Token": token
				});
				//call POST method
				sap.ui.core.BusyIndicator.show(0);
				var that = this;
				oModel = this.getOwnerComponent().getModel();
				oJSONModel = this.getOwnerComponent().getModel("json");

				oModelMain.create("/CheckflagSet", oMaster, {
					success: function(oData, oResponse) {
						// Success
						sap.ui.core.BusyIndicator.hide(0);
						MessageToast.show("TTR successfully Confirmed");

						oModel.read("/HeadSet", {
							success: function(r) {
								that.oBusy.close();
								oJSONModel.setProperty("/headModel", r.results);
								oJSONModel.refresh();
							}
						});
						var oTab = that.byId("tabId");
						oTab.setVisible(false);
						oTab.removeSelections(true);
						var oTab1 = that.byId("headTable");
						oTab1.removeSelections(true);
					},
					error: function(oError) {
						sap.ui.core.BusyIndicator.hide();
						jQuery.sap.require("sap.m.MessageBox");
						sap.m.MessageBox.show((JSON.parse(oError.responseText).error.message.value), {
							icon: sap.m.MessageBox.Icon.Information,
							title: "Message Box"
						});
					}
				});

				sap.ui.core.BusyIndicator.hide(0);
			}
		},
		onBatch1: function(oEvent) {
			var tabI = oEvent.getSource().getParent().getBindingContext("json").getPath().split("/")[2];
			var indx = parseInt(tabI);
			var matnr = this.getView().getModel("json").getData().confModel[indx].Matnr;
			var oModel = this.getView().getModel();
			var ojson = this.getView().getModel("json");
			var plant =  this.getView().getModel("json").getData().confModel[indx].Towerks;
			var rig =  this.getView().getModel("json").getData().confModel[indx].Tolgort;
			var that = this;
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter(
				"Matnr",
				sap.ui.model.FilterOperator.EQ, matnr
			));
			aFilter.push(new sap.ui.model.Filter(
				"Werks",
				sap.ui.model.FilterOperator.EQ, plant
			));
			aFilter.push(new sap.ui.model.Filter(
				"Lgort",
				sap.ui.model.FilterOperator.EQ, rig
			));
			sap.ui.core.BusyIndicator.show();
			oModel.read("/TobatchSet", {
				filters: aFilter,
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					ojson.setProperty("/batModel" + indx, r.results);
						that.byId("tabId").getItems()[indx].getCells()[6].bindItems("json>/batModel" + indx,
							new sap.ui.core.ListItem({
							key: "{json>Tocharg}",
							text: "{json>Tocharg}"
						}));
				}.bind(this),

				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}

			});
		}

	});
});