sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox",
	"va/model/formatter",
	"sap/ui/model/Filter",
	"sap/m/MessageToast"
], function(Controller, History, MessageBox, formatter, Filter, MessageToast) {
	"use strict";

	return Controller.extend("va.controller.ShoppingOut", {
		formatter: formatter,
		onInit: function() {
			this.getOwnerComponent().getRouter().getRoute("cart").attachPatternMatched(this._onMatched, this);
		},
		_onMatched: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var that = this;
			this.oBusy = new sap.m.BusyDialog();
			this.oBusy.open();

			oModel.read("/CheckflagSet('X')", {
				success: function(r) {
					that.oBusy.close();
					oJSONModel.setProperty("/Flag", r);
				}
			});
			oModel.read("/DraftitemsSet", {
				success: function(r) {
					that.oBusy.close();
					oJSONModel.setProperty("/cartModel", r.results);
				},
				error: function() {
					that.oBusy.close();
					MessageToast.show("Unable to get records from cartData. Please try again.");
				}
			});
		},

		/// navigation back to previous hash
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		//// navigation on View cart press on cart dialog 
		onPrintPress: function(oEvt) {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var mtrnum = oJSONModel.getProperty("/title");

			var sRead = "/sap/opu/odata/sap/ZMM_ODATA_TTR_NEW_SRV/pdfSet(Mtrnum='" + mtrnum + "')" + "/$value";
			oModel.read(sRead, {
				async: true,
				success: function(odata, response) {},
				error: function() {}
			});
			window.open(sRead, "Preview", "height=800,width=1000,left=50,top=50");
			this.getOwnerComponent().getRouter().navTo("worklist", {});
			this.odialog.close();
		},
		onPreview: function(oEvent) {

		},
		//// on delete pressed of the dialog draft items//
		onDeleteSelectedItemPressed: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var selctdItem = oEvent.getParameter("listItem").getBindingContext("json").getObject();
			var olinenum = selctdItem.Item;
			var Guid = selctdItem.Mtrnum;
			var flag = "X";

			oModel.remove("/DraftitemsSet(Mtrnum='" + Guid + "',Item='" + olinenum + "',Flag='" + flag + "')", {
				success: function(data, response) {
					sap.ui.core.BusyIndicator.hide();
					oModel.read("/DraftitemsSet", {
						success: function(r, s) {
							oJSONModel.setProperty("/cartModel", r.results);
						}
					});
					MessageToast.show("Draft item successfully removed from cart");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
						}
					});
					oJSONModel.refresh("true");
				}
			});
		},
		// On Discard take to initial screen
		onDiscardDlg: function() {
			this.getOwnerComponent().getRouter().navTo("worklist", {});
			this.odialog.close();
		},

		// All items in the cart are posted to order
		onOrderPressed: function() {
			var oModel = this.getOwnerComponent().getModel("json").getData().cartModel;
			var oTable = this.byId("checkOutTable").getItems();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			//store all the context/contextPath of the table in an array
			var oMaster = {};
			var oItemData = [];
			for (var i = 0; i < oModel.length; i++) {
				if (oMaster.Flag !== "X") {
					// create header	///P///	
					oMaster.Flag = "X";
					oMaster.Mtrnum = oModel[i].Mtrnum;
				}
				//create item 
				var oDetail = {};
				
				oDetail.Mtrnum = oModel[i].Mtrnum;
				oDetail.Item = oModel[i].Item;
				oDetail.Matnr = oModel[i].Matnr;
				oDetail.Charg = oModel[i].Charg;
				oDetail.Tocharg = oModel[i].Tocharg;
				oDetail.Towerks = oModel[i].Towerks;
				oDetail.Tolgort = oModel[i].Tolgort;
				oDetail.Comments = oModel[i].Comments;
				oDetail.EntryQty = oModel[i].EntryQty;
				oDetail.Ntdescription = oModel[i].Ntdescription;
				oDetail.Lostno = oModel[i].Lostno;
				oItemData.push(oDetail);
			}
			// insert item data into header data
			oMaster.nav_htoi = oItemData;
			//get model instance
			sap.ui.core.BusyIndicator.show();
			var oModelMain = this.getOwnerComponent().getModel();
			oModelMain.setHeaders({
				"Access-Control-Allow-Origin": "*",
				"Content-Type": "application/x-www-form-urlencoded",
				"X-CSRF-Token": "Fetch"
			});
			//fetch token and get reponse
			var token;
			oModelMain.read('/DraftitemsSet', null, null, false, function(oData, oResponse) {
					token = oResponse.headers['x-csrf-token'];
				},
				function() {

				});
			//set http header for POST rest with token fetched from read
			oModelMain.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/json",
				"DataServiceVersion": "2.0",
				"Accept": "application/atom+xml,application/atomsvc+xml,application/xml",
				"X-CSRF-Token": token
			});
			//call POST method
			
			var that = this;
			oModelMain.create("/CheckflagSet", oMaster, {
				success: function(oData, oResponse) {
					// Success
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("TTR successfully Created");
					oJSONModel.setProperty("/clear","X");

					if (!that.odialog) {
						that.odialog = sap.ui.xmlfragment("va.view.pDialog", that);
						that.getView().addDependent(that.odialog);

						that.odialog.setModel(oJSONModel);
						oJSONModel.setProperty("/title", oResponse.data.Mtrnum);
						var prNum = oJSONModel.getProperty("/title");

						oJSONModel.refresh();
						sap.ui.getCore().byId("pId").setText("Tubular Order '" + prNum + "' Created.");
						that.odialog.open();
					}
					if (that.odialog) {
						var prNum = oJSONModel.getProperty("/title");
						oJSONModel.refresh();
						sap.ui.getCore().byId("pId").setText("Tubular Order '" + prNum + "' Created.");
						that.odialog.open();
					}
					oModelMain.read("/CheckflagSet('X')", {
						success: function(r) {
							oJSONModel.setProperty("/Flag", r);
							oJSONModel.refresh("true");
							oModelMain.read("/DraftitemsSet", {
								success: function(r) {
									oJSONModel.setProperty("/cartModel", r.results);
									sap.ui.core.BusyIndicator.hide();
								}
							});
							oJSONModel.refresh();
						}
					});
				},
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					jQuery.sap.require("sap.m.MessageBox");
					sap.m.MessageBox.show((JSON.parse(oError.responseText).error.message.value), {
						icon: sap.m.MessageBox.Icon.Information,
						title: "Message Box"
					});
				}
			});
			// sap.ui.core.BusyIndicator.hide(0);
		}
	});
});