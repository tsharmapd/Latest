sap.ui.define([
	"va/controller/BaseController",
	"sap/ui/model/json/JSONModel"
], function(BaseController, JSONModel) {
	"use strict";

	return BaseController.extend("va.controller.App", {

		onInit: function() {
			var oViewModel,
				fnSetAppNotBusy,
				iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();

			oViewModel = new JSONModel({
				busy: true,
				delay: 0
			});
			this.setModel(oViewModel, "appView");

			fnSetAppNotBusy = function() {
				oViewModel.setProperty("/busy", false);
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			};

			this.getOwnerComponent().getModel().metadataLoaded().
			then(fnSetAppNotBusy);

			// apply content density mode to root view
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());

			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var that = this;
			oModel.read("/CheckflagSet('X')", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/Flag", r);
					if (r.Flag === "X") {
						if (!that.oInitalDialog) {
							that.oInitalDialog = sap.ui.xmlfragment("va.view.InitialDialog", that);
							that.getView().addDependent(that.oInitalDialog);
						} // forward compact/cozy style into Dialog
						that.oInitalDialog.addStyleClass(that.getOwnerComponent().getContentDensityClass());
						that.oInitalDialog.open();
					}
				}
			});
			oJSONModel.refresh(true);
		},
		onContinueToCartPress: function() {
			this.oInitalDialog.close();
		},
		onDiscard: function() {
		var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");	
			var mtr = oJSONModel.getProperty("/Flag").Mtrnum;
			var olinenum="";
			var flag="X";
		oModel.remove("/DraftitemsSet(Mtrnum='" + mtr + "',Item='" + olinenum + "',Flag='" + flag + "')", {
				success: function(data, response) {
					sap.ui.core.BusyIndicator.hide();
					oModel.read("/DraftitemsSet", {
						success: function(r, s) {
							oJSONModel.setProperty("/cartModel", r.results);
						}
					});
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
						}
					});
					oJSONModel.refresh("true");
				}
			});	
		this.oInitalDialog.close();
		}
	});

});