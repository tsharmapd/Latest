sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/m/MessageToast"
], function(Controller, History, MessageBox, Filter, MessageToast) {
	"use strict";

	return Controller.extend("va.controller.History", {
		onInit: function() {
			this.getOwnerComponent().getRouter().getRoute("history").attachPatternMatched(this._onMatched, this);

		},
		_onMatched: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oJSONModel.setProperty("/selKey", "R");
			this.byId("selComb").setSelectedKey(oJSONModel.getProperty("/selKey"));
			var that = this;
			this.oBusy = new sap.m.BusyDialog();
			this.oBusy.open();

			var Flg = "1";
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter(
				"Mtrnum",
				sap.ui.model.FilterOperator.EQ, ""
			));
			aFilter.push(new sap.ui.model.Filter(
				"Flag",
				sap.ui.model.FilterOperator.EQ, Flg
			));
			aFilter.push(new sap.ui.model.Filter(
				"Item",
				sap.ui.model.FilterOperator.EQ, ""
			));
			oModel.read("/DraftitemsSet", {
				filters: aFilter,
				success: function(r) {

					oJSONModel.setProperty("/historyModel", r.results);
					

				},
				error: function() {

					MessageToast.show("Unable to get records, Please try again.");
				}
			});

			oModel.read("/CheckflagSet('B')", {
				success: function(r, s) {
					oJSONModel.setProperty("/RigNum", r);
				}
			});

			oModel.read("/CheckflagSet('C')", {
				success: function(r, s) {
					oJSONModel.setProperty("/User", r);
				}
			});
			
			oModel.read("/MtrnumSet", {
				success: function(r) {
					oJSONModel.setProperty("/Mtrnum", r.results);
				}
			});
			
			oJSONModel.refresh("true");
			that.oBusy.close();
		},

		//call on filter value change
		onChange: function(oEvent) {
			this.byId("filterBar").fireFilterChange(oEvent);
		},
		//reset all filters
		onReset: function(oEvent) {
			var oItems = this.byId("filterBar").getAllFilterItems(true);
			for (var i = 0; i < oItems.length; i++) {
				var oControl = this.byId("filterBar").determineControlByFilterItem(oItems[i]);
				if (oControl) {
					oControl.setValue("");
				}
			}
		},
		// Open value help for TTR
		handleValueHelpTtr: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpTtrDialog) {
				this._valueHelpTtrDialog = sap.ui.xmlfragment("va.view.ValueHelpTtr", this);
				this.getView().addDependent(this._valueHelpTtrDialog);
			}
			this._valueHelpTtrDialog.getBinding("items").filter([new Filter(
				"Ttr",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);
			this._valueHelpTtrDialog.open(sInputValue);

		},

		_handleLiveChangeTtr: function(oEvent) {
			// var sId = oEvent.getParameters().id;
			var aFilters = [];
			var oList;
			var sQuery = oEvent.getParameters().value;
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("Mtrnum", sap.ui.model.FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}
			oList = sap.ui.getCore().byId("listt");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters);
		},

		_handleValueHelpCloseTtr: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var orderInput = this.byId("hTtrId");
				orderInput.setValue(oSelectedItem.getTitle());
				this.fttr = oSelectedItem.getDescription();
			}
		},

		//Search functionality based on values in filters
		onSearch: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			this.oBusy = new sap.m.BusyDialog();
			this.oBusy.open();
			var that = this;
			var Flg = "1";
			var oDateTo = "";
			var oDatefrom = "";
			var Mtrnum = this.byId("hTtrId").getValue();
			var Status = this.byId("hstatusId").getSelectedKey();
			var Trans = this.byId("trsnMode").getSelectedKey();
			var date1 = this.byId("frDateid").getDateValue();
			var date2 = this.byId("toDateid").getDateValue();
			if(date1)
			{
			
			var date = new Date(date1.getUTCFullYear(), date1.getMonth(), date1.getUTCDate());
			var nDate = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			var oDatef = nDate.format(new Date(date));
			oDatefrom = oDatef + 'T00:00:00';
			}
			if(date2){
			
			 date = new Date(date2.getUTCFullYear(), date2.getMonth(), date2.getUTCDate());
			 nDate = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			 oDatef = nDate.format(new Date(date));
			oDateTo = oDatef + 'T00:00:00';
			}
			// oDetail.Lfdat = oDateout;
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter(
				"Mtrnum",
				sap.ui.model.FilterOperator.EQ, Mtrnum
			));
			aFilter.push(new sap.ui.model.Filter(
				"Flag",
				sap.ui.model.FilterOperator.EQ, Flg
			));
			aFilter.push(new sap.ui.model.Filter(
				"Tocontactaddress",
				sap.ui.model.FilterOperator.EQ, Trans
			));
			aFilter.push(new sap.ui.model.Filter(
				"Statuscomments",
				sap.ui.model.FilterOperator.EQ, Status
			));
			if(date1){
			
			aFilter.push(new sap.ui.model.Filter(
				"Dat1",
				sap.ui.model.FilterOperator.EQ, oDatefrom
			));
			}
			if(date2){
			
			aFilter.push(new sap.ui.model.Filter(
				"Dat2",
				sap.ui.model.FilterOperator.EQ, oDateTo
			));
			}
			oModel.read("/DraftitemsSet", {
				filters: aFilter,
				success: function(r) {
					oJSONModel.setProperty("/historyModel", r.results);
					oJSONModel.refresh("true");
					that.oBusy.close();
				},
				error: function() {
					MessageToast.show("Unable to get records, Please try again.");
					that.oBusy.close();
				}
			});
			// var i;
			// var oControl;
			// var filter;
			// var aFilter = [];
			// var aFilters = this.byId("filterBar").getFilterGroupItems();
			// var aFiltersWithValue = [];
			// for (i = 0; i < aFilters.length; i++) {
			// 	oControl = this.byId("filterBar").determineControlByFilterItem(aFilters[i]);
			// 	if (oControl && oControl.getValue && oControl.getValue()) {
			// 		aFiltersWithValue.push(aFilters[i]);
			// 		if (i === 0) {
			// 			filter = new Filter("Ebeln", sap.ui.model.FilterOperator.Contains, oControl.getValue());
			// 			aFilter.push(filter);
			// 		}
			// 		if (i === 1) {
			// 			var nDate = sap.ui.core.format.DateFormat.getDateInstance({
			// 				pattern: "yyyy-MM-dd"
			// 			});
			// 			var oDatef = nDate.format(new Date(oControl.getValue()));
			// 			var oDateout = oDatef + 'T00:00:00';
			// 			filter = new Filter("Eadat", sap.ui.model.FilterOperator.EQ, oDateout);
			// 			aFilter.push(filter);
			// 		}
			// 		if (i === 2) {
			// 			filter = new Filter("Lgort", sap.ui.model.FilterOperator.EQ, oControl.getSelectedKey());
			// 			aFilter.push(filter);
			// 		}
			// 		if (i === 3) {
			// 			filter = new Filter("Lifnr", sap.ui.model.FilterOperator.EQ, oControl.getSelectedKey());
			// 			aFilter.push(filter);
			// 		}
			// 	}
			// }

			// var oModel = this.getOwnerComponent().getModel();
			// JSONModel = this.getOwnerComponent().getModel("json");
			// var oSort = this.byId("sort");
			// sap.ui.core.BusyIndicator.show(0);
			// //read entityset SesHeaderSet 
			// oModel.read("/SesHeaderSet", {
			// 	filters: aFilter,
			// 	success: function(r) {
			// 		var oResults = r.results;
			// 		JSONModel.setProperty("/listDataModel", oResults);
			// 		if (oResults.length === 0) {
			// 			oSort.setEnabled(false);

			// 		} else {
			// 			oSort.setEnabled(true);
			// 		}
			// 		sap.ui.core.BusyIndicator.hide();
			// 	},
			// 	error: function() {
			// 		oSort.setEnabled(false);
			// 		sap.ui.core.BusyIndicator.hide();
			// 		MessageToast.show("Unable to retrieve data. Please try again.");
			// 	}
			// });
		},

		onChangeSel: function(oEvt) {
			this.sComb = this.byId("selComb").getSelectedKey();
			var oJsonModel = this.getOwnerComponent().getModel("json");
			oJsonModel.setProperty("/selKey", this.sComb);
			if (this.sComb === "K") {
				this.getOwnerComponent().getRouter().navTo("worklist", {});
				this.byId("selComb").setSelectedKey(oJsonModel.getProperty("/selKey"));
			}
			if (this.sComb === "T") {
				var confirmId = "confirmId";
				this.getOwnerComponent().getRouter().navTo("confirm", {
					confirmId: confirmId
				});
				this.byId("selComb").setSelectedKey(oJsonModel.getProperty("/selKey"));
			}
		},
		onDownloadPress: function(oEvent) {
			var mtrnum = oEvent.getSource().getBindingContext("json").getObject().Mtrnum;
			var oModel = this.getOwnerComponent().getModel();

			var sRead = "/sap/opu/odata/sap/ZMM_ODATA_TTR_NEW_SRV/pdfSet(Mtrnum='" + mtrnum + "')" + "/$value";
			oModel.read(sRead, {
				async: true,
				success: function(odata, response) {},
				error: function() {}
			});
			window.open(sRead, "Preview", "height=800,width=1000,left=50,top=50");
			// this.getOwnerComponent().getRouter().navTo("worklist", {});
			//	this.odialog.close();

		},
		// to filter table records based on created by
		onFilterCreatedBy: function() {
			if (!this.fDialog) {
				this.fDialog = sap.ui.xmlfragment("va.view.createdbyFilter", this);
				this.getView().addDependent(this.fDialog);
			}
			var c = [];
			var d = [];
			var oArray = this.getOwnerComponent().getModel("json").getData().historyModel;
			for (var i = 0; i < oArray.length; i++) {
				if (c.indexOf(oArray[i].Ernam) === -1) {
					c.push(oArray[i].Ernam);
				}
			}
			for (var j = 0; j < c.length; j++) {
				var object = {};
				object.Ernam = c[j];
				d.push(object);
			}
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oJSONModel.setProperty("/createdBy", d);

			var a = [];
			var b = [];
			for (var x = 0; x < oArray.length; x++) {
				if (a.indexOf(oArray[x].Maktx) === -1) {
					if (oArray[x].Maktx) {
						a.push(oArray[x].Maktx);
					}
				}
			}
			for (var y = 0; y < a.length; y++) {
				var obj = {};
				obj.Maktx = a[y];
				b.push(obj);
			}
			oJSONModel.setProperty("/tItem", b);
			var e = [];
			var f = [];
			for (var h = 0; h < oArray.length; h++) {
				if (e.indexOf(oArray[h].Statuscomments) === -1) {
					if (oArray[h].Statuscomments) {
						e.push(oArray[h].Statuscomments);
					}
				}
			}
			for (var k = 0; k < e.length; k++) {
				var objc = {};
				objc.Statuscomments = e[k];
				f.push(objc);
			}
			oJSONModel.setProperty("/status", f);

			this.fDialog.open();
		},
		onFilterCreatedByConfirm: function(oEvent) {

			// var params = oEvent.getParameters();
			// var aFilterItems = params.filterItems;
			// //	var oSelectedFilter = aFilterItems[0].getKey();

			// //	var aFilterItems = params.filterItems;
			// var iLength = aFilterItems.length;
			// var aFilter = [];
			// for (var i = 0; i < iLength; i++) {
			// 	if (params.filterItems[i].mBindingInfos.key.binding.sPath == "Ernam") {
			// 		if (params.filterItems[i].mBindingInfos.key.binding.oValue) {
			// 			aFilter.push(new sap.ui.model.Filter(
			// 				"Ernam",
			// 				sap.ui.model.FilterOperator.EQ, params.filterItems[i].mBindingInfos.key.binding.oValue
			// 			));
			// 		}
			// 	}
			// 	if (params.filterItems[i].mBindingInfos.key.binding.sPath == "Maktx") {
			// 		if (params.filterItems[i].mBindingInfos.key.binding.oValue) {
			// 			aFilter.push(new sap.ui.model.Filter(
			// 				"Maktx",
			// 				sap.ui.model.FilterOperator.EQ, params.filterItems[i].mBindingInfos.key.binding.oValue
			// 			));
			// 		}
			// 	}
			// 	if (params.filterItems[i].mBindingInfos.key.binding.sPath == "Ntdescription") {
			// 		if (params.filterItems[i].mBindingInfos.key.binding.oValue) {
			// 			aFilter.push(new sap.ui.model.Filter(
			// 				"Ntdescription",
			// 				sap.ui.model.FilterOperator.EQ, params.filterItems[i].mBindingInfos.key.binding.oValue
			// 			));
			// 		}
			// 	}
			// 	if (params.filterItems[i].mBindingInfos.key.binding.sPath == "Statuscomments") {
			// 		if (params.filterItems[i].mBindingInfos.key.binding.oValue) {
			// 			aFilter.push(new sap.ui.model.Filter(
			// 				"Statuscomments",
			// 				sap.ui.model.FilterOperator.EQ, params.filterItems[i].mBindingInfos.key.binding.oValue
			// 			));
			// 		}
			// 	}

			// 	var otable = this.byId("historyTable").getBinding("items").filter(aFilter);
			// }
			// //	var Matnr = this.sSearch;

		},

		/// navigation back to previous hash
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
			this.getOwnerComponent().getModel("json").setProperty("/selKey", "T");
		}
	});
});