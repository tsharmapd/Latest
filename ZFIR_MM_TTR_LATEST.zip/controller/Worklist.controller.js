sap.ui.define([
	"va/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"va/model/formatter",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/ui/model/FilterOperator"

], function(BaseController, JSONModel, History, formatter, MessageBox, Filter, MessageToast, FilterOperator) {
	"use strict";

	return BaseController.extend("va.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			this.getOwnerComponent().getRouter().getRoute("worklist").attachPatternMatched(this._onPatternMatched, this);
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show();
			// Set model for the first table display
			oModel.read("/SeachitemSet", {
				success: function(r) {
					oJSONModel.setProperty("/tableModel", r.results);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function() {}
			});
			// Get the rig number for inital
			oModel.read("/CheckflagSet('B')", {
				success: function(r, s) {
					oJSONModel.setProperty("/RigNum", r);

				}
			});
			// Get the flag for the record check
			oModel.read("/CheckflagSet('X')", {
				success: function(r) {
					oJSONModel.setProperty("/Flag", r);
				}
			});

			// Get the flag for the record check
			var that = this;
			oModel.read("/CheckflagSet('C')", {
				success: function(r) {
					oJSONModel.setProperty("/lostModel", r);
					var namew = r.Namew;
					that.plant = r.Werks;
					that.byId("plantId").setValue(namew);
					var aFilters = [];
					var werks = that.plant;
					var filter = new Filter("Werks", sap.ui.model.FilterOperator.EQ, werks);
					aFilters.push(filter);
					oModel.read("/SlocSet", {
						filters: aFilters,
						success: function(r) {
							oJSONModel.setProperty("/SlocSet", r.results);
							oJSONModel.refresh("true");
						}.bind(that)
					});

				}
			});
			// Dropdown for reason for transfer

			oModel.read("/ResasonSet", {
				success: function(r) {
					oJSONModel.setProperty("/ViewDrpdwn", r.results);
				}
			});
			// Get the plant for F4
			oModel.read("/PlantSet", {
				success: function(r) {
					oJSONModel.setProperty("/PlantSet", r.results);
				}
			});

			oJSONModel.refresh(true);

		},

		// oninital run
		_onPatternMatched: function() {

			var ojson = this.getOwnerComponent().getModel("json");
			// var namew = ojson.getProperty("/lostModel").Namew;
			// this.plant = ojson.getProperty("/lostModel").Werks;
			ojson.setProperty("/selKey", "K");
			if (ojson.getProperty("/clear") === "X") {
				ojson.setProperty("/clear", "");
				// this.byId("plantId").setValue(namew);
				this.byId("rigId").setValue("");
				this.byId("transId").setValue("");
				this.byId("logId").setValue("");
				this.byId("latId").setValue("");
				this.byId("wellId").setValue("");
				this.byId("lsdId").setValue("");
				this.byId("shipId").setValue("");
				this.byId("oprId").setValue("");
				this.byId("jobId").setValue("");
			}
			if (this.byId("selComb").getSelectedKey() === "K") {
				return;
			} else {
				this.byId("selComb").setSelectedKey(ojson.getProperty("/selKey"));
			}
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */
		onBatchChange: function(oEvent) {
			var value = oEvent.getSource().getValue();
			var ojson = this.getOwnerComponent().getModel("json");
			ojson.setProperty("/selBtch", value);
			var tabI = oEvent.getSource().getParent().getBindingContext("json").getPath().split("/")[2];
			this.byId("table").getItems()[tabI].getCells()[3].setValue(value);
		},
		// check for the batch dropdown and pass the filter as material plant storage location
		onBatch: function(oEvent) {
			var tabI = oEvent.getSource().getParent().getBindingContext("json").getPath().split("/")[2];
			var indx = parseInt(tabI);
			var matnr = this.getView().getModel("json").getData().tableModel[indx].Matnr;
			var oModel = this.getView().getModel();
			var ojson = this.getView().getModel("json");
			var plant = this.plant;
			var rig = this.log;
			var that = this;
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter(
				"Matnr",
				sap.ui.model.FilterOperator.EQ, matnr
			));
			aFilter.push(new sap.ui.model.Filter(
				"Werks",
				sap.ui.model.FilterOperator.EQ, plant
			));
			aFilter.push(new sap.ui.model.Filter(
				"Lgort",
				sap.ui.model.FilterOperator.EQ, rig
			));
			sap.ui.core.BusyIndicator.show();
			oModel.read("/TobatchSet", {
				filters: aFilter,
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					ojson.setProperty("/batchModel" + indx, r.results);
					that.byId("table").getItems()[indx].getCells()[3].bindItems("json>/batchModel" + indx,
						new sap.ui.core.ListItem({
							key: "{json>Tocharg}",
							text: "{json>Tocharg}"
						}));
				}.bind(this),

				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}

			});
		},
		onRftChange: function(oEvent) {
			var value = oEvent.getSource().getValue();
			var ojson = this.getOwnerComponent().getModel("json");
			ojson.setProperty("/selRft", value);
			var tabI = oEvent.getSource().getParent().getBindingContext("json").getPath().split("/")[2];
			this.byId("table").getItems()[tabI].getCells()[5].setValue(value);
		},
		onDiscard: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var oRecord = this.getView().getModel("json").getData().Flag[0];
			var Mtr = "";
			var olinenum = "";
			var flag = "X";
			Mtr = oRecord.Mtr;
			// var srecord = oRecord.Guid;

			oModel.remove("/DraftitemsSet(Mtrnum='" + Mtr + "',Item='" + olinenum + "',Flag='" + flag + "')", {
				success: function(data, response) {
					MessageBox.success("Draft item successfully removed ");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							oJSONModel.setProperty("/Flag", r);
						}
					});
					oJSONModel.refresh("true");
				},
				error: function() {

					MessageBox.error("Unable to delete records from cartData. Please try again.");
				}
			});
			oJSONModel.refresh();
			this.oInitalDialog.close();
		},

		OnLostHole: function(oevent) {
			var that = this;
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var Flag = oJSONModel.getProperty("/Flag").Flag;
			var namel = oJSONModel.getProperty("/lostModel").Namel;
			var namew = oJSONModel.getProperty("/lostModel").Namew;
			this.plant = oJSONModel.getProperty("/lostModel").Werks;
			this.log = oJSONModel.getProperty("/lostModel").Lgort;
			if (Flag === "X") {
				if (!this._ochangeDialog) {
					this._ochangeDialog = sap.ui.xmlfragment("va.view.changeDialog", this);
					this.getView().addDependent(this._ochangeDialog);

				}
				this._ochangeDialog.open();
			}
			if (Flag !== "X") {
				if (oevent.getSource().getSelected()) {
					that.byId("job").setVisible(true);
					that.byId("jobId").setVisible(true);
					that.byId("opr").setVisible(true);
					that.byId("oprId").setVisible(true);
					that.byId("well").setVisible(true);
					that.byId("wellId").setVisible(true);
					that.byId("lsd").setVisible(true);
					that.byId("lsdId").setVisible(true);
					that.byId("lat").setVisible(true);
					that.byId("latId").setVisible(true);
					that.byId("log").setVisible(true);
					that.byId("logId").setVisible(true);
					that.byId("LsnId").setVisible(true);
					that.byId("toBatchid").setVisible(false);
					that.byId("ship").setVisible(false);
					that.byId("shipId").setVisible(false);
					that.byId("plantId").setEditable(false);
					that.byId("rigId").setEditable(false);
					that.byId("trans").setLabel("Lost in Hole Date");
					that.byId("resId").setVisible(false);
					that.byId("plantId").setValue(namew);
					that.byId("rigId").setValue(namel);
				}
			}

		},
		// Dismiss for the Radio button
		onDis: function() {
			var that = this;
			var rig = this.byId("rbMngd").getSelected();
			if (rig === false) {
				this.byId("rbMngd").setSelected(true);
				this.byId("rbNMngd").setSelected(false);
				that._ochangeDialog.close();
			} else {
				var lost = this.byId("rbNMngd").getSelected();
				if (lost === false) {
					this.byId("rbMngd").setSelected(false);
					this.byId("rbNMngd").setSelected(true);
					that._ochangeDialog.close();
				}
			}
		},

		// on continue for the Radio Button		
		onContinue: function() {
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var mtr = oJSONModel.getProperty("/Flag").Mtrnum;
			var olinenum = "";
			var flag = "X";
			oModel.remove("/DraftitemsSet(Mtrnum='" + mtr + "',Item='" + olinenum + "',Flag='" + flag + "')", {
				success: function(data, response) {
					sap.ui.core.BusyIndicator.hide();
					oModel.read("/DraftitemsSet", {
						success: function(r, s) {
							oJSONModel.setProperty("/cartModel", r.results);
						}
					});
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
						}
					});
					oJSONModel.refresh("true");
				}
			});
			var lost = this.byId("rbNMngd").getSelected();
			if (lost === true) {
				that.byId("job").setVisible(true);
				that.byId("jobId").setVisible(true);
				that.byId("opr").setVisible(true);
				that.byId("oprId").setVisible(true);
				that.byId("well").setVisible(true);
				that.byId("wellId").setVisible(true);
				that.byId("lsd").setVisible(true);
				that.byId("lsdId").setVisible(true);
				that.byId("lat").setVisible(true);
				that.byId("latId").setVisible(true);
				that.byId("log").setVisible(true);
				that.byId("logId").setVisible(true);
				that.byId("LsnId").setVisible(true);
				that.byId("plantId").setEditable(false);
				that.byId("rigId").setEditable(false);
				that.byId("trans").setLabel("Lost in Hole Date");
				that.byId("toBatchid").setVisible(false);
				that.byId("ship").setVisible(false);
				that.byId("shipId").setVisible(false);
			} else {
				lost = this.byId("rbMngd").getSelected();
				if (lost === true) {
					that.byId("job").setVisible(false);
					that.byId("jobId").setVisible(false);
					that.byId("opr").setVisible(false);
					that.byId("oprId").setVisible(false);
					that.byId("well").setVisible(false);
					that.byId("wellId").setVisible(false);
					that.byId("lsd").setVisible(false);
					that.byId("lsdId").setVisible(false);
					that.byId("lat").setVisible(false);
					that.byId("latId").setVisible(false);
					that.byId("log").setVisible(false);
					that.byId("logId").setVisible(false);
					that.byId("LsnId").setVisible(false);
					// that.byId("toBatchid").setVisible(true);
					that.byId("plantId").setEditable(true);
					that.byId("rigId").setEditable(true);
					that.byId("ship").setVisible(true);
					that.byId("shipId").setVisible(true);
					that.byId("trans").setLabel("Transfer Date");
				}
			}
			that._ochangeDialog.close();
		},

		onTrnsfrRig: function(oevent) {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var namew = oJSONModel.getProperty("/lostModel").Namew;
			this.plant = oJSONModel.getProperty("/lostModel").Werks;
			var that = this;

			var Flag = oJSONModel.getProperty("/Flag").Flag;
			if (Flag === "X") {
				if (!this._ochangeDialog) {
					this._ochangeDialog = sap.ui.xmlfragment("va.view.changeDialog", this);
					this.getView().addDependent(this._ochangeDialog);
				}
				this._ochangeDialog.open();
			}
			if (Flag !== "X") {
				if (oevent.getSource().getSelected()) {
					that.byId("job").setVisible(false);
					that.byId("jobId").setVisible(false);
					that.byId("opr").setVisible(false);
					that.byId("oprId").setVisible(false);
					that.byId("well").setVisible(false);
					that.byId("wellId").setVisible(false);
					that.byId("lsd").setVisible(false);
					that.byId("lsdId").setVisible(false);
					that.byId("lat").setVisible(false);
					that.byId("latId").setVisible(false);
					that.byId("log").setVisible(false);
					that.byId("logId").setVisible(false);
					that.byId("LsnId").setVisible(false);
					// that.byId("toBatchid").setVisible(true);
					that.byId("resId").setVisible(false);
					that.byId("plantId").setEditable(true);
					that.byId("plantId").setValue(namew);
					that.byId("rigId").setValue("");
					that.byId("rigId").setEditable(true);
					that.byId("trans").setLabel("Transfer Date");
					that.byId("ship").setVisible(true);
					that.byId("shipId").setVisible(true);
					this.log = "";
					// that.byId("wbsId").setVisible(true);
				}

			}

		},

		OnNonTrackItemPress: function(oEvent) {
			var shText = this.byId("plantId");
			if (shText.getValue() === "") {
				shText.setValueState("Error");
				MessageBox.error("Enter the Plant");
			} else {
				shText.setValueState("None");
				var rig = this.byId("rigId");
				if (rig.getValue() === "") {
					rig.setValueState("Error");
					MessageBox.error("Enter the Rig Number");
				} else {
					rig.setValueState("None");
					if (!this._oAddNonTrack) {
						this._oAddNonTrack = sap.ui.xmlfragment("va.view.AddNonTrack", this);
						this.getView().addDependent(this._oAddNonTrack);
					}
					this._oAddNonTrack.open();
				}
			}
		},

		onCancelpDialog: function() {
			var that = this;
			that._oAddNonTrack.close();

		},
		// Open value help for plant
		handleValueHelp: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment("va.view.ValueHelp", this);
				this.getView().addDependent(this._valueHelpDialog);
			}
			this._valueHelpDialog.getBinding("items").filter([new Filter(
				"Name",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);
			this._valueHelpDialog.open(sInputValue);

		},
		//Open value help for Rig
		handleValueHp: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHpDialog) {
				this._valueHpDialog = sap.ui.xmlfragment("va.view.ValueHp", this);
				this.getView().addDependent(this._valueHpDialog);
			}
			this._valueHpDialog.getBinding("items").filter([new Filter(
				"Name",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);
			this._valueHpDialog.open(sInputValue);
		},
		// get the value for Rig
		_handleValueHpClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var ojson = this.getView().getModel("json");
				var f = [];
				var orderInput = this.byId("rigId");
				orderInput.setValue(oSelectedItem.getTitle());
				this.log = oSelectedItem.getDescription();
				var rig = this.log;
				var string = "Y";
				// var show = rig.includes(string);
				var show = rig.indexOf(string);
				if (show === 0) {
					this.byId("resId").setVisible(true);
					// this.riglog = "X";
				} else {
					this.byId("resId").setVisible(false);
					// this.riglog = "";
				}
				var oModel = this.getOwnerComponent().getModel("json").getData().tableModel;
				for (var i = 0; i < oModel.length; i++) {
					ojson.setProperty("/batchModel" + i, f);
				}
			}
		},
		// Get the value for Plant
		_handleValueHelpClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var orderInput = this.byId("plantId");
				orderInput.setValue(oSelectedItem.getTitle());
				this.plant = oSelectedItem.getDescription();
				if (this.plant !== "") {
					this.byId("rigId").setEditable(true);
					var oModel = this.getOwnerComponent().getModel();
					var oJSONModel = this.getOwnerComponent().getModel("json");
					var aFilters = [];
					var werks = this.plant;
					var filter = new Filter("Werks", sap.ui.model.FilterOperator.EQ, werks);
					aFilters.push(filter);
					oModel.read("/SlocSet", {
						filters: aFilters,
						success: function(r) {
							oJSONModel.setProperty("/SlocSet", r.results);
							oJSONModel.refresh("true");
						}.bind(this)
					});
				}
			}
		},

		// to filter live change values in value help
		_handleLiveChange: function(oEvent) {
			var sId = oEvent.getParameters().id;
			var aFilters = [];
			var oList;
			var sQuery = oEvent.getParameters().value;
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("Name", sap.ui.model.FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}
			if (sId === "list1") {
				oList = sap.ui.getCore().byId("list1");
			} else {
				oList = sap.ui.getCore().byId("list");
			}
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters);
		},

		onAddToCartPressed: function(oEvent) {
			var error = "";
			var shText = this.byId("plantId");
			var table = oEvent.getSource().getParent().getParent().getParent();
			var items = oEvent.getSource().getParent().getParent();
			var index = table.indexOfItem(items);
			var rgNum = this.byId("rbNMngd").getSelected();
			if (rgNum === true) {
				if (this.byId("jobId").getValue() === "") {
					this.byId("jobId").setValueState("Error");
					MessageBox.error("Enter the Job Number");
					error = "X";
				} else {
					error = "";
					this.byId("jobId").setValueState("None");
					if (this.byId("oprId").getValue() === "") {
						this.byId("oprId").setValueState("Error");
						MessageBox.error("Enter the Operator");
						error = "X";
					} else {
						error = "";
						this.byId("oprId").setValueState("None");
						if (this.byId("wellId").getValue() === "") {
							this.byId("wellId").setValueState("Error");
							MessageBox.error("Enter the Well Name");
							error = "X";
						} else {
							error = "";
							this.byId("wellId").setValueState("None");
							var lostNo = table.getItems()[index].getCells()[9].mProperties.value;
							if (lostNo === "") {
								MessageBox.error("Enter Lost Serial Number");
								error = "X";
							} else {
								error = "";
								this.byId("wellId").setValueState("None");
								this.byId("oprId").setValueState("None");
								this.byId("jobId").setValueState("None");
	
							}
						}
					}

				}
			}
			if (shText.getValue() === "") {
				shText.setValueState("Error");
				MessageBox.error("Enter the Plant");
			} else {
				shText.setValueState("None");
				var date = this.byId("transId");
				if (date.getValue() === "") {
					date.setValueState("Error");
					MessageBox.error("Enter the Date");
				} else {
					date.setValueState("None");
					var rig = this.byId("rigId");
					if (rig.getValue() === "") {
						rig.setValueState("Error");
						MessageBox.error("Enter the Rig Number");
					} else {
						rig.setValueState("None");
						var objData = oEvent.getSource().getParent().getBindingContext("json").getObject();
						var Qty = table.getItems()[index].getCells()[6].mProperties.value;
						if (Qty === "0" || Qty === "" || Qty < 1) {
							MessageBox.warning("Quantity should not be Empty or Zero");
						} else {

							if (error === "") {
								// Item Level Data
								var cartData = {};
								var selectedStatus = table.getItems()[index].getCells()[5].mProperties.value;
								cartData.Reasoncode = selectedStatus;
								cartData.Matnr = objData.Matnr;
								// cartData.Knttp = this.byId("selComb").getSelectedKey();
								cartData.Maktx = objData.Description;
								cartData.Charg = objData.Condition;
								cartData.EntryQty = table.getItems()[index].getCells()[6].mProperties.value;
								cartData.Type = objData.Type;
								cartData.Menge = objData.Availqty;
								cartData.Comments = table.getItems()[index].getCells()[7].mProperties.value;
								cartData.Lostno = table.getItems()[index].getCells()[9].mProperties.value;
								cartData.Towerks = this.plant;
								cartData.Shipmentinfo = this.getView().byId("shipId").getValue();
								cartData.Tolgort = this.log;
								var radio = this.byId("rbMngd").getSelected();
								if (radio === false) {
									cartData.Transfermode = "B";
								} else {
									cartData.Transfermode = "A";
								}
								// Header Level Data
								cartData.Wellname = this.getView().byId("wellId").getValue();
								cartData.Jobnumber = this.getView().byId("jobId").getValue();
								cartData.Operator = this.getView().byId("oprId").getValue();
								cartData.Lsd = this.getView().byId("lsdId").getValue();
								cartData.Tolongitude = this.getView().byId("logId").getValue();
								cartData.Tolatitude = this.getView().byId("latId").getValue();
								var oModel = this.getOwnerComponent().getModel();
								var oJSONModel = this.getOwnerComponent().getModel("json");
								var that = this;
								sap.ui.core.BusyIndicator.show(0);
								oModel.create("/DraftitemsSet", cartData, {

									success: function(oData, oResponse) {
										// MessageToast.show("Item added to cart");
										oModel.read("/CheckflagSet('X')", {
											success: function(r) {
												oJSONModel.setProperty("/Flag", r);
												oJSONModel.refresh("true");
												MessageToast.show("Item added to cart");
												sap.ui.core.BusyIndicator.hide();
											}

										});
										oModel.read("/SeachitemSet", {
											success: function(r) {
												oJSONModel.setProperty("/tableModel", r.results);
												that.getView().byId("Idcb2").setSelectedKey(""); //this.getView().byId("Idcb2").getSelectedKey()
												that.getView().byId("Idcb1").setSelectedKey(""); //this.getView().byId("Idcb2").getSelectedKey()
												for (var i = 0; i < that.byId("table").getItems().length; i++) {
													that.byId("table").getItems()[i].getCells()[3].setValue("");
													that.byId("table").getItems()[i].getCells()[3].setSelectedKey("");
													that.byId("table").getItems()[i].getCells()[5].setValue("");
													that.byId("table").getItems()[i].getCells()[5].setSelectedKey("");
													that.byId("table").getItems()[i].getCells()[6].setValue("");
													that.byId("table").getItems()[i].getCells()[7].setValue("");
													that.byId("table").getItems()[i].getCells()[9].setValue("");
												}
											},
											error: function() {}
										});
										oJSONModel.refresh(true);
										// to update the table with the new item created  
										oModel.read("/DraftitemsSet", {
											success: function(r, s) {
												oJSONModel.setProperty("/cartModel", r.results);
												sap.ui.core.BusyIndicator.hide();

											}
										});
										oJSONModel.refresh(true);
									},
									error: function(oError) {
										sap.ui.core.BusyIndicator.hide();
										jQuery.sap.require("sap.m.MessageBox");
										sap.m.MessageBox.show((JSON.parse(oError.responseText).error.message.value), {
											icon: sap.m.MessageBox.Icon.Information,
											title: "Message Box"
										});
									}
								});
							}
						}
					}
				}
			}
		},
		onQtyChange: function(oevent) {
			var tabI = oevent.getSource().getParent().getBindingContext("json").getPath().split("/")[2];
			var ojson = this.getOwnerComponent().getModel("json");
			var rft = ojson.getProperty("/selRft");
			var btc = ojson.getProperty("/selBtch");

			this.getView().byId("Idcb2").setSelectedKey(rft); //this.getView().byId("Idcb2").getSelectedKey()
			this.getView().byId("Idcb1").setSelectedKey(btc); //this.getView().byId("Idcb2").getSelectedKey()
			this.byId("table").getItems()[tabI].getCells()[3].setValue(btc);
			this.byId("table").getItems()[tabI].getCells()[3].setSelectedKey(btc);
			this.byId("table").getItems()[tabI].getCells()[5].setValue(rft);
			this.byId("table").getItems()[tabI].getCells()[5].setSelectedKey(rft);
		},
		onRigchange: function() {
			// var rig = this.byId("rigId").getValue();
			var rig = this.log;
			var string = "Y";
			var show = rig.includes(string);
			if (show === false) {
				this.byId("resId").setVisible(false);
				this.riglog = "X";
			} else {
				this.byId("resId").setVisible(true);
				this.riglog = "";
			}
		},
		onCreateItemPress: function(oEvent) {
			var canProceed = true;
			var shText = sap.ui.getCore().byId("shtextId");
			if (shText.getValue() === "") {
				shText.setValueState("Error");
				shText.setValueStateText("Enter Material");
				canProceed = false;
			}

			var qtyVal = sap.ui.getCore().byId("qtyId");
			if (qtyVal.getValue() === "") {
				qtyVal.setValueState("Error");
				qtyVal.setValueStateText("Enter Quantity");
				canProceed = false;
			}
			// if (canProceed === "true") {
			var addToCart = {};
			//	addToCart.Knttp = accAsgn;
			addToCart.Ntdescription = shText.getValue();
			addToCart.Ntentryqty = qtyVal.getValue();
			addToCart.Towerks = this.plant;
			addToCart.Tolgort = this.log;
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.create("/DraftitemsSet", addToCart, {
				success: function(oData, oResponse) {
					MessageToast.show("Item added to cart");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							oJSONModel.setProperty("/Flag", r);
							oJSONModel.refresh("true");
							MessageToast.show("Item added to cart");
							sap.ui.core.BusyIndicator.hide();
						}

					});
					sap.ui.getCore().byId("shtextId").setValue("");
					sap.ui.getCore().byId("shtextId").setValueState("None");
					sap.ui.getCore().byId("qtyId").setValue("");
					sap.ui.getCore().byId("qtyId").setValueState("None");
					// to update the table with the new item created  
					oModel.read("/DraftitemsSet", {
						success: function(r, s) {
							oJSONModel.setProperty("/cartModel", r.results);
							sap.ui.core.BusyIndicator.hide();
						}
					});
					oJSONModel.refresh(true);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		// },

		//// shopping cart button opens dialog with draft items
		onShoppingCartPressed: function(oEvent) {

			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show();
			this.getOwnerComponent().getModel().read("/DraftitemsSet", {
				success: function(r) {

					oJSONModel.setProperty("/cartModel", r.results);
					sap.ui.core.BusyIndicator.hide();
				}
			});

			if (!this.ocartPress) {
				this.ocartPress = sap.ui.xmlfragment("va.view.ShoppingCart", this);
				this.getView().addDependent(this.ocartPress);
			}

			this.ocartPress.open();
		},

		//// on delete pressed of the dialog draft items//
		onDeletePressed: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var selctdItem = oEvent.getParameter("listItem").getBindingContext("json").getObject();
			var olinenum = selctdItem.Item;
			var Guid = selctdItem.Mtrnum;
			var flag = "X";
			//	sap.ui.core.BusyIndicator.show(0);
			oModel.remove("/DraftitemsSet(Mtrnum='" + Guid + "',Item='" + olinenum + "',Flag='" + flag + "')", {
				success: function(data, response) {
					sap.ui.core.BusyIndicator.hide();
					oModel.read("/DraftitemsSet", {
						success: function(r, s) {
							oJSONModel.setProperty("/cartModel", r.results);
						}
					});
					MessageToast.show("Draft item successfully removed from cart");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
						}
					});
					oJSONModel.refresh("true");
				}
			});
		},

		///// cart dialog cancel closes dialog
		cancel: function() {
			this.ocartPress.close();
		},

		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		//// navigation on View cart press on cart dialog
		ViewCart: function(oEvt) {
			var cartId = "cartId";
			this.getOwnerComponent().getRouter().navTo("cart", {
				cartId: cartId
			});
		},

		onChangeSel: function(oEvt) {
			this.sComb = this.byId("selComb").getSelectedKey();
			var oJsonModel = this.getOwnerComponent().getModel("json");
			oJsonModel.setProperty("/selKey", this.sComb);
			if (this.sComb === "T") {
				var confirmId = "confirmId";
				this.getOwnerComponent().getRouter().navTo("confirm", {
					confirmId: confirmId
				});
				this.byId("selComb").setSelectedKey(oJsonModel.getProperty("/selKey"));
			}
			if (this.sComb === "R") {
				var historyId = "historyId";
				this.getOwnerComponent().getRouter().navTo("history", {
					historyId: historyId
				});
				this.byId("selComb").setSelectedKey(oJsonModel.getProperty("/selKey"));
			}
		}

	});
});