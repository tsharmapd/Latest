sap.ui.define([
	"pd/fr/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"pd/fr/model/formatter",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/FilterOperator"

], function(BaseController, JSONModel, History, formatter, Filter, MessageToast, MessageBox, FilterOperator) {
	"use strict";

	return BaseController.extend("pd.fr.controller.Worklist", {

		formatter: formatter,
		//to hide the table and filter bar before rendering the view 
		onBeforeRendering: function() {
			//To make the initial visibility to false before Receipt type selection
			this.byId("HboxId").setVisible(false);
			this.byId("idProductsTable").setVisible(false);
			var ojson = this.getOwnerComponent().getModel("json");
			ojson.setProperty("/postBtnVisibility", false);
			ojson.setProperty("/attachBtnVisibility", false);
			ojson.setProperty("/clearBtnVisibility", false);
		},
		// to handle Receipt type selection, Visibilty of all the controls is set during this selection.
		handleSelectionChange: function(oEvent) {
			//TJ Post Go live
				this.refreshTable();
			this.resetAll();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			this.byId("cmb2").removeAllItems();
			oJSONModel.refresh(true);
			oJSONModel.setProperty("/postBtnVisibility", true);
			oJSONModel.setProperty("/attachBtnVisibility", true);
			oJSONModel.setProperty("/clearBtnVisibility", true);
			if (oEvent.getSource().getSelectedItem() !== null) {
				var key = oEvent.getSource().getSelectedItem().getProperty("key");

				this.byId("MsgStrip").setVisible(false);
			} else {
				key = "";
				oJSONModel.setProperty("/viewImage", true);

			}
			var that = this;
			that.resetAll();
			that.refreshTable();
			// to handle Fuel Receipt selection
			if (key === "F") {
				var fFlag = true;
				this.refreshTable();
				this.resetAll();
				this.byId("page").setTitle("Fuel Receipt");
				this.byId("pnlId").setVisible(true);
				this.byId("pnlIdNoPnl").setVisible(false);
				this.byId("wbsi").setVisible(false);
				this.byId("delDtBox").setVisible(true);
				this.byId("HboxId").setVisible(true);
				this.byId("RgTypId").setSelectedKey();
				this.byId("LcId").setSelectedKey();
				// this.byId("rbMngd").setSelected(true);
				this.byId("rbMngd").setSelected(false);
				this.byId("rbNMngd").setSelected(false);
				var today = new Date();
				this.byId("delvyDt").setDateValue(today);
				this.byId("vndrBox").setVisible(true);
				this.byId("MvBox").setVisible(false);
				this.byId("idProductsTable").setVisible(true);
				this.populateRigStorage();
				this.populateVendor();
				var oJSONModel = that.getOwnerComponent().getModel("json");
				oJSONModel.setProperty("/tabI", undefined);
				oJSONModel.setProperty("/sRig", "");
				oJSONModel.setProperty("/sLoc", "");
				sap.ui.core.BusyIndicator.show(0);
				/*setting visibility of the receipt types in global*/
				var oView2 = {
					fuelRcpt: true,
					tankDips: false,
					pumpOut: false,
					lubricants: false
				};
				oEvent.getSource().setSelectedKey(key);
				oJSONModel.setProperty("/viewImage", false);
				oJSONModel.setProperty("/oViewModel", oView2);
				this.populateMaterial();
				this.MaterialInitialLoad();
				oJSONModel.refresh(true);
				sap.ui.core.BusyIndicator.hide();
				var flagMsg = false;
			} else {
				//to handle Tank dips selection
				if (key === "T") {
					this.refreshTable();
					this.resetAll();
					this.byId("page").setTitle("Tank Dips");
					this.byId("delDtBox").setVisible(false);
					this.byId("HboxId").setVisible(true);
					this.byId("pnlId").setVisible(false);
					this.byId("wbsi").setVisible(false);
					this.byId("pnlIdNoPnl").setVisible(true);
					this.byId("RgTypId").setSelectedKey();
					this.byId("LcId").setSelectedKey();
					// this.byId("vndrBox").setVisible(true);
					this.byId("vndrBox").setVisible(false);
					this.byId("MvBox").setVisible(false);
					// this.byId("rbMngd").setSelected(true);
					this.byId("rbMngd").setSelected(false);
					this.byId("rbNMngd").setSelected(false);
					this.populateRigStorage();
					this.populateVendor();
					var today = new Date();
					this.byId("toDt").setDateValue(today);
					var oJSONModel = that.getView().getModel("json");
					oJSONModel.setProperty("/tabI", undefined);
					oJSONModel.setProperty("/showCart", undefined);
					oJSONModel.setProperty("/sRig", "");
					oJSONModel.setProperty("/sLoc", "");
					sap.ui.core.BusyIndicator.show(0);
					var oView3 = {
						fuelRcpt: false,
						tankDips: true,
						pumpOut: false,
						lubricants: false
					};
					oEvent.getSource().setSelectedKey(key);
					oJSONModel.setProperty("/viewImage", false);
					oJSONModel.setProperty("/oViewModel", oView3);
					this.populateMaterial();
					this.MaterialInitialLoad();
					oJSONModel.refresh(true);
					sap.ui.core.BusyIndicator.hide();
				}
				// to handle Lubricants selection
				if (key == "L") {
					this.refreshTable();
					this.resetAll();
					this.byId("page").setTitle("Lubricants");
					this.byId("pnlId").setVisible(false);
					this.byId("pnlIdNoPnl").setVisible(true);
					this.byId("HboxId").setVisible(true);
					this.byId("delDtBox").setVisible(true);
					this.byId("wbsi").setVisible(false);
					this.byId("RgTypId").setSelectedKey();
					this.byId("LcId").setSelectedKey();
					this.byId("vndrBox").setVisible(true);
					this.byId("MvBox").setVisible(false);
					// this.byId("rbMngd").setSelected(true);
					this.byId("rbMngd").setSelected(false);
					this.byId("rbNMngd").setSelected(false);
					this.populateRigStorage();
					this.populateVendor();
					var today = new Date();
					this.byId("delvyDt").setDateValue(today);
					var oJSONModel = this.getOwnerComponent().getModel("json");
					oJSONModel.setProperty("/tabI", undefined);
					oJSONModel.setProperty("/showCart", undefined);
					sap.ui.core.BusyIndicator.show(0);
					var oView2 = {
						fuelRcpt: false,
						tankDips: false,
						pumpOut: false,
						lubricants: true
					};
					oEvent.getSource().setSelectedKey(key);
					oJSONModel.setProperty("/viewImage", false);
					oJSONModel.setProperty("/oViewModel", oView2);
					this.populateMaterial();
					this.MaterialInitialLoad();
					oJSONModel.setProperty("/sRig", "");
					oJSONModel.setProperty("/sLoc", "");
					oJSONModel.setProperty("/tabI", undefined);
					oJSONModel.setProperty("/showCart", undefined);
					oJSONModel.refresh();
					sap.ui.core.BusyIndicator.hide();
					var flagMsg = false;
				}
				//to handle Pump out selection
				if (key == "P") {
					this.refreshTable();
					this.resetAll();
					that.byId("delDtBox").setVisible(true);
					that.byId("pnlId").setVisible(false);
					this.byId("pnlIdNoPnl").setVisible(false);
					that.byId("page").setTitle("Pump Out");
					that.byId("HboxId").setVisible(true);
					// this.byId("rbMngd").setSelected(true);
					this.byId("rbMngd").setSelected(false);
					this.byId("rbNMngd").setSelected(false);
					that.byId("RgTypId").setSelectedKey();
					that.byId("LcId").setSelectedKey();
			
					if (that.byId("rbTtoR").getSelected()) {
						that.byId("vndrBox").setVisible(false);
						that.byId("MvBox").setVisible(true);
						that.byId("wbsi").setVisible(true);
					}else
					{
							that.byId("vndrBox").setVisible(true);
					}
					var today = new Date();
					this.byId("delvyDt").setDateValue(today);
					this.populateRigStorage();
					this.populateVendor();
					this.populateMaterial();
					this.MaterialInitialLoad();
					var oJSONModel = that.getView().getModel("json");
					oJSONModel.setProperty("/tabI", undefined);
					oJSONModel.setProperty("/showCart", undefined);
					sap.ui.core.BusyIndicator.show(0);
					var oView2 = {
						fuelRcpt: false,
						tankDips: false,
						pumpOut: true,
						lubricants: false
					};
					oEvent.getSource().setSelectedKey(key);
					oJSONModel.setProperty("/viewImage", false);
					oJSONModel.setProperty("/oViewModel", oView2);
					oJSONModel.setProperty("/sRig", "");
					oJSONModel.refresh();
					sap.ui.core.BusyIndicator.hide();
				}
			}
		},

		//on return to supplier radio btn selection
		onTrnsfrtoRig: function() {
			var that = this;
			var flag;
			this.byId("wbsi").setVisible(true);
			this.byId("loc").setVisible(false);
			//check if data input available then show a pop-up to confirm
			var checkData = that.byId("pmpOutTable").getItems()[0].getCells();
			for (var i = 0; i < checkData.length; i++) {
				if (!flag) {
					if (i !== 5 && i !== 6 && i !== 7) {
						if (i === 0 || i === 1 || i === 2 || i === 3 || i === 4) {
							if (checkData[i].getSelectedKey()) {
								flag = true;
							}
						} else {
							if (checkData[i].getValue()) {
								flag = true;
							}
						}
					}
				}
			}
			if (flag) {
				MessageBox.confirm(
					"Data will be lost", {
						onClose: function(oAction) {
							if (oAction === "OK") {
								that.refreshTable();
								that.resetAll();
								if (that.byId("rbRtoS").getSelected()) {
									that.byId("vndrBox").setVisible(true);
									that.byId("MvBox").setVisible(false);
									that.byId("wbsId").setVisible(false);
								} else {
									that.byId("vndrBox").setVisible(false);
									that.byId("MvBox").setVisible(true);
									that.byId("wbsId").setVisible(false);
								}
							} else {
								var rbnm = that.byId("rbTtoR").getSelected();
								if (!rbnm) {
									that.byId("rbTtoR").setSelected(true);
									that.byId("rbRtoS").setSelected(false);
									that.byId("vndrBox").setVisible(false);
									that.byId("MvBox").setVisible(true);
									that.byId("wbsId").setVisible(false);
								} else {
									that.byId("rbTtoR").setSelected(false);
									that.byId("rbRtoS").setSelected(true);
									that.byId("vndrBox").setVisible(true);
									that.byId("MvBox").setVisible(false);
									that.byId("wbsId").setVisible(false);
								}
							}
						}
					});
			} else {
				if (that.byId("rbRtoS").getSelected()) {
					that.byId("vndrBox").setVisible(true);
					that.byId("MvBox").setVisible(false);
					that.byId("wbsId").setVisible(false);
				} else {
					that.byId("vndrBox").setVisible(false);
					that.byId("MvBox").setVisible(true);
					that.byId("wbsId").setVisible(false);
				}
			}
			this.populateMaterial();
		},
		onRtntoSupp: function() {
			this.byId("wbsi").setVisible(false);
			this.byId("loc").setVisible(true);
		},
		NonMngdSelected: function(oEvent) {
			var that = this;
			// //check if data input available then show a pop-up to confirm
			// var flag;
			// //check if data input available then show a pop-up to confirm
			// var checkData = that.byId("idProductsTable").getItems()[0].getCells();
			// for (var i = 0; i < checkData.length; i++) {
			// 	if (!flag) {
			// 		if (i !== 4 && i !== 5) {
			// 			if (i === 0 || i === 1 || i === 2) {
			// 				if (checkData[i].getSelectedKey()) {
			// 					flag = true;
			// 				}
			// 			} else {
			// 				if (checkData[i].getValue()) {
			// 					flag = true;
			// 				}

			// 			}
			// 		}
			// 	}
			// }
			// if (flag) {
			// 	MessageBox.confirm(
			// 		"Data will be lost", {
			// 			onClose: function(oAction) {
			// 				if (oAction === "OK" ) {
			// 					that.refreshTable();
			// 					that.resetAll();
			// 				} else {
			// 					var rbnm = that.byId("rbNMngd").getSelected();
			// 					if (!rbnm) {
			// 						that.byId("rbNMngd").setSelected(true);
			// 						that.byId("rbMngd").setSelected(false);
			// 					} else {
			// 						that.byId("rbNMngd").setSelected(false);
			// 						that.byId("rbMngd").setSelected(true);
			// 					}
			// 				}
			// 			}
			// 		});
			// }
			if (oEvent.getSource().getSelected()) {
				that.populateMaterial();
			}
		},
		MngdSelected: function(oEvent) {
				var that = this;
					if (oEvent.getSource().getSelected()) {
				that.populateMaterial();
			}
		},
		// to refresh the table items
		refreshTable: function() {
			var model = this.getOwnerComponent().getModel("json");
			var that = this;
			if (model.getProperty("/oViewModel").fuelRcpt) {
				that._oTable = that.byId('idProductsTable');
				for (var i = 0; i < that._oTable.getItems().length; i++) {
					that._oTable.getItems()[i].getCells()[0].setValue("");
					that._oTable.getItems()[i].getCells()[0].setSelectedKey("");
					that._oTable.getItems()[i].getCells()[1].setValue("");
					that._oTable.getItems()[i].getCells()[1].setSelectedKey("");
					that._oTable.getItems()[i].getCells()[2].setValue("");
					that._oTable.getItems()[i].getCells()[3].setValue("");
					that._oTable.getItems()[i].getCells()[4].setText("");
					that._oTable.getItems()[i].getCells()[5].mAggregations.items[2].setVisible(false);
				}
			} else if (model.getProperty("/oViewModel").pumpOut) {
				that._oTable = that.byId('pmpOutTable');
				for (var i = 0; i < that._oTable.getItems().length; i++) {
					that._oTable.getItems()[i].getCells()[0].setSelectedKey("");
					that._oTable.getItems()[i].getCells()[0].setValue("");
					that._oTable.getItems()[i].getCells()[0].setValueState("None");
					that._oTable.getItems()[i].getCells()[1].setSelectedKey("");
					that._oTable.getItems()[i].getCells()[1].setValue("");
					that._oTable.getItems()[i].getCells()[2].setSelectedKey("");
					that._oTable.getItems()[i].getCells()[2].setValue("");
					that._oTable.getItems()[i].getCells()[3].setSelectedKey("");
					that._oTable.getItems()[i].getCells()[3].setValue("");
					that._oTable.getItems()[i].getCells()[4].setValue("");
					that._oTable.getItems()[i].getCells()[5].setText("");
					that._oTable.getItems()[i].getCells()[6].setText("");

				}
			} else if (model.getProperty("/oViewModel").lubricants) {
				that._oTable = that.byId('idLubTable');
				for (var i = 0; i < that._oTable.getItems().length; i++) {
					that._oTable.getItems()[i].getCells()[0].setValue("");
					that._oTable.getItems()[i].getCells()[1].setValue("");
					that._oTable.getItems()[i].getCells()[2].setValue("");
					that._oTable.getItems()[i].getCells()[3].setText("");
					that._oTable.getItems()[i].getCells()[4].setValue("");

				}
			}

			if (model.getProperty("/oViewModel").tankDips) {
				that._tnkTable = that.byId('tDpTable');
				for (var j = 0; j < that._tnkTable.getItems().length; j++) {
					that._tnkTable.getItems()[j].getCells()[0].setValue("");
					that._tnkTable.getItems()[j].getCells()[0].setSelectedKey("");
					that._tnkTable.getItems()[j].getCells()[0].setValueState("None");
					that._tnkTable.getItems()[j].getCells()[1].setValue("");
					that._tnkTable.getItems()[j].getCells()[1].setSelectedKey("");
					that._tnkTable.getItems()[j].getCells()[2].setValue("");
					that._tnkTable.getItems()[j].getCells()[2].setSelectedKey("");
					that._tnkTable.getItems()[j].getCells()[3].setValue("");
					that._tnkTable.getItems()[j].getCells()[4].setText("");
					that._tnkTable.getItems()[j].getCells()[5].setText("");
					that._tnkTable.getItems()[j].getCells()[6].setText("");
					that._tnkTable.getItems()[j].getCells()[7].setText("");
					that._tnkTable.getItems()[j].getCells()[8].setText("");
					that._tnkTable.getItems()[j].getCells()[9].setText("");
				}
				var json = that.getOwnerComponent().getModel("json");
				if (json.getProperty("/posted") === "Y") {
					json.setProperty("/posted", "");
				}
			}
		},
		refreshPumpout: function() {
			this.byId("MvId").setVisible(false);
		},
		// to reset all the input values
		resetAll: function() {
			var that = this;
			that.byId("rbMngd").setSelected(false);
			that.byId("rbNMngd").setSelected(false);
			that.byId("RgTypId").setSelectedKey("");
			that.byId("RgTypId").setValueState("None");
			that.byId("LcId").setSelectedKey("");
			that.byId("LcId").setValueState("None");
			that.byId("VnId").setSelectedKey("");
			that.byId("tdstr").setSelectedKey("");
			that.byId("tdmat").setSelectedKey("");
			that.byId("VnId").setValueState("None");
			that.byId("cmb1").setSelectedKey("");
			that.byId("MvId").setSelectedKey("");
			that.byId("cmb1").setValueState("None");
			that.byId("cmb2").setSelectedKey("");
			that.byId("cmb2").setValueState("None");
			that.byId("Qt1").setValue("");
			that.byId("Qt1").setValueState("None");
			that.byId("delvyDt").setValueState("None");
			// that.byId("delvyDt").setValue("");
			that.byId("wbs").setValue("");
			that.byId("wbs").setValueState("None");
			
			if (sap.ui.getCore().byId("attach")) {
				sap.ui.getCore().byId("attach").setValue("");
			}
			that.tableBinding();
			that.getOwnerComponent().getModel("json").refresh();
		},
		onInit: function() {
			this._onPatternMatched();

		},

		//called to bind the table model
		tableBinding: function() {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var oModel = this.getOwnerComponent().getModel();
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/ItemsSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/tabModel", r.results);
				}
			});
		},
		// to validate combobox for each selections made
		validateComboBox: function(oEvt) {
			var comboBox = oEvt.getSource();
			if (comboBox.getSelectedItemId() === "") {
				comboBox.setValueState("Error");
				comboBox.setValueStateText("Select valid item from list.");
			} else {
				comboBox.setValueState("None");
			}
			var oJSONModel = this.getOwnerComponent().getModel("json");
			
			if (oJSONModel.getProperty("/oViewModel").fuelRcpt && this.byId("rbMngd").getSelected()=== false && this.byId("rbNMngd").getSelected()=== false) {
				MessageBox.error("Please Select Managed or Non Managed Fuel");
			}
		},
		// To validate Input fields
		validateInput: function(oEvent) {
			if (oEvent.getParameters().value !== "" && oEvent.getParameters().value !== "0" && oEvent.getParameters().value !== "0.000") {
				var val = oEvent.getSource().setValueState("None");
			} else {
				oEvent.getSource().setValueState("Error");
			}

		},
		// Methods called on pattern matched
		_onPatternMatched: function() {
			this.populateVendor();
			this.populateLocation();
			this.populateRigStorage();
			this.populateRig();
			this.populateRigType();
			this.populateMaterial();
			this.MaterialInitialLoad();
			this.populateDepth();
			this.populateSection();
			this.populateOperationType();
			this.populateCharge();
			this.tableBinding();
			this.populateClass();
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			// called for Receipt type combo box model binding
			oModel.read("/RecptTypeSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/ViewDrpdwn", r.results);
				}
			});
		},
		//diameter of the tnkDips international Values
		populateDepth: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oModel.read("/welldiameterSet", {
				success: function(r) {
					oJSONModel.setProperty("/diaModel", r.results);
				},
				error: function() {}
			});
		},
		///operation type data
		populateOperationType: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oModel.read("/OperationsSet", {
				success: function(r) {
					oJSONModel.setProperty("/oprtnModel", r.results);
				},
				error: function() {}
			});
		},
		//section data model
		populateSection: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oModel.read("/wellsectionSet", {
				success: function(r) {
					oJSONModel.setProperty("/secModel", r.results);
				},
				error: function() {}
			});
		},
		//To get Vendor data model
		populateVendor: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var recpt = this.byId("selComb").getSelectedKey();
			var aFilters = [new Filter("ReceiptType", "EQ", recpt)];
			oModel.read("/VendorSet", {
				filters: aFilters,
				success: function(r) {
					oJSONModel.setProperty("/VndrModel", r.results);
				},
				error: function(oError) {

				}
			});
		},
		// To get the Location model
		populateLocation: function() {
			this._oTable = this.getView("table");
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/RigLocSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/LocModel", r.results);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get Location . Please try again.");
				}
			});
		},
		populateClass: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/classSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/classModel", r.results);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get class. Please try again.");
				}
			});
		},
		// to populate charge to 
		populateCharge: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/chargetoSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/chargeModel", r.results);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get charge to . Please try again.");
				}
			});
		},
		//item level rig storage also get data based on material filter
		populateRigStorage: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			var receipttype = this.byId("selComb").getSelectedKey();
			var aFilters = [new Filter("ReceiptType", "EQ", receipttype)];
			oModel.read("/RigStorageLocSet", {
				filters: aFilters,
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/StorModel", r.results);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get Storage Location. Please try again.");
				}
			});
		},

		// to get the Rig No
		populateRig: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show();
			oModel.read("/RigNoSet", {
				success: function(r) {
					oJSONModel.setProperty("/RigModel", r.results);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get manufacture Data. Please try again.");
				}
			});
		},
		//Rig Type Model
		populateRigType: function() {
			this._oTable = this.getView("table");
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/RigTypesSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/RigTypeModel", r.results);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get the Rig Type. Please try again.");
				}
			});
		},
		//To load all the materials initially
		MaterialInitialLoad: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var that = this;
			var oFilter = [];
			if (oJSONModel.getProperty("/oViewModel").tankDips || oJSONModel.getProperty("/oViewModel").fuelRcpt || oJSONModel.getProperty(
					"/oViewModel").pumpOut || oJSONModel.getProperty("/oViewModel").lubricants) {

				var Recpt = that.byId("selComb").getSelectedKey();
				var aFilters = [new Filter("Rigtype", "EQ", ""), new Filter("ReceiptType", "EQ", Recpt),
					new Filter("Lgort", "EQ", ""), new Filter("NonManagedFuel", "EQ", "")
				];
			}
			if (oJSONModel.getProperty("/oViewModel").tankDips) {
				var fRig = oJSONModel.getProperty("/sRig");
				Recpt = that.byId("selComb").getSelectedKey();
				var aFilters = [new Filter("Rigtype", "EQ", fRig), new Filter("ReceiptType", "EQ", Recpt),
					new Filter("Lgort", "EQ", ""), new Filter("NonManagedFuel", "EQ", "")
				];
			} else {
				if (oJSONModel.getProperty("/sRig") !== undefined) {
					fRig = oJSONModel.getProperty("/sRig");
					Recpt = that.byId("selComb").getSelectedKey();
					var aFilters = [new Filter("Rigtype", "EQ", fRig), new Filter("ReceiptType", "EQ", Recpt),
						new Filter("Lgort", "EQ", ""), new Filter("NonManagedFuel", "EQ", "")
					];
				}
				if (oJSONModel.getProperty("/sRig") !== undefined && that.byId("rbNMngd").getSelected() === true) {
					fRig = oJSONModel.getProperty("/sRig");
					Recpt = that.byId("selComb").getSelectedKey();
					aFilters = [new Filter("Rigtype", "EQ", fRig), new Filter("ReceiptType", "EQ", Recpt),
						new Filter("Lgort", "EQ", ""), new Filter("NonManagedFuel", "EQ", "X")
					];
				}

				if (oJSONModel.getProperty("/sRig") !== undefined && oJSONModel.getProperty("/sStorLoc") !== undefined && that.byId("rbNMngd").getSelected() ===
					true) {
					fRig = oJSONModel.getProperty("/sRig");
					Recpt = that.byId("selComb").getSelectedKey();
					aFilters = [new Filter("Rigtype", "EQ", fRig), new Filter("ReceiptType", "EQ", Recpt),
						new Filter("Lgort", "EQ", ""), new Filter("NonManagedFuel", "EQ", "X")
					];
				}
			}
			oModel.read("/MaterialSet", {
				filters: aFilters,
				success: function(r) {
					oJSONModel.setProperty("/iMtrlModel", r.results);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		/// to get the materials based on rig, location
		populateMaterial: function() {
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");

			var aFilter = [];
			if (oJSONModel.getProperty("/oViewModel").tankDips) {
				var fRig = oJSONModel.getProperty("/sRig");
				var Recpt = that.byId("selComb").getSelectedKey();
				// var tpSLoc = that.byId("tdstr").getSelectedKey();
				var aFilters = [new Filter("Rigtype", "EQ", fRig), new Filter("ReceiptType", "EQ", Recpt),
					new Filter("Lgort", "EQ", oJSONModel.getProperty("/sStorLoc")), new Filter("NonManagedFuel", "EQ", "")
					// new Filter("Lgort", "EQ", tpSLoc), new Filter("NonManagedFuel", "EQ", "")
				];
			} else {
				if (oJSONModel.getProperty("/sRig") !== undefined) {
					var fRig = oJSONModel.getProperty("/sRig");
					var Recpt = that.byId("selComb").getSelectedKey();
					var aFilters = [new Filter("Rigtype", "EQ", fRig), new Filter("ReceiptType", "EQ", Recpt),
						new Filter("Lgort", "EQ", ""), new Filter("NonManagedFuel", "EQ", "")
					];
				}
				if (oJSONModel.getProperty("/sRig") !== undefined && that.byId("rbNMngd").getSelected() === true) {
					var fRig = oJSONModel.getProperty("/sRig");
					var Recpt = that.byId("selComb").getSelectedKey();
					var aFilters = [new Filter("Rigtype", "EQ", fRig), new Filter("ReceiptType", "EQ", Recpt),
						new Filter("Lgort", "EQ", ""), new Filter("NonManagedFuel", "EQ", "X")
					];
				}
				if (oJSONModel.getProperty("/sStorLoc") !== undefined) {
					var fRig = oJSONModel.getProperty("/sRig");
					var Recpt = that.byId("selComb").getSelectedKey();
					var aFilters = [new Filter("Rigtype", "EQ", ""), new Filter("ReceiptType", "EQ", Recpt),
						new Filter("Lgort", "EQ", oJSONModel.getProperty("/sStorLoc")), new Filter("NonManagedFuel", "EQ", "")
					];
				}
				if (oJSONModel.getProperty("/sStorLoc") !== undefined && oJSONModel.getProperty("/sStorLoc") !== undefined) {
					var fRig = oJSONModel.getProperty("/sRig");
					var Recpt = that.byId("selComb").getSelectedKey();
					var aFilters = [new Filter("Rigtype", "EQ", fRig), new Filter("ReceiptType", "EQ", Recpt),
						new Filter("Lgort", "EQ", oJSONModel.getProperty("/sStorLoc")), new Filter("NonManagedFuel", "EQ", "")
					];
				}
				if (oJSONModel.getProperty("/sRig") !== undefined && oJSONModel.getProperty("/sStorLoc") !== undefined && that.byId("rbNMngd").getSelected() ===
					true) {
					fRig = oJSONModel.getProperty("/sRig");
					Recpt = that.byId("selComb").getSelectedKey();
					aFilters = [new Filter("Rigtype", "EQ", fRig), new Filter("ReceiptType", "EQ", Recpt),
						new Filter("Lgort", "EQ", oJSONModel.getProperty("/sStorLoc")), new Filter("NonManagedFuel", "EQ", "X")
					];
				}
				if (oJSONModel.getProperty("/sRig") !== undefined && oJSONModel.getProperty("/sClass") !== undefined &&
					oJSONModel.getProperty("/oViewModel").lubricants === true) {
					fRig = oJSONModel.getProperty("/sRig");
					Recpt = that.byId("selComb").getSelectedKey();
					aFilters = [new Filter("Rigtype", "EQ", fRig), new Filter("ReceiptType", "EQ", Recpt),
						new Filter("Labor", "EQ", oJSONModel.getProperty("/sClass"))
					];
				}
				// TJ Post Go live
				if (oJSONModel.getProperty("/oViewModel").pumpOut && that.byId("rbTtoR").getSelected() ) {
				var pumpOutFilter = new Filter("PumpOutType", "EQ", "T");
				aFilters.push(pumpOutFilter);
			} 
			}
					
			var I = oJSONModel.getProperty("/tabI");

			oModel.read("/MaterialSet", {
				filters: aFilters,
				success: function(r) {
					//	sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/MatrlModel" + I, r.results);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			});

		},
		// On material change if cartage show price $ input entry
		onMaterialChange: function(oEvent) {
			var that = this;
			var x = oEvent.getSource().getBindingContext("json").getPath().replace(/tabModel\//g, '');
			var Index = x.replace(/\//g, '');
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var oVal = oEvent.getSource().getSelectedItem().getProperty("key");
			var oI = oJSONModel.getProperty("/tabI");
			var path = "/MatrlModel" + oI;
			var matrlIndx = oEvent.getSource().getSelectedItem().getBindingContext("json").getPath().split("/")[2];
			this.getOwnerComponent().getModel("json").setProperty("/Indx", Index);
			if (oJSONModel.getProperty("/oViewModel").tankDips) {
				this.byId("tdpTable").getItems()[Index].getCells()[6].setText(oJSONModel.getProperty(path)[matrlIndx].Meins);
			}
			if (oJSONModel.getProperty("/oViewModel").pumpOut && that.byId("rbRtoS").getSelected()) {
				this.byId("pmpOutTable").getItems()[Index].getCells()[5].setText(oJSONModel.getProperty(path)[matrlIndx].Meins);
				this.byId("pmpOutTable").getItems()[Index].getCells()[6].setText(oJSONModel.getProperty(path)[matrlIndx].Labst);
			} else if (that.byId("rbTtoR").getSelected() && oJSONModel.getProperty("/oViewModel").pumpOut) {

				this.byId("pmpOutTable").getItems()[Index].getCells()[5].setText(oJSONModel.getProperty(path)[matrlIndx].Meins);
				this.byId("pmpOutTable").getItems()[Index].getCells()[6].setText(oJSONModel.getProperty(path)[matrlIndx].Labst);
			}
			if (oJSONModel.getProperty("/oViewModel").lubricants) {
				this.byId("idLubTable").getItems()[Index].getCells()[3].setText(oJSONModel.getProperty(path)[matrlIndx].Meins);
			}
			this.byId("idProductsTable").getItems()[Index].getCells()[4].setText(oJSONModel.getProperty(path)[matrlIndx].Meins);
	if (oJSONModel.getProperty("/oViewModel").fuelRcpt) {
			var cartg = oJSONModel.getProperty(path)[matrlIndx].Cartage;
			if (cartg === "X") {
				oEvent.getSource().getParent().getCells()[5].mAggregations.items[2].setVisible(true);
				if (!this.cDialog) {
					this.cDialog = sap.ui.xmlfragment("pd.fr.view.cartage", this);
				}
				this.cDialog.open();
			}
			if (cartg !== "X") {
				oEvent.getSource().getParent().getCells()[5].mAggregations.items[2].setVisible(false);
			}
			
	}
		if (oJSONModel.getProperty("/oViewModel").pumpOut) {
			var cartg = oJSONModel.getProperty(path)[matrlIndx].Cartage;
			if (cartg === "X") {
				oEvent.getSource().getParent().getCells()[7].mAggregations.items[2].setVisible(true);
				if (!this.cDialog) {
					this.cDialog = sap.ui.xmlfragment("pd.fr.view.cartage", this);
				}
				this.cDialog.open();
			}
			if (cartg !== "X") {
				oEvent.getSource().getParent().getCells()[7].mAggregations.items[2].setVisible(false);
			}
			
	}
		},

		//on tdips material change get stock and show in table
		ontDipsMaterlChng: function(oEvent) {
			var Index = oEvent.getSource().getSelectedItem().getBindingContext("json").getPath().split("/")[2];
			var x = oEvent.getSource().getBindingContext("json").getPath().replace(/tabModel\//g, '');
			var tableIndx = x.replace(/\//g, '');

			var path = "/MatrlModel" + tableIndx;
			var oJsonModel = this.getOwnerComponent().getModel("json");

			this.byId("tDpTable").getItems()[tableIndx].getCells()[6].setText(oJsonModel.getProperty(path)[Index].Meins);
			var stockVal = oEvent.getSource().getParent().getCells()[4].setText(oJsonModel.getProperty(path)[Index].Labst);
			if (stockVal === "0.000") {
				MessageBox.warning("Stock is zero or not applicable");
			}
			this.getOwnerComponent().getModel("json").refresh();
		},
		// to calculate and set the quantity value equals to stock subtracted by curr reading
		onCurrentReadingChange: function(oEvent) {
			var curr = oEvent.getParameters().value;
			var x = oEvent.getSource().getBindingContext("json").getPath().replace(/tabModel\//g, '');
			var Index = x.replace(/\//g, '');
			var stock = this.byId("tDpTable").getItems()[Index].getCells()[4].getText();
			var Quantity = stock - curr;
			this.byId("tDpTable").getItems()[Index].getCells()[5].setText(Quantity);
		},
		onNo: function() {
			sap.ui.getCore().byId("cPrice").setValue("");
			this.cDialog.close();
		},
		//on cartage dialog Yes press
		onYes: function(oEvent) {
			var cprice = sap.ui.getCore().byId("cPrice").getValue();
			var ojson = this.getOwnerComponent().getModel("json");
			ojson.setProperty("/cPrice", cprice);
			ojson.setProperty("/cartageMtrl", true);

			if (ojson.getProperty('/oViewModel').lubricants) {
				this.byId("priceCol2").setVisible(true);
			}
		if (ojson.getProperty('/oViewModel').fuelRcpt) {	
			this.byId("crtgId").setVisible(true);
			var i = ojson.getProperty("/tabI");

			this.byId("idProductsTable").getItems()[i].getCells()[2].setValue(cprice);
			
		}	
			if (ojson.getProperty('/oViewModel').pumpOut) {	
			this.byId("crtgIdP").setVisible(true);
			var i = ojson.getProperty("/tabI");

			this.byId("pmpOutTable").getItems()[i].getCells()[8].setValue(cprice);
			
		}	
		
		
			sap.ui.getCore().byId("cPrice").setValue("");
			this.cDialog.close();
		},
		//on cartage dialog Yes press
		onYesl: function() {
			var ojson = this.getOwnerComponent().getModel("json");
			var i = ojson.getProperty("/showCart");
			var pric = sap.ui.getCore().byId("clPrice").getValue();
			if (ojson.getProperty('/oViewModel').fuelRcpt) {
			this.byId("idProductsTable").getItems()[i].getCells()[2].setValue(pric);
			}
			if (ojson.getProperty('/oViewModel').pumpOut) {
			this.byId("pmpOutTable").getItems()[i].getCells()[8].setValue(pric);
			}
			sap.ui.getCore().byId("clPrice").setValue("");
			this.oDialog.close();
		},
		onNol: function() {
			sap.ui.getCore().byId("clPrice").setValue("");
			this.oDialog.close();
		},
		openPrice: function(oEvent) {
			if (!this.oDialog) {
				this.oDialog = sap.ui.xmlfragment("pd.fr.view.cartageL", this);
			}
			var x = oEvent.getSource().getBindingContext("json").getPath().replace(/tabModel\//g, '');
			var Index = x.replace(/\//g, '');
			var ojson = this.getOwnerComponent().getModel("json");
			ojson.setProperty("/showCart", Index);

			var pric ;
			if (ojson.getProperty('/oViewModel').fuelRcpt){
			pric = this.byId("idProductsTable").getItems()[Index].getCells()[2].getValue();
			sap.ui.getCore().byId("clPrice").setValue(pric);
			}
				if (ojson.getProperty('/oViewModel').pumpOut){
			pric = this.byId("pmpOutTable").getItems()[Index].getCells()[8].getValue();
			sap.ui.getCore().byId("clPrice").setValue(pric);
			}
			
			this.oDialog.open();

		},
		//to get selected Rig value and load the Materials dynamically
		onSelectedRig: function(oEvent) {
			
					
			var ojsonModel = this.getOwnerComponent().getModel("json");
			var oVal = oEvent.getSource().getSelectedItem().getProperty("key");
			ojsonModel.setProperty("/sRig", oVal);
			// this.MaterialInitialLoad();
				this.populateMaterial();
		},
		// to get the item level stor location value and load the  materials dynamically
		onStorLocChange: function(oEvent) {
			var ojsonModel = this.getOwnerComponent().getModel("json");
			var oVal = oEvent.getSource().getSelectedItem().getProperty("key");
			var key = oEvent.getSource().getSelectedKey();
			this.getOwnerComponent().getModel("json").setProperty("/sClass", key);
			ojsonModel.setProperty("/sStorLoc", oVal);
			var i = oEvent.getSource().getParent().getParent().indexOfItem(oEvent.getSource().getParent());
			ojsonModel.setProperty("/tabI", i);
			if (ojsonModel.getProperty("/oViewModel").fuelRcpt) {
				//	this.byId("cmb2").unbindItems();
				oEvent.getSource().getParent().getParent().getItems()[i].getCells()[1].bindItems("json>/MatrlModel" + i,
					new sap.ui.core.ListItem({
						key: "{json>Matnr}",
						text: "{json>Maktx}"
					}));
			}
			if (ojsonModel.getProperty("/oViewModel").tankDips) {
				oEvent.getSource().getParent().getParent().getItems()[i].getCells()[2].bindItems("json>/MatrlModel" + i,
					new sap.ui.core.ListItem({
						key: "{json>Matnr}",
						text: "{json>Maktx}"
					}));
			}
			if (ojsonModel.getProperty("/oViewModel").pumpOut) {
			if 	(this.byId("rbRtoS").getSelected())
			{ if 	(oVal === "CAMP" || oVal === "BOIL" || oVal === "GENR"  )
			{
				oEvent.getSource().getParent().getParent().getItems()[i].getCells()[3].unbindItems();
			}
			else
			{
				oEvent.getSource().getParent().getParent().getItems()[i].getCells()[3].bindItems("json>/MatrlModel" + i,
					new sap.ui.core.ListItem({
						key: "{json>Matnr}",
						text: "{json>Maktx}"
					}));
			}
			}
			else {
			if 	(oVal === "CAMP" || oVal === "BOIL" || oVal === "GENR" || oVal === "CART"  )
			{
				oEvent.getSource().getParent().getParent().getItems()[i].getCells()[3].unbindItems();
			}
			else{	
					oEvent.getSource().getParent().getParent().getItems()[i].getCells()[3].bindItems("json>/MatrlModel" + i,
					new sap.ui.core.ListItem({
						key: "{json>Matnr}",
						text: "{json>Maktx}"
					}));
			}
			}
			}
			
		
			
			if (ojsonModel.getProperty("/oViewModel").lubricants) {
				oEvent.getSource().getParent().getParent().getItems()[i].getCells()[1].bindItems("json>/MatrlModel" + i,
					new sap.ui.core.ListItem({
						key: "{json>Matnr}",
						text: "{json>Maktx}"
					}));
			}
			this.populateMaterial();
		},
		/*	onClassChange: function(oEvent) {
				var key = oEvent.getSource().getSelectedKey();
				this.getOwnerComponent().getModel("json").setProperty("/sClass", key);
				var i = oEvent.getSource().getParent().getParent().indexOfItem(oEvent.getSource().getParent());
			/*	if(key !== undefined || key !==""){
					this.getOwnerComponent().getModel("json").setProperty("/tabI", i);
				}*/
		/*	this.populateMaterial();
		if (this.getOwnerComponent().getModel("json").getProperty("/oViewModel").lubricants) {
			oEvent.getSource().getParent().getParent().getItems()[i].getCells()[1].bindItems("json>/MatrlModel" + i,
				new sap.ui.core.ListItem({
					key: "{json>Matnr}",
					text: "{json>Maktx}"
				}));*/
		//this.getOwnerComponent().getModel("json").setProperty("/tabI", "");
		/*	}
		
		},*/

		// materials based on selected location in Header level
		onSelectedLocation: function(oEvent) {
			var ojsonModel = this.getOwnerComponent().getModel("json");
			var loc = oEvent.getSource().getSelectedItem().getProperty("key");
			ojsonModel.setProperty("/sLoc", loc);
			this.populateMaterial();
		},
		handleDateChange: function(oEvent) {
			//	var oText = this.byId("T1");
			var oDP = oEvent.oSource;
			var sValue = oEvent.getParameter("value");
			var bValid = oEvent.getParameter("valid");
			if (bValid) {
				oDP.setValueState(sap.ui.core.ValueState.None);
			} else {
				oDP.setValueState(sap.ui.core.ValueState.Error);
			}
		},
		// action on selections of international values
		onSelections: function(oEvent) {
			var iIndex = this.byId("tDpTable").indexOfItem(this.byId("tDpTable").getSelectedItem());
			this.getOwnerComponent().getModel("json").setProperty("/index", iIndex);
			if (!this.dialog) {
				this.dialog = sap.ui.xmlfragment("pd.fr.view.internationalValues", this);
				this.getView().addDependent(this.dialog);
			}
			this.dialog.open();
		},
		// on Yes  press of international values
		onIntrlPress: function(oEvent) {
			var ojsonModel = this.getOwnerComponent().getModel("json");
			var oTable = this.byId("tDpTable");
			var tabModel = ojsonModel.getData().tabModel;
			var okey1 = sap.ui.getCore().byId("icmb1").getSelectedKey();
			var okey2 = sap.ui.getCore().byId("icmb2").getSelectedKey();
			var okey3 = sap.ui.getCore().byId("icmb3").getSelectedKey();
			var newdata = {};
			newdata.CartageAmount = okey1;
			newdata.Lgobe = okey2;
			newdata.Ebeln = okey3;
			var iIndex = ojsonModel.getProperty("/index");
			tabModel.splice(iIndex, 1, newdata);
			ojsonModel.setProperty("/tabModel", tabModel);
			ojsonModel.refresh(true);
			this.dialog.close();
		},
		onCancel: function() {
			this.dialog.close();
		},
		// on add Icon press add the new row
		addNewCell: function(oEvent) {
			this.byId("secLbl").setVisible(false);
			this.byId("dpLbl").setVisible(false);
			this.byId("opLbl").setVisible(false);
			var oJSONModel = this.getView().getModel("json");
			var Obj = this.getView().getModel("json").getData().tabModel;
			var oNewObject = {
				Matnr: "",
				Menge: "",
				Lgobe: ""
			};
			Obj.push(oNewObject);
			oJSONModel.setProperty("/data", Obj);
			oJSONModel.refresh(true);
		},
		// on delete icon press delete the selected row
		onDeleteFuel: function(oEvent) {
			var that = this;
			var ojson = that.getOwnerComponent().getModel("json");
			if (ojson.getProperty("/oViewModel").fuelRcpt) {
				that.oTable = that.byId("idProductsTable");
			} else if (ojson.getProperty("/oViewModel").tankDips) {
				that.oTable = that.byId("tDpTable");
			} else if (ojson.getProperty("/oViewModel").pumpOut) {
				that.oTable = that.byId("pmpOutTable");
			} else {
				that.oTable = that.byId("idLubTable");
			}
			var Model = that.getModel("json").getData().tabModel;
			//	var Model = that.oTable.getModel("json").getData();

			if (Model.length !== 1) {
				//	var sItem = oEvent.getSource().getParent().getBindingContext("json").getObject();
				var itemIndx = oEvent.getSource().getParent().getBindingContext("json").getPath().split("/")[2];
				var indxofsItem = parseInt(itemIndx);
				var oJSONModel = this.getView().getModel("json");
				var delObj = oJSONModel.getData().tabModel;
				//	delObj.pop(sItem);
				delObj.splice(indxofsItem, 1);
				oJSONModel.refresh(true);
			} else {
				MessageToast.show("Single entry should not be removed");
			}
		},
		// Posting for all  Receipt Types Fuel,TankDips,PumpOut,Lubricants
		onCreateFr: function(oEvent) {
			// console.log($.now());
			// console.log("Entering Process document");
			
			if (this.getOwnerComponent().getModel("json").getProperty("/busy")=== true)
			{
				// console.log($.now());
				// console.log("Duplicate call Exit Processing");
				return;
				
			}
			// console.log($.now());
			// console.log("Continue processing Post document");
			var that = this;
			var proceed = true;
			var RigType = that.byId("RgTypId").getSelectedKey();
			if (RigType === "") {
				that.byId("RgTypId").setValueState("Error");
				that.byId("RgTypId").setValueStateText("Select valid item from list.");
				proceed = false;
			} else {
				that.byId("RgTypId").setValueState("None");
			}
			// var Loc = that.byId("LcId").getSelectedKey();
			// if (Loc === "") {
			// 	that.byId("LcId").setValueState("Error");
			// 	that.byId("LcId").setValueStateText("Select valid item from list.");
			// 	proceed = false;
			// } else {
			// 	that.byId("LcId").setValueState("None");
			// }
			var Vend = that.byId("VnId").getSelectedKey();
			var selType = that.byId("selComb").getSelectedKey();
			var nonManged = that.byId("rbNMngd").getSelected();
			if (Vend === "" && ( selType !== "T" && nonManged === false) ) {
				that.byId("VnId").setValueState("Error");
				that.byId("VnId").setValueStateText("Select valid item from list.");
				proceed = false;
			} else {
				that.byId("VnId").setValueState("None");
			}

			var delDate = that.byId("delvyDt").getDateValue();
			var todaysDt = that.byId("toDt").getDateValue();
			var tDipsflag = true;
			if (that.getOwnerComponent().getModel("json").getProperty("/oViewModel").tankDips) {
				tDipsflag = false;
			}
			if (tDipsflag) {
				if (delDate === "") {

					that.byId("delvyDt").setValueStateText("Select valid item from list.");
					proceed = false;
				} else if (delDate !== "") {
					that.byId("delvyDt").setValueState("None");
				}
			}
			if (tDipsflag !== true) {

				if (todaysDt === "") {
					//	that.byId("delvyDt").setValueState("Error");
					that.byId("toDt").setValueStateText("Select valid item from list.");
					proceed = false;
				} else if (todaysDt !== "") {
					that.byId("toDt").setValueState("None");
				}
			}

			var oJSONModel = that.getOwnerComponent().getModel("json");
			var tModel = oJSONModel.getData().tabModel;
			var mModel = oJSONModel.getData().iMtrlModel;

			var oHeader = {};
			var ItemData = [];
			//for Fuel Receipt
			if (oJSONModel.getProperty("/oViewModel").fuelRcpt) {
				// TJ Post go live Chanrge to Only relevant for Fuel Reciept
			  	
					  		
			if (this.byId("rbMngd").getSelected()=== false && this.byId("rbNMngd").getSelected()=== false) {
				MessageBox.error("Please Select Managed or Non Managed Fuel");
				return;
			}
			
			var Loc = that.byId("LcId").getSelectedKey();
			if (Loc === "") {
				that.byId("LcId").setValueState("Error");
				that.byId("LcId").setValueStateText("Select valid item from list.");
				proceed = false;
			} else {
				that.byId("LcId").setValueState("None");
			}
				
				for (var i = 0; i < tModel.length; i++) {
					var Items = {};
					//	Items.CartageAmount = "0.00";

					if (that.byId("idProductsTable").getItems()[i].getCells()[2].getValue() !== "") {
						Items.CartageAmount = that.byId("idProductsTable").getItems()[i].getCells()[2].getValue();
					}
					Items.Menge = that.byId("idProductsTable").getItems()[i].getCells()[3].getValue();
					if (Items.Menge === "") {
						that.byId("idProductsTable").getItems()[i].getCells()[3].setValueState("Error");
						proceed = false;
					} else if (Items.Menge !== "") {
						that.byId("idProductsTable").getItems()[i].getCells()[3].setValueState("None");
					}
					Items.Matnr = that.byId("idProductsTable").getItems()[i].getCells()[1].getSelectedKey();
					if (Items.Matnr === "") {
						that.byId("idProductsTable").getItems()[i].getCells()[1].setValueState("Error");
						that.byId("cmb2").setValueState("Error");
					} else {
						that.byId("cmb2").setValueState("None");
					}
					//	Items.Matnr = "101";
					Items.Lgort = that.byId("idProductsTable").getItems()[i].getCells()[0].getSelectedKey();
					if (Items.Lgort === "") {
						that.byId("idProductsTable").getItems()[i].getCells()[0].setValueState("Error");
						that.byId("cmb1").setValueState("Error");
					} else {
						that.byId("cmb1").setValueState("None");
					}
					ItemData.push(Items);
				}
	
			} else if (oJSONModel.getProperty("/oViewModel").tankDips) {
				for (var j = 0; j < tModel.length; j++) {
					var Items = {};

					Items.Chargeto = that.byId("tDpTable").getItems()[j].getCells()[0].getSelectedKey();
					if (Items.Chargeto === "") {
						// that.byId("tDpTable").getItems()[j].getCells()[0].setValueState("Error");
						that.byId("tDpTable").getItems()[j].getCells()[0].setSelectedKey("J");

					} else {
						that.byId("tDpTable").getItems()[j].getCells()[0].setValueState("None");
					}

					Items.Lgort = that.byId("tDpTable").getItems()[j].getCells()[1].getSelectedKey();
					if (Items.Lgort === "") {
						that.byId("tDpTable").getItems()[j].getCells()[1].setValueState("Error");
					} else {
						that.byId("tDpTable").getItems()[j].getCells()[1].setValueState("None");
					}
					Items.Matnr = that.byId("tDpTable").getItems()[j].getCells()[2].getSelectedKey();
					if (Items.Matnr === "") {
						that.byId("tDpTable").getItems()[j].getCells()[2].setValueState("Error");
					} else {
						that.byId("tDpTable").getItems()[j].getCells()[2].setValueState("None");
					}
					Items.Menge = that.byId("tDpTable").getItems()[j].getCells()[5].getText();
					/*	if (Items.Menge === "0") {
							that.byId("tDpTable").getItems()[j].getCells()[5].setValueState("Error");

							MessageToast.show("Quantity should not be zero");
							proceed = false;
						}
						if (Items.Menge === "") {
							that.byId("tDpTable").getItems()[j].getCells()[5].setValueState("Error");
							MessageToast.show("Enter current reading to calculate quantity");
							proceed = false;
						}*/
					if (that.byId("tDpTable").getItems()[j].getCells()[7].getText() !== "" &&
						that.byId("tDpTable").getItems()[j].getCells()[8].getText() !== "" &&
						that.byId("tDpTable").getItems()[j].getCells()[9].getText() !== "") {
						Items.Wellsection = that.byId("tDpTable").getItems()[j].getCells()[7].getText();
						Items.OperationType = that.byId("tDpTable").getItems()[j].getCells()[8].getText();
						Items.Diameter = that.byId("tDpTable").getItems()[j].getCells()[9].getText();
					}
					ItemData.push(Items);
				}
			} else if (oJSONModel.getProperty("/oViewModel").pumpOut) {
				for (var k = 0; k < tModel.length; k++) {
					var Items = {};
					Items.Menge = that.byId("pmpOutTable").getItems()[k].getCells()[4].getValue();
					if (Items.Menge === "") {
						that.byId("pmpOutTable").getItems()[k].getCells()[4].setValueState("Error");
						MessageToast.show("Enter a valid quantity");
						proceed = false;
					}
					Items.Matnr = that.byId("pmpOutTable").getItems()[k].getCells()[3].getSelectedKey();
					if (Items.Matnr === "") {
						that.byId("pmpOutTable").getItems()[k].getCells()[3].setValueState("Error");
						proceed = false;
					}
					Items.Lgort = that.byId("pmpOutTable").getItems()[k].getCells()[1].getSelectedKey();
					if (Items.Lgort === "") {
						that.byId("pmpOutTable").getItems()[k].getCells()[1].setValueState("Error");
						proceed = false;
					}
					if (that.byId("pmpOutTable").getItems()[k].getCells()[8].getValue() !== "") {
						Items.CartageAmount = that.byId("pmpOutTable").getItems()[k].getCells()[8].getValue();
					}

					Items.Chargeto = that.byId("pmpOutTable").getItems()[k].getCells()[0].getSelectedKey();
					if (Items.Chargeto === "") {
						// that.byId("pmpOutTable").getItems()[k].getCells()[0].setValueState("Error");
						// proceed = false;
					that.byId("pmpOutTable").getItems()[k].getCells()[0].setSelectedKey("J");
					}
					if (that.byId("rbTtoR").getSelected()) {
						Items.MoveToWbs = that.byId("wbs").getValue();
						//	that.byId("pmpOutTable").getItems()[k].getCells()[2].getValue();
						if (that.byId("pmpOutTable").getItems()[k].getCells()[2].getValue() === "") {
							//	MessageBox.warning("Please enter the Wbs element");
						}
					}
					ItemData.push(Items);
				}
			} else if (oJSONModel.getProperty("/oViewModel").lubricants) {
				for (var r = 0; r < tModel.length; r++) {
					var Items = {};
					if (that.byId("idProductsTable").getItems()[r].getCells()[2].getValue() !== "") {
						Items.CartageAmount = that.byId("idProductsTable").getItems()[r].getCells()[2].getValue();
					}
					if (that.byId("idLubTable").getItems()[r].getCells()[4].getValue() !== "") {
						Items.CartageAmount = that.byId("idLubTable").getItems()[r].getCells()[4].getValue();
					}

					if (Items.Menge === "") {
						that.byId("idLubTable").getItems()[r].getCells()[2].setValueState("Error");
						proceed = false;
					} else if (Items.Menge !== "") {
						Items.Menge = that.byId("idLubTable").getItems()[r].getCells()[2].getValue();
						that.byId("idLubTable").getItems()[r].getCells()[2].setValueState("None");
					}
					Items.Matnr = that.byId("idLubTable").getItems()[r].getCells()[1].getSelectedKey();
					if (Items.Matnr === "") {
						that.byId("tDpTable").getItems()[r].getCells()[1].setValueState("Error");
					} else {
						that.byId("tDpTable").getItems()[r].getCells()[1].setValueState("None");
					}

					/*Items.Lgort = that.byId("idLubTable").getItems()[r].getCells()[0].getSelectedKey();
					if (Items.Lgort === "") {
						that.byId("idLubTable").getItems()[r].getCells()[0].setValueState("Error");
					} else {
						that.byId("idLubTable").getItems()[r].getCells()[0].setValueState("None");
					}*/

					ItemData.push(Items);
				}
			}
			oJSONModel.setProperty("/Payload", Items);
			var delDt = that.byId("delvyDt").getValue();
			var valDel = that.byId("delvyDt").getDateValue();
			var tdyDt = that.byId("toDt").getValue();
			var tvdyDt = that.byId("toDt").getDateValue();
			var updatedFormat;
			var dateformat;
			if (delDt === "") {
				updatedFormat = null;
			} else {
				var delvyDate = new Date(delDt);
				var date = new Date(valDel.getUTCFullYear(), valDel.getMonth(), valDel.getUTCDate());
				var nDate = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyy-MM-dd"
				});
				var oDatef = nDate.format(new Date(date));
				var oDateout = oDatef + 'T00:00:00';
				updatedFormat = [delvyDate.getFullYear(), delvyDate.getMonth() + 1, delvyDate.getDate()].join("-");
				updatedFormat = updatedFormat + "T00:00:00";
				oHeader.PstngDate = oDateout; //updatedFormat;
				oHeader.DocDate = oDateout; //updatedFormat;
			}
			if (oJSONModel.getProperty("/oViewModel").tankDips) {
				if (tdyDt === "") {
					dateformat = null;
				} else {
					var today = new Date(tdyDt);
				var date = new Date(tvdyDt.getUTCFullYear(), tvdyDt.getMonth(), tvdyDt.getUTCDate());
				var nDate = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyy-MM-dd"
				});
				var oDatef = nDate.format(new Date(date));
				var oDateout = oDatef + 'T00:00:00';
					dateformat = [today.getFullYear(), today.getMonth() + 1, today.getDate()].join("-");
					dateformat = dateformat + "T00:00:00";
					oHeader.PstngDate = oDateout; //dateformat;
					oHeader.DocDate = oDateout; //dateformat;
				}
			}
			//	oHeader.Bsart = "ZF";
			//	oHeader.MoveType = "901";
			/*	if(!oJSONModel.getProperty("/oViewModel").pmpOut){
				oHeader.MoveType = "901";
				}else if(oJSONModel.getProperty("/oViewModel").pmpOut &&  that.byId("rbTtoS").getSelected()){
						oHeader.MoveType = "415Q";
				}*/
			if (oJSONModel.getProperty("/oViewModel").pumpOut) {
				oHeader.MoveStloc = that.byId("MvId").getSelectedKey();
			}
			oHeader.Lifnr = that.byId("VnId").getSelectedKey();
			//	oHeader.Ekgrp = "";
			oHeader.ReceiptType = that.byId("selComb").getSelectedKey();
			//	oHeader.HeaderTxt = "";
			oHeader.Location = that.byId("LcId").getSelectedKey();

			if (that.byId("rbTtoR").getSelected() && oJSONModel.getProperty("/oViewModel").pumpOut) {
				oHeader.TransferToRig = "X";
				/*	Items.MoveToWbs = that.byId("wbs").getValue();*/
				that.byId("vndrBox").setVisible(false);
				that.byId("MvBox").setVisible(true);
			} else if (oJSONModel.getProperty("/oViewModel").pumpOut && that.byId("rbRtoS").getSelected()) {

				that.byId("rbMngd").setSelected(false);
				that.byId("MvBox").setVisible(false);
				that.byId("vndrBox").setVisible(true);
				oHeader.ReturnToSupp = "X";
			}

			var tDipsflag = true;
			if (oJSONModel.getProperty("/oViewModel").tankDips) {
				tDipsflag = false;
			}
			var LubFlag = true;
			if (oJSONModel.getProperty("/oViewModel").lubricants) {
				LubFlag = false;
			}
			if (oJSONModel.getProperty("/oViewModel").pumpOut) {
				LubFlag = false;
			}
			if (tDipsflag && LubFlag) {
				if (that.byId("rbMngd").getSelected()) {
					oHeader.ManagedFuel = "X";
				} else if (that.byId("rbNMngd").getSelected()) {
					oHeader.NonManagedFuel = "X";
				}
			}

			// insert item data into header data
			oHeader.ItemsSet = ItemData;
			//get model instance
			var oModelMain = this.getOwnerComponent().getModel();
			if (that.byId("MvId").getSelectedKey() !== "" && that.byId("VnId").getSelectedKey() === "") {
				proceed = true;
			}
			if (proceed !== true) {
				MessageBox.warning("Please enter all the mandatory fields");
				sap.ui.core.BusyIndicator.hide();
			} else if (proceed === true && that.byId("delvyDt").getValue() === "" && tDipsflag) {
				MessageBox.warning("Please Enter the Delivery Date");
				sap.ui.core.BusyIndicator.hide();
			} else if (proceed === true && oJSONModel.getProperty("/continue")) {
				MessageBox.warning("Please Choose the appropriate material");
				sap.ui.core.BusyIndicator.hide();
			} else {
				var that = this;
				this.getOwnerComponent().getModel("json").setProperty("/busy", true);
				sap.ui.core.BusyIndicator.show();
				oModelMain.create("/HeaderSet", oHeader, {
					success: function(oData, oResponse) {
						// Success
						sap.ui.core.BusyIndicator.hide();
						var oMsg = oResponse.headers;
						var sEbeln = oResponse.data.Ebeln;
						var jsonStr = oMsg["sap-message"];
						var msgTyp = JSON.parse(jsonStr).severity;
					   if (msgTyp !== "error") {
					   		that.getOwnerComponent().getModel("json").setProperty("/busy", false);
						MessageBox.success((JSON.parse(jsonStr).message));
                      
						//add create operation for uploading files to sharepoint
						var oFileName = sap.ui.getCore().byId("attach");
						if(oFileName){
						if (oFileName.getValue() && sEbeln) {
							var sPath = "/sap/opu/odata/sap/ZMM_ODATA_FUEL_RECPT_ISSUE_SRV/AttachSet";
							var sFileVal = oFileName.getValue();
							var sUrl = sPath + "(Filename='" + sFileVal + "',Ebeln='" + sEbeln + "')/$value";
							oFileName.setUploadUrl(sUrl);
							oFileName.setSendXHR(true);

							//add header parameters
							that.getOwnerComponent().getModel().refreshSecurityToken();
							var file = oFileName.oFileUpload.files[0];
							var base64Marker = 'data:' + file.type + ';base64,';
							var reader = new FileReader();
							reader.onload = (function(theFile) {
								return function(evt) {
									var base64Index = evt.target.result.indexOf(base64Marker) + base64Marker.length;
									var base64 = evt.target.result.substring(base64Index);
									var token = that.getOwnerComponent().getModel().getHeaders()['x-csrf-token'];
									$.ajaxSetup({
										cache: false
									});

									jQuery.ajax({
										url: sPath,
										async: false,
										dataType: 'json',
										cache: false,
										data: base64,
										type: "POST",
										beforeSend: function(xhr) {
											xhr.setRequestHeader("X-CSRF-Token", token);
											xhr.setRequestHeader("Content-Type", file.type);
											xhr.setRequestHeader("slug", sFileVal + "," + sEbeln + "," + file.name);
										},
										success: function(odata) {
											oFileName.setValue("");
										that.getOwnerComponent().getModel("json").setProperty("/busy", false);
										}
									});
								};
							})(file);
							reader.readAsDataURL(file);
						} //get value from file if condition
						}
						var p = that.getOwnerComponent().getModel("json").getProperty("/tabI");
						that.getOwnerComponent().getModel("json").setProperty("/posted", "Y");
						that.getOwnerComponent().getModel("json").setProperty("/MatrlModel" + p, "");
						that.refreshTable();
						that.resetAll();
					}
					else
					{
							that.getOwnerComponent().getModel("json").setProperty("/busy", false);
						MessageBox.error((JSON.parse(jsonStr).message));
					}
					},
					error: function(oError, oResponse) {
						sap.ui.core.BusyIndicator.hide();
						jQuery.sap.require("sap.m.MessageBox");
							that.getOwnerComponent().getModel("json").setProperty("/busy", false);
						sap.m.MessageBox.show((JSON.parse(oError.responseText).error.message.value), {
							icon: sap.m.MessageBox.Icon.Information,
							title: "Message Box"
						});
					}
				});
			}

		},
		suggestionItemSelected: function(oEvt) {
			oEvt.getSource();
			oEvt.getParameters();
		},

		onUpdateFinished: function(oEvent) {

			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},

		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},
		onClear: function() {
			this.refreshTable();
			this.resetAll();
		},
		openAttachment: function(e) {
			if (!this.attachDialog) {
				this.attachDialog = sap.ui.xmlfragment("pd.fr.view.attachment", this);
				this.getView().addDependent(this.attachDialog);
			}
			this.attachDialog.open();
		},
		
		fileChange: function(oEvent){
			var oName = oEvent;	
		},
		
		attachOk: function() {
			var sValue = sap.ui.getCore().byId("attach").oFileUpload.files[0].name;
			sap.ui.getCore().byId("attach").setValue(sValue);
			this.attachDialog.close();
		},
		
		attachCancel: function() {
			sap.ui.getCore().byId("attach").setValue("");
			this.attachDialog.close();
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("worklistView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},

		onRefresh: function() {
			this._oTable.getBinding("items").refresh();
		},

		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Matnr")
			});
		},

		_applySearch: function(oTableSearchState) {
			var oViewModel = this.getModel("worklistView");
			this._oTable.getBinding("items").filter(oTableSearchState, "Application");

			if (oTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		},
			handleWBSHelp : function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._WBSHelpDialog) {
				this._WBSHelpDialog = sap.ui.xmlfragment(
					"pd.fr.view.wbsSearch",
					this
				);
				this.getView().addDependent(this._WBSeHelpDialog);
			}


			// open value help dialog filtered by the input value
			this._WBSHelpDialog.open(sInputValue);
		},

		_handleWBSHelpSearch : function (evt) {
			var sValue = evt.getParameter("value");
			

			var aFilters = [new Filter("RigNo", "EQ", sValue)];
					var oModel = this.getOwnerComponent().getModel();
						var oJSONModel = this.getOwnerComponent().getModel("json");
						// evt.getSource()._setModel(oModel);
						evt.getSource()._setModel(oJSONModel, "json");
							sap.ui.core.BusyIndicator.show();
		oModel.read("/WBSSet", {
				filters: aFilters,
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/WBSModel", r.results);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			});
			
				
			// evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleWBSHelpClose : function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
			this.byId("wbs").setValue(oSelectedItem.getProperty("title"));
					
		}
		},
		
				beforeSelectSloc: function(evt) {
					var oSource = evt.getSource();
				},
				
			onExit: function() {
				
             this.byId("cmb1").destroy(); 
             this.byId("cmb2").destroy(); 
             this.byId("crtgId").destroy(); 
             this.byId("Qt1").destroy(); 
             this.byId("uomId").destroy(); 
             this.byId("priceBt").destroy(); 
             this.byId("tableList").destroy(); 
             this.byId("tDcmb1").destroy(); 
             this.byId("tDcmb2").destroy(); 
             this.byId("crtgId2").destroy(); 
             this.byId("uomLb").destroy(); 
             this.byId("priceBt2").destroy(); 
             this.byId("chrgId").destroy();          
             this.byId("tdstr").destroy();   
             this.byId("tdmat").destroy();   
             this.byId("crRdng").destroy();  
             this.byId("stck").destroy();  
             this.byId("qty").destroy();  
             this.byId("uomtd").destroy();  
             this.byId("ScStg").destroy();  
             this.byId("Optyp").destroy();  
             this.byId("Dpth").destroy();
             this.byId("chrg2Id").destroy(); 
             this.byId("postr").destroy(); 
             this.byId("pomat").destroy(); 
             this.byId("uompo").destroy(); 
             this.byId("avstck").destroy(); 
             this.byId("priceBtP").destroy(); 
             this.byId("crtgIdP").destroy(); 
             
			}

	});
});